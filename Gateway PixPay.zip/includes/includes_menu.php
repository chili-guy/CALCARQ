<?php
session_start();

include('../../libs/updateUserInfo.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: ../../login");
    exit();
}



?>
 
 
 
 <div class="loader-container">
         <div class="loader"></div>
         <div class="loading-text">Carregando recursos, aguarde um pouco...</div>
      </div>
      <nav class="pc-sidebar">
         <div class="navbar-wrapper">
            <div class="m-header">
               <a href="../../" class="b-brand text-primary">
                  <img src="../../imagens/log.png" alt="logo" style="width: 200px; height: auto;" />
               </a>
            </div>
            <div class="navbar-content">
               <div class="card pc-user-card">
                  <div class="card-body">
                     <div class="d-flex align-items-center">
                        <div class="flex-shrink-0">
                           <img src="https://img.freepik.com/fotos-premium/logotipo-redondo-moderno-com-mulher-futurista-em-cores-suaves-e-luz-de-fundo-ia-generativa_7023-240406.jpg?w=740" alt="user-image" class="user-avtar wid-45 rounded-circle" />
                        </div>
                        <div class="flex-grow-1 ms-3 me-2">
                           <h6 class="mb-0"><?php echo $user_name; ?></h6>
                           <small>Cargo: <?php echo $user_role; ?></small>
                        </div>
                        <a class="btn btn-icon btn-link-secondary avtar" data-bs-toggle="collapse" href="#pc_sidebar_userlink">
                           <svg class="pc-icon">
                              <use xlink:href="#custom-sort-outline"></use>
                           </svg>
                        </a>
                     </div>
                     <div class="collapse pc-user-links" id="pc_sidebar_userlink">
                        <div class="pt-3">
                           <a href="logout">
                              <i class="ti ti-power"></i>
                              <span>Sair</span>
                           </a>
                           
                          <?php
if (isset($_SESSION['role']) && $_SESSION['role'] === 'ADMIN') {
?>
                            <div class="pt-3">
        <a href="admin">
            <i class="ti ti-shield"></i> <!-- Ícone de administrador -->
            <span>Administração</span>
        </a>
                           
                            <?php
                            }
                            ?>
                           
                           
                           
                        </div>
                     </div>
                  </div>
               </div>
 
               <ul class="pc-navbar">
                  <li class="pc-item pc-caption">
                     <label>Navegação</label>
                  </li>
                  <li class="pc-item active">
                     <a href="./" class="pc-link">
                        <span class="pc-micon">
                           <svg class="pc-icon">
                              <use xlink:href="#custom-status-up"></use>
                           </svg>
                        </span>
                        <span class="pc-mtext">Dashboard</span>
                     </a>
                  </li>
                
                  <li class="pc-item ">
                     <a href="../../profile" class="pc-link">
                        <span class="pc-micon">
                           <i class="ti ti-users"></i>
                        </span>
                        <span class="pc-mtext">Perfil</span>
                     </a>
                  </li>
                  <li class="pc-item">
                     <a href="../../settings" class="pc-link">
                        <span class="pc-micon">
                           <i class="ti ti-users"></i>
                        </span>
                        <span class="pc-mtext">Configurações</span>
                     </a>
                  </li>
                    <?php
                            if(isset($_SESSION['documents_checked']) && $_SESSION['documents_checked'] == 1) {
                                ?>
                  <li class="pc-item pc-caption">
                     <label>Financeiro</label>
                     <svg class="pc-icon">
                        <use xlink:href="#custom-presentation-chart"></use>
                     </svg>
                  </li>
                  
                  <li class="pc-item">
              <a data-target="libs/includes/gerar_saque" type="submit" class="pc-link openModal">
                        <span class="pc-micon">
                           <i class="ti ti-arrow-bar-up"></i>
                        </span>
                        <span class="pc-mtext">Transferir via PIX</span>
                     </a>
                  </li>
                  <li class="pc-item">
                         <a data-target="libs/includes/gerar_pix" type="submit" class="pc-link openModal">
                        <span class="pc-micon">
                           <i class="ti ti-arrow-bar-to-down"></i>
                        </span>
                        <span class="pc-mtext">Gerar Pagamento PIX</span>
                     </a>
                  </li>
                  <li class="pc-item">
                         <a data-target="libs/includes/transferencia_interna" type="submit" class="pc-link openModal">
            
                        <span class="pc-micon">
                           <i class="ti ti-arrow-bar-to-down"></i>
                        </span>
                        <span class="pc-mtext">Transferência Interna</span>
                     </a>
                  </li>
                 <li class="pc-item pc-caption">
                     <label>Status</label>
                     <svg class="pc-icon">
                        <use xlink:href="#custom-presentation-chart"></use>
                     </svg>
                  </li>
                  <li class="pc-item">
                     <a href="../../cashin" class="pc-link">
                        <span class="pc-micon">
                           <i class="ti ti-chart-bar"></i>
                        </span>
                        <span class="pc-mtext">Entradas PIX</span>
                     </a>
                  </li>
                    <li class="pc-item">
                     <a href="../../cashout" class="pc-link">
                        <span class="pc-micon">
                           <i class="ti ti-chart-bar"></i>
                        </span>
                        <span class="pc-mtext">Saidas PIX</span>
                     </a>
                  </li>
                  
                     <li class="pc-item">
                     <a href="../../relatorios" class="pc-link">
                        <span class="pc-micon">
                           <i class="ti ti-chart-bar"></i>
                        </span>
                        <span class="pc-mtext">Relatorios</span>
                     </a>
                  </li>
                  
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                 <li class="pc-item pc-caption">
                     <label>DEVELOPERS</label>
                     <svg class="pc-icon">
                        <use xlink:href="#custom-presentation-chart"></use>
                     </svg>
                  </li>
                  <li class="pc-item">
                     <a href="../../dev" class="pc-link">
                        <span class="pc-micon">
                           <i class="ti ti-news"></i>
                        </span>
                        <span class="pc-mtext">Documentação API</span>
                     </a>
                  </li>
                    <li class="pc-item">
                     <a href="../../keys" class="pc-link">
                        <span class="pc-micon">
                           <i class="ti ti-news"></i>
                        </span>
                        <span class="pc-mtext">Credenciais API</span>
                     
                  </li>
                
               
                     
                     <?php
                            }
                            ?>
                            
                            
                  </li>
               </ul>
            </div>
         </div>
      </nav>