

<li class="list-group-item">
                     <h6 class="mb-1">Layout do tema</h6>
                     <p class="text-muted text-sm">Escolha seu layout</p>
                     <div class="theme-main-layout d-flex align-center gap-1 w-100">
                        <a href="#!" data-bs-toggle="tooltip" title="Vertical" class="active" data-value="vertical">
                           <img src="../../sistemaAssets/assets/images/customizer/caption-on.svg" alt="img" class="img-fluid" />
                        </a>
                        <a href="#!" data-bs-toggle="tooltip" title="Horizontal" data-value="horizontal">
                           <img src="../../sistemaAssets/assets/images/customizer/horizontal.svg" alt="img" class="img-fluid" />
                        </a>
                        <a href="#!" data-bs-toggle="tooltip" title="Color Header" data-value="color-header">
                           <img src="../../sistemaAssets/assets/images/customizer/color-header.svg" alt="img" class="img-fluid" />
                        </a>
                        <a href="#!" data-bs-toggle="tooltip" title="Compact" data-value="compact">
                           <img src="../../sistemaAssets/assets/images/customizer/compact.svg" alt="img" class="img-fluid" />
                        </a>
                        <a href="#!" data-bs-toggle="tooltip" title="Tab" data-value="tab">
                           <img src="../../sistemaAssets/assets/images/customizer/tab.svg" alt="img" class="img-fluid" />
                        </a>
                     </div>
                  </li>
                  <li class="list-group-item">
                     <h6 class="mb-1">Escolha seu layout</h6>
                     <p class="text-muted text-sm">Ocultar/Mostrar Legenda da Barra Lateral</p>
                     <div class="row theme-color theme-nav-caption">
                        <div class="col-6">
                           <div class="d-grid">
                              <button
                                 class="preset-btn btn-img btn active"
                                 data-value="true"
                                 onclick="layout_caption_change('true');"
                                 data-bs-toggle="tooltip"
                                 title="Caption Show">
                                 <img src="../../sistemaAssets/assets/images/customizer/caption-on.svg" alt="img" class="img-fluid" />
                              </button>
                           </div>
                        </div>
                        <div class="col-6">
                           <div class="d-grid">
                              <button
                                 class="preset-btn btn-img btn"
                                 data-value="false"
                                 onclick="layout_caption_change('false');"
                                 data-bs-toggle="tooltip"
                                 title="Caption Hide">
                                 <img src="../../sistemaAssets/assets/images/customizer/caption-off.svg" alt="img" class="img-fluid" />
                              </button>
                           </div>
                        </div>
                     </div>
                  </li>
                  <li class="list-group-item">
                     <div class="pc-rtl">
                        <h6 class="mb-1">Layout do tema</h6>
                        <p class="text-muted text-sm">LTR/RTL</p>
                        <div class="row theme-color theme-direction">
                           <div class="col-6">
                              <div class="d-grid">
                                 <button
                                    class="preset-btn btn-img btn active"
                                    data-value="false"
                                    onclick="layout_rtl_change('false');"
                                    data-bs-toggle="tooltip"
                                    title="LTR">
                                    <img src="../../sistemaAssets/assets/images/customizer/ltr.svg" alt="img" class="img-fluid" />
                                 </button>
                              </div>
                           </div>
                           <div class="col-6">
                              <div class="d-grid">
                                 <button
                                    class="preset-btn btn-img btn"
                                    data-value="true"
                                    onclick="layout_rtl_change('true');"
                                    data-bs-toggle="tooltip"
                                    title="RTL">
                                    <img src="../../sistemaAssets/assets/images/customizer/rtl.svg" alt="img" class="img-fluid" />
                                 </button>
                              </div>
                           </div>
                        </div>
                     </div>
                  </li>
                  <li class="list-group-item pc-box-width">
                     <div class="pc-container-width">
                        <h6 class="mb-1">Largura do layout</h6>
                        <p class="text-muted text-sm">Escolha o layout completo ou contêiner</p>
                        <div class="row theme-color theme-container">
                           <div class="col-6">
                              <div class="d-grid">
                                 <button
                                    class="preset-btn btn-img btn active"
                                    data-value="false"
                                    onclick="change_box_container('false')"
                                    data-bs-toggle="tooltip"
                                    title="Full Width">
                                    <img src="../../sistemaAssets/assets/images/customizer/full.svg" alt="img" class="img-fluid" />
                                 </button>
                              </div>
                           </div>
                           <div class="col-6">
                              <div class="d-grid">
                                 <button
                                    class="preset-btn btn-img btn"
                                    data-value="true"
                                    onclick="change_box_container('true')"
                                    data-bs-toggle="tooltip"
                                    title="Fixed Width">
                                    <img src="../../sistemaAssets/assets/images/customizer/fixed.svg" alt="img" class="img-fluid" />
                                 </button>
                              </div>
                           </div>
                        </div>
                     </div>
                  </li>
                  <li class="list-group-item">
                     <div class="d-grid">
                        <button class="btn btn-light-danger" id="layoutreset">Redefinir Layout</button>
                     </div>
                  </li>
               </ul>
            </div>
         </div>
      </div>
      <script src="../../sistemaAssets/assets/js/plugins/apexcharts.min.js"></script>
      <script src="../../sistemaAssets/assets/js/pages/dashboard-default.js"></script>
      <script src="../../sistemaAssets/assets/js/plugins/popper.min.js"></script>
      <script src="../../sistemaAssets/assets/js/plugins/simplebar.min.js"></script>
      <script src="../../sistemaAssets/assets/js/plugins/bootstrap.min.js"></script>
      <script src="../../sistemaAssets/assets/js/fonts/custom-font.js"></script>
      <script src="../../sistemaAssets/assets/js/pcoded.js"></script>
      <script src="../../sistemaAssets/assets/js/plugins/feather.min.js"></script>
      <script>
         layout_change('dark');
      </script>
      <script>
         layout_theme_contrast_change('false');
      </script>
      <script>
         change_box_container('false');
      </script>
      <script>
         layout_caption_change('true');
      </script>
      <script>
         layout_rtl_change('false');
      </script>
      <script>
         preset_change('preset-1');
      </script>
      <script>
         main_layout_change('vertical');
      </script>
   </body>

</html>

