<style>
  .toast {
    position: fixed;
    bottom: 20px;
    right: 20px;
    border-radius: 8px;
    background: linear-gradient(135deg, #ff7e5f, #feb47b);
    color: #fff;
    padding: 15px 20px;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
    font-family: 'Arial', sans-serif;
    font-size: 16px;
    opacity: 0;
    transform: translateY(100%);
    transition: all 0.4s ease;
    display: block !important;
}

.toast.active {
    opacity: 1;
    transform: translateY(0);
}

.toast .toast-close {
    position: absolute;
    top: 10px;
    right: 10px;
    color: #fff;
    font-size: 18px;
    cursor: pointer;
    opacity: 0.7;
}

.toast .toast-close:hover {
    opacity: 1;
}

.toast-content {
    display: flex;
    align-items: center;
    gap: 10px;
}

.toast-check {
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: #ff4500;
    border-radius: 50%;
    color: #fff;
    font-size: 24px;
    width: 40px;
    height: 40px;
}

</style>