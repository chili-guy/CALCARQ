<!DOCTYPE html>
<html lang="pt-BR">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Documentação: Gerar PIX</title> <!-- Bootstrap CSS -->
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet"> <!-- Para ícones -->
  <style>
    body {
      background-color: #121212;
      color: #e0e0e0;
      font-family: 'Arial', sans-serif;
      margin: 0;
      padding: 0;
    }

    header {
      background-color: #1e1e1e;
      color: #ffffff;
      padding: 20px 15px;
      text-align: center;
    }

    header h1 {
      font-size: 2rem;
      margin: 0;
    }

    header p {
      font-size: 1rem;
      margin-top: 10px;
    }

    .navbar-custom {
      background-color: #343a40;
    }

    .navbar-custom .navbar-nav .nav-link {
      color: #ffffff;
    }

    .navbar-custom .navbar-nav .nav-link:hover {
      color: #007bff;
    }

    .sidebar {
      background-color: #1f2a36;
      color: #ffffff;
      position: fixed;
      top: 0;
      left: 0;
      height: 100%;
      width: 220px;
      padding-top: 20px;
      box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
      z-index: 999;
    }

    .sidebar h4 {
      text-align: center;
      margin-bottom: 30px;
      font-size: 1.2rem;
      color: #ffffff;
    }

    .sidebar a {
      color: #ffffff;
      text-decoration: none;
      padding: 12px 20px;
      display: block;
      font-size: 1rem;
      border-bottom: 1px solid #444;
      transition: background-color 0.3s;
    }

    .sidebar a:hover {
      background-color: #007bff;
    }

    .main-content {
      margin-left: 240px;
      padding: 20px;
    }

    .section-title {
      color: #007bff;
      margin-top: 30px;
      margin-bottom: 20px;
      font-size: 1.5rem;
    }

    .section-content {
      background-color: #2c2f38;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
      margin-bottom: 30px;
    }

    .code-block {
      background-color: #2d2d2d;
      color: #f8f8f2;
      padding: 15px;
      border-radius: 8px;
      border: 1px solid #444;
      font-family: 'Courier New', monospace;
      font-size: 1rem;
      line-height: 1.5;
      white-space: pre-wrap;
      word-wrap: break-word;
      overflow-x: auto;
    }

    .alert-custom {
      padding: 15px;
      margin-top: 20px;
      border-radius: 5px;
    }

    .alert-success {
      background-color: #2d6a4f;
      border-color: #2d6a4f;
      color: #ffffff;
    }

    .alert-danger {
      background-color: #9d2f2f;
      border-color: #9d2f2f;
      color: #ffffff;
    }

    footer {
      background-color: #1e1e1e;
      color: #ffffff;
      padding: 15px;
      text-align: center;
    }

    footer a {
      color: #ffffff;
      text-decoration: none;
    }

    footer a:hover {
      text-decoration: underline;
    }

    .table th {
      background-color: #007bff;
      color: #ffffff;
    }

    .table-striped tbody tr:nth-child(odd) {
      background-color: #333;
    }

    .table td, .table th {
      vertical-align: middle;
      color: #ffffff; /* Adiciona cor branca para o texto das células */
    }

    .btn-custom {
      background-color: #007bff;
      color: white;
      border-radius: 5px;
      padding: 8px 16px;
      font-size: 1rem;
      border: none;
      transition: background-color 0.3s;
    }

    .btn-custom:hover {
      background-color: #0056b3;
    }

    .table td, .table th {
      vertical-align: middle;
      color: #ffffff;
    }
  </style>
</head>

<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <h4 class="text-center">Documentação PIX</h4>
        <ul>
      <li><a href="#introducao"><i class="fas fa-code"></i> API - Gerar Pagamento</a></li>
      <li><a href="#introducao1"><i class="fas fa-book"></i> API - Transferência PIX</a></li>
      <li><a href="#webhook"><i class="fas fa-bell"></i> WEBHOOK - Evento de Pagamento</a></li>
      <li><a href="#webhook1"><i class="fas fa-bell"></i> WEBHOOK - Evento de Transferência</a></li>
        </ul>
    </div>
  <!-- Container principal -->
  <div class="main-content">
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-custom">
      <a class="navbar-brand text-white" href="#">PixPay</a>
    </nav>

    <!-- Header -->
    <header>
               

      <h1>Documentação: Gerar PIX</h1>
      <p>Saiba como utilizar o script para gerar PIX em sua aplicação.</p>
                     <center> <img src="https://pixpay.fun/imagens/log.png" alt="Logo" class="img-fluid mb-4" style="max-width: 200px;"> </center>

    </header>

    <!-- Seção Introdução -->
    <section id="introducao">
      <h2 class="section-title">Introdução</h2>
      <div class="section-content">
        <p>Este script permite a geração de um QR Code PIX utilizando um endpoint específico. É ideal para aplicações que precisam de integração com pagamentos via PIX.</p>
      </div>
    </section>

    <!-- Seção Exemplo de Código -->
    <section id="codigo">
      <h2 class="section-title">Exemplo de Código</h2>
      <div class="section-content">
        <button class="btn btn-custom mb-3" onclick="copyToClipboard('code1')">Copiar Código</button>
        <div class="code-block" id="code1">
          &lt;?php
          $apiUrl = 'https://pixpay.fun/v3/pix/qrcode';
          $postData = [
          'client_id' => 'seu_client_id',
          'client_secret' => 'seu_client_secret',
          'nome' => 'Nome do Cliente',
          'cpf' => 'CPF do Cliente',
          'valor' => 100.00,
          'descricao' => 'Descrição do pagamento',
          'urlnoty' => 'https://seuservidor.com/callback'
          ];
          $ch = curl_init();
          curl_setopt($ch, CURLOPT_URL, $apiUrl);
          curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
          curl_setopt($ch, CURLOPT_POST, true);
          curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
          curl_setopt($ch, CURLOPT_HTTPHEADER, [
          'Content-Type: application/x-www-form-urlencoded',
          ]);
          $response = curl_exec($ch);
          if (curl_errno($ch)) {
          echo 'Erro cURL: ' . curl_error($ch);
          } else {
          echo 'Resposta do servidor: ' . $response; 
          }
          curl_close($ch);
          ?&gt;
        </div>
      </div>
    </section>

    <!-- Seção Parâmetros -->
    <section id="parametros">
      <h2 class="section-title">Parâmetros</h2>
      <div class="section-content">
        <table class="table table-striped table-bordered">
          <thead>
            <tr>
              <th>Parâmetro</th>
              <th>Descrição</th>
              <th>Exemplo</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>client_id</td>
              <td>Identificação do cliente</td>
              <td>"seu_client_id"</td>
            </tr>
            <tr>
              <td>client_secret</td>
              <td>Chave secreta do cliente</td>
              <td>"seu_client_secret"</td>
            </tr>
            <tr>
              <td>nome</td>
              <td>Nome do pagador</td>
              <td>"João da Silva"</td>
            </tr>
            <tr>
              <td>cpf</td>
              <td>CPF do pagador</td>
              <td>"12345678901"</td>
            </tr>
            <tr>
              <td>valor</td>
              <td>Valor da transação</td>
              <td>100.00</td>
            </tr>
            <tr>
              <td>descricao</td>
              <td>Descrição da transação</td>
              <td>"Pagamento de serviços"</td>
            </tr>
            <tr>
              <td>urlnoty</td>
              <td>URL para receber notificações de callback</td>
              <td>"https://seuservidor.com/callback"</td>
            </tr>
          </tbody>
        </table>
      </div>
    </section>

    <!-- Seção Respostas da API -->
    <section id="respostas">
      <h2 class="section-title">Respostas da API</h2>
      <div class="section-content">
        <div class="alert alert-success alert-custom">
          <strong>Exemplo de Resposta 200:</strong>
          <div class="code-block">
            {<br> 
            "transactionId": "4392d1d7e408d3cec04fm1zf3gv7vkq1",<br> 
            "external_id": "",<br> 
            "status": "PENDING",<br> 
            "amount": 15,<br> 
            "calendar": {<br> 
            "expiration": 3000,<br> 
            "dueDate": "2024-10-07 04:41:05"<br> 
            },<br> 
            "debtor": {<br> 
            "name": "Henrique Silva",<br> 
            "document": "12924586666"<br> 
            },<br> 
            "qrcode": "00020126850014br.gov.bcb.pix2563pix.voluti.com.br/qr/v3/at/6ed39bf2-bdc2-42b8-a95b-13d2212146b25204000053039865802BR5925PixPay PAYMENTS SOLUTIONS LTD6008SALVADOR62070503***63048D9B"<br> 
            }<br>
          </div>
        </div>
        <div class="alert alert-danger alert-custom">
          <strong>Exemplo de Resposta 401:</strong>
          <div class="code-block">
            {<br> 
            "statusCode": 401,<br> 
            "message": "Erro de autorização"<br> 
            }<br>
          </div>
        </div>
      </div>
    </section>
  </div>
</body>

  
  
  <div class="main-content">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg navbar-custom">
            <a class="navbar-brand text-white" href="#">Transferência PIX</a>
        </nav>

        <!-- Header -->
        <header>
            <h1>Documentação: Transferência PIX</h1>
            <p>Saiba como utilizar o script para realizar transferências via PIX em sua aplicação.</p>
        </header>

        <!-- Seção Introdução -->
        <section id="introducao1">
            <h2 class="section-title">Introdução</h2>
            <div class="section-content">
                <p>Este script permite a realização de uma transferência PIX entre contas utilizando um endpoint específico. Ideal para sistemas que necessitam de integração com a API PIX para realizar pagamentos e transferências.</p>
            </div>
        </section>

        <!-- Seção Exemplo de Código -->
        <section id="codigo1">
            <h2 class="section-title">Exemplo de Código</h2>
            <div class="section-content">
                <button class="btn btn-custom mb-3" onclick="copyToClipboard('code1')">Copiar Código</button>
                <div class="code-block" id="code1">
                    &lt;?php
                    $apiUrl = 'https://pixpay.fun/v3/pix/payment';

                    $postData = [
                        'client_id' => 'SEU CLIENT ID',
                        'client_secret' => 'SEU CLIENT SECRET',
                        'nome' => 'Nome do cliente',
                        'cpf' => 'Cpf do cliente',
                        'valor' => 1.00,
                        'chave_pix' => 'Chave pix Cliente',
                        'urlnoty' => 'https://seuservidor.com/callback'
                    ];

                    $ch = curl_init();

                    curl_setopt($ch, CURLOPT_URL, $apiUrl);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
                    curl_setopt($ch, CURLOPT_HTTPHEADER, [
                        'Content-Type: application/x-www-form-urlencoded',
                    ]);

                    $response = curl_exec($ch);

                    if (curl_errno($ch)) {
                        echo 'Erro cURL: ' . curl_error($ch);
                    } else {
                        echo 'Resposta do servidor: ' . $response;
                    }

                    curl_close($ch);
                    ?&gt;
                </div>
            </div>
        </section>

        <!-- Seção Parâmetros -->
        <section id="parametros1">
            <h2 class="section-title">Parâmetros</h2>
            <div class="section-content">
                <table class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>Parâmetro</th>
                            <th>Descrição</th>
                            <th>Exemplo</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>client_id</td>
                            <td>Identificação do cliente </td>
                            <td>"seu_client_id"</td>
                        </tr>
                        <tr>
                            <td>client_secret</td>
                            <td>Chave secreta do cliente </td>
                            <td>"seu_client_secret"</td>
                        </tr>
                        <tr>
                            <td>nome</td>
                            <td>Nome do pagador.</td>
                            <td>"cris"</td>
                        </tr>
                        <tr>
                            <td>cpf</td>
                            <td>CPF do pagador.</td>
                            <td>"11970142332"</td>
                        </tr>
                        <tr>
                            <td>valor</td>
                            <td>Valor da transferência.</td>
                            <td>1.00</td>
                        </tr>
                        <tr>
                            <td>chave_pix</td>
                            <td>Chave PIX do destinatário.</td>
                            <td>"chave@pix.com"</td>
                        </tr>
                        <tr>
                            <td>urlnoty</td>
                            <td>URL para receber notificações de callback.</td>
                            <td>"https://seuservidor.com/callback"</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </section>

        <!-- Seção Respostas da API -->
        <section id="respostas1">
            <h2 class="section-title">Respostas da API</h2>
            <div class="section-content">
                <div class="alert alert-success alert-custom">
                    <strong>Exemplo de Resposta 200:</strong>
                    <div class="code-block">[{"statusCode":200,"message":"Saque PIX processado com sucesso"}]</div>
                </div>
                <div class="alert alert-danger alert-custom">
                    <strong>Exemplo de Resposta 400:</strong>
                    <div class="code-block">{"statusCode":400,"message":"Saldo insuficiente para cobrir valor e taxas."}</div>
                </div>
            </div>
        </section>
        
        
        
        <section id="webhook">
            <h2 class="section-title">WEBHOOK-Evento de Pagamento</h2>
            <div class="section-content">
                <div class="alert alert-success alert-custom">
                    <strong>Será lhe enviado um alerta por meio de um Webhook assim que o pagamento for confirmado pelo nosso sistema, segue abaixo o modelo JSON do payload enviado:</strong>
                    <div class="code-block">{
    "requestBody": {
        "transactionType": "RECEIVEPIX",
        "transactionId": "c327ce8bee2a18565ec2m1zdu6px2keu",
        "external_id": "55aefd02e54e785fbb5a80faa19f8802",
        "amount": 15.00,
        "paymentType": "PIX",
        "status": "PAID",
        "dateApproval": "2024-10-07 16:07:10",
        "creditParty": {
            "name": "Henrique silva",
            "email": "billiPagamentos@gmail.com",
            "taxId": "999999999"
        },
        "debitParty": {
            "bank": "PixPay SOLUCOES DE PAGAMENTOS LTDA",
            "taxId": "46872831000154"
        }
    }
}</div>
                </div>
            </div>
        </section>
        
        <section id="webhook1">
            <h2 class="section-title">WEBHOOK-Evento de Transferência</h2>
            <div class="section-content">
                <div class="alert alert-success alert-custom">
                    <strong>Será lhe enviado um alerta por meio de um Webhook assim que o pagamento for confirmado pelo nosso sistema, segue abaixo o modelo JSON do payload enviado:</strong>
                    <div class="code-block">{
    "transactionType": "PAYMENT",
    "transactionId": "798176179",
    "external_id": "ebceb2b835598ccad73ce42eb5etrh2m5",
    "amount": 1,
    "dateApproval": "2024-12-19 17:10:54",
    "statusCode": {
        "statusId": 1,
        "description": "Pagamento aprovado"
    }
}</div>
                </div>
            </div>
        </section>
    </div>
  <footer>
    <p>&copy; 2024 Documentação Gateway PixPay <br></p>
  </footer> <!-- Bootstrap JS e dependências -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script> <!-- Script de copiar código -->
  <script>
    function copyToClipboard(id) {             const codeBlock = document.getElementById(id).innerText;             navigator.clipboard.writeText(codeBlock).then(() => {                 alert('Código copiado para a área de transferência!');             }).catch(err => {                 alert('Erro ao copiar código: ' + err);             });         }     
  </script>
</body>

</html>