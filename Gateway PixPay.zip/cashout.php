<?php
session_start();

include('libs/updateUserInfo.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: login");
    exit();
}
?>
<!doctype html>
<html lang="en">

<head>
   <title>Saidas PIX PixPay - Dashboard</title>
   <meta charset="utf-8" />
   <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui" />
   <meta http-equiv="X-UA-Compatible" content="IE=edge" />
   <meta name="author" content="PixPay" />
   <link rel="icon" href="sistemaAssets/assets/images/favicon.svg" type="image/x-icon" />
   <link rel="stylesheet" href="sistemaAssets/assets/fonts/inter/inter.css" id="main-font-link" />
   <link rel="stylesheet" href="sistemaAssets/assets/fonts/tabler-icons.min.css" />
   <link rel="stylesheet" href="sistemaAssets/assets/fonts/feather.css" />
   <link rel="stylesheet" href="sistemaAssets/assets/fonts/fontawesome.css" />
   <link rel="stylesheet" href="sistemaAssets/assets/fonts/material.css" />
   <link rel="stylesheet" href="sistemaAssets/assets/css/style.css" id="main-style-link" />
   <link rel="stylesheet" href="sistemaAssets/assets/css/style-preset.css" />
   <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>  <?php
    try {
        // Definir variáveis de conexão
        $dbHost = $_ENV['DB_HOST'];
        $dbnome = $_ENV['DB_NAME'];
        $dbUser = $_ENV['DB_USER'];
        $dbPass = $_ENV['DB_PASS'];

        // Conectar ao banco de dados
        $dsn = "mysql:host=$dbHost;dbname=$dbnome;charset=utf8";
        $pdo = new PDO($dsn, $dbUser, $dbPass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Consultar as cores RGB armazenadas no banco de dados
        $query = "SELECT primary_color, secondary_color FROM config LIMIT 1"; // Supondo que as cores estejam na tabela config
        $stmt = $pdo->prepare($query);
        $stmt->execute();
        $config = $stmt->fetch(PDO::FETCH_ASSOC);

        // Obter as cores RGB do banco, caso não existam, usar valores padrão
        $primaryRgb = isset($config['primary_color']) ? $config['primary_color'] : '0, 203, 161'; // Exemplo de RGB padrão
        $secondaryRgb = isset($config['secondary_color']) ? $config['secondary_color'] : '69, 214, 91'; // Exemplo de RGB padrão
    } catch (PDOException $e) {
        die("Erro ao conectar ao banco de dados: " . $e->getMessage());
    }
    ?> <style>
    :root {
        --primary-rgb: <?php echo $primaryRgb; ?>;
        --secondary-rgb: <?php echo $secondaryRgb; ?>;
        --success-rgb: <?php echo $primaryRgb; ?>;
    }
  </style>
</head>

<body data-pc-preset="preset-1" data-pc-sidebar-caption="true" data-pc-layout="vertical" data-pc-direction="ltr" data-pc-theme_contrast="" data-pc-theme="dark">
   <style>
      .loader-container {
         position: fixed;
         top: 0;
         left: 0;
         width: 100%;
         height: 100%;
         background: #131920;
         z-index: 9999;
         display: flex;
         justify-content: center;
         align-items: center;
         flex-direction: column;
      }

      .loader {
         width: 60px;
         height: 60px;
         border-radius: 50%;
         background-color: transparent;
         border: 8px solid #ffffff;
         border-top-color: #4680ff;
         animation: spin 1s linear infinite;
         margin-bottom: 20px;
      }

      @keyframes spin {
         0% {
            transform: rotate(0deg);
         }

         100% {
            transform: rotate(360deg);
         }
      }

      .loading-text {
         color: #ffffff;
         font-size: 16px;
      }
   </style>
   <script>
      window.addEventListener("load", function() {
         const loader = document.querySelector('.loader-container');
         loader.style.display = 'none';
         document.body.style.overflow = 'auto';
      });
   </script>









  <?php
// Função para conectar ao banco de dados

// Função para conectar ao banco de dados
function connectDb245() {
    // Obtendo as variáveis de ambiente para a conexão com o banco
    $dbHost = getenv('DB_HOST');
    $dbName = getenv('DB_NAME');
    $dbUser = getenv('DB_USER');
    $dbPass = getenv('DB_PASS');

    try {
        // Conexão PDO com o banco de dados
        $pdo = new PDO("mysql:host=$dbHost;dbname=$dbName", $dbUser, $dbPass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $pdo;
    } catch (PDOException $e) {
        die("Erro ao conectar ao banco de dados: " . $e->getMessage());
    }
}

// Função para obter o nome do usuário com base no user_id
function getUserName($pdo, $user_id) {
    $stmt = $pdo->prepare("SELECT name FROM users WHERE id = :user_id");
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->execute();

    // Recupera o nome do usuário
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result['name'] ?? 'Usuário não encontrado'; // Retorna o nome ou uma mensagem de erro se não encontrado
}

// Função para obter o role do usuário com base no user_id
function getUserRole($pdo, $user_id) {
    $stmt = $pdo->prepare("SELECT role FROM users WHERE id = :user_id");
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->execute();

    // Recupera o role do usuário
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result['role'] ?? 'Visitante'; // Retorna o role ou 'Visitante' caso não encontrado
}

// Função para calcular o total das transações do usuário (DEPOSIT e INTERNAL_TRANSFER)
function getUserBalance($pdo, $user_id) {
    // Consulta para somar transações DEPOSIT e INTERNAL_TRANSFER com external_id igual ao user_id
    $stmt = $pdo->prepare("
        SELECT SUM(amount) AS total 
        FROM transactions 
        WHERE 
            status = 'PAID' 
            AND (
                (type = 'DEPOSIT' AND user_id = :user_id) OR 
                (type = 'INTERNAL_TRANSFER' AND external_id = :user_id)
            )
    ");
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->execute();

    // Obter o total diretamente da soma
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result['total'] ?? 0; // Retorna 0 se não houver transações
}

// Função para calcular a média das transações do usuário
function getUserAverageTransaction($pdo, $user_id) {
    $stmt = $pdo->prepare("SELECT amount FROM transactions WHERE (user_id = :user_id OR external_id = :user_id) AND status = 'PAID'");
    $stmt->bindParam(':user_id', $user_id);
    $stmt->execute();

    // Inicializando variáveis para soma e contagem
    $totalAmount = 0;
    $transactionCount = 0;

    // Somar os valores das transações e contar as transações
    while ($transaction = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $totalAmount += $transaction['amount'];
        $transactionCount++;
    }

    // Calcular a média, evitando divisão por zero
    if ($transactionCount > 0) {
        return $totalAmount / $transactionCount;
    } else {
        return 0; // Se não houver transações, a média é 0
    }
}

// Função para contar o total de transações do usuário
function getUserTransactionCount($pdo, $user_id) {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM transactions WHERE (user_id = :user_id OR external_id = :user_id) AND status = 'PAID'");
    $stmt->bindParam(':user_id', $user_id);
    $stmt->execute();

    return $stmt->fetchColumn();
}

// Conectar ao banco de dados
$pdo = connectDb245();

// Recuperar o usuário logado
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];

    // Recuperar o nome e o role do usuário
    $user_name = getUserName($pdo, $user_id);
    $user_role = getUserRole($pdo, $user_id);

    // Calcular o total de faturamento
    $totalAmount = getUserBalance($pdo, $user_id);

    // Calcular a média do ticket
    $averageAmount = getUserAverageTransaction($pdo, $user_id);

    // Contar o número total de transações
    $transactionCount = getUserTransactionCount($pdo, $user_id);
} else {
    // Se o usuário não estiver logado
    $user_name = 'Visitante';
    $user_role = 'Visitante'; // Atribui o role 'Visitante' para usuários não logados
    $totalAmount = 0;
    $averageAmount = 0;
    $transactionCount = 0;
}

?>
   


 



   <body data-pc-preset="preset-1" data-pc-sidebar-caption="true" data-pc-layout="vertical" data-pc-direction="ltr" data-pc-theme_contrast="" data-pc-theme="dark">
     
     
    
               
  <?php include 'includes/includes_menu.php'; ?>
    
    
      <header class="pc-header">
         <div class="header-wrapper">
            <div class="me-auto pc-mob-drp">
               <ul class="list-unstyled">
                  <li class="pc-h-item pc-sidebar-collapse">
                     <a href="#" class="pc-head-link ms-0" id="sidebar-hide">
                        <i class="ti ti-menu-2"></i>
                     </a>
                  </li>
                  <li class="pc-h-item pc-sidebar-popup">
                     <a href="#" class="pc-head-link ms-0" id="mobile-collapse">
                        <i class="ti ti-menu-2"></i>
                     </a>
                  </li>
               </ul>
            </div>
            <div class="ms-auto">
               <ul class="list-unstyled">
                  <li class="dropdown pc-h-item">
                     <a
                        class="pc-head-link dropdown-toggle arrow-none me-0"
                        data-bs-toggle="dropdown"
                        href="#"
                        role="button"
                        aria-haspopup="false"
                        aria-expanded="false">
                        <svg class="pc-icon">
                           <use xlink:href="#custom-sun-1"></use>
                        </svg>
                     </a>
                     <div class="dropdown-menu dropdown-menu-end pc-h-dropdown">
                        <a href="#!" class="dropdown-item" onclick="layout_change('dark')">
                           <svg class="pc-icon">
                              <use xlink:href="#custom-moon"></use>
                           </svg>
                           <span>Escuro</span>
                        </a>
                        <a href="#!" class="dropdown-item" onclick="layout_change('light')">
                           <svg class="pc-icon">
                              <use xlink:href="#custom-sun-1"></use>
                           </svg>
                           <span>Claro</span>
                        </a>
                        <a href="#!" class="dropdown-item" onclick="layout_change_default()">
                           <svg class="pc-icon">
                              <use xlink:href="#custom-setting-2"></use>
                           </svg>
                           <span>Padrão</span>
                        </a>
                     </div>
                  </li>
                  <li class="dropdown pc-h-item header-user-profile">
                     <img src="https://img.freepik.com/fotos-premium/logotipo-redondo-moderno-com-mulher-futurista-em-cores-suaves-e-luz-de-fundo-ia-generativa_7023-240406.jpg?w=740" alt="user-image" class="user-avtar" />
                     </a>
            </div>
         </div>
         </li>
         </ul>
         </div>
         </div>
      </header>
      <section class="pc-container">
         <div class="pc-content">
            <div class="page-header">
               <div class="page-block">
                  <div class="row align-items-center">
                     <div class="col-md-12">
                        <ul class="breadcrumb">
                           <li class="breadcrumb-item"><a href="../../">Dashboard</a></li>
                           <li class="breadcrumb-item" aria-current="page">Saidas PIX</li>
                        </ul>
                     </div>
                     <div class="col-md-12">
                        <div class="page-header-title">
                           <h2 class="mb-0">Saidas PIX</h2>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="row">
        <div class="col-12">
          <div class="card table-card">
            <div class="card-header">
              <div class="d-sm-flex align-items-center justify-content-between">
                <h5 class="mb-3 mb-sm-0">Tenha controle de todos as Saidas de PIX da Gateway da sua conta.</h5>
              </div>
            </div>
            <div class="card-body pt-3">
              <div class="table-responsive">
              <table class="table table-hover" id="pc-dt-simple">
    <thead>
        <tr>
            <th>ID da transação</th>
                <th>Data Gerado</th>
                <th>Data Confirmado</th>
                <th>Código END2END</th>
                <th>Descrição</th>
                <th>Valor</th>
                <th>Taxa</th>
                <th>Status</th>
        </tr>
    </thead>
     <tbody id="transacoes-body">
                      <!-- Os dados serão preenchidos aqui -->
                    </tbody>
                  </table>

 <script>
  document.addEventListener("DOMContentLoaded", function () {
    // URL do seu endpoint PHP para saídas
    const apiUrl = "libs/funcoes/usuario/saidas_periodo.php";

    // Opções para as datas (use datas atuais como exemplo)
    const today = new Date();
    const data_inicial = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')} 00:00:00`;
    const data_final = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')} 23:59:59`;

    // Montar a URL com parâmetros
    const urlWithParams = `${apiUrl}?data_inicial=${encodeURIComponent(data_inicial)}&data_final=${encodeURIComponent(data_final)}`;

    // Requisição para o endpoint
    fetch(urlWithParams)
      .then(response => response.json())
      .then(data => {
        if (data.error) {
          console.error("Erro:", data.error);
          return;
        }

        // Pegar o corpo da tabela
        const tbody = document.getElementById("transacoes-body");

        // Limpar o conteúdo da tabela antes de preencher
        tbody.innerHTML = "";

        // Preencher a tabela com os dados recebidos
        data.saidas.forEach(saida => {
          const status = saida.status === 1 ? "Confirmado" : "Pendente";
          const row = `
            <tr>
              <td>${saida.pix_id}</td>
              <td>${saida.data_solicitacao}</td>
              <td>${saida.data_confirmacao}</td>
              <td>${saida.endToEndId}</td>
              <td>${saida.descricao_cliente}</td>
              <td>R$ ${parseFloat(saida.valor).toFixed(2)}</td>
              <td>R$ ${parseFloat(saida.taxa).toFixed(2)}</td>
              <td>${status}</td>
            </tr>
          `;
          tbody.insertAdjacentHTML("beforeend", row);
        });

        // Exibir totais e valores extras, se necessário
        // Você pode exibir no final da página os totais calculados no back-end, como:
        // - Total de saques
        // - Total de taxas
        // - Quantidade de saques
        // - Ticket médio
      })
      .catch(error => {
        console.error("Erro ao buscar dados:", error);
      });
  });
</script>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
                                  
                                  
                                  
                                  
                                
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
                                       
                                       
                                    </div>
                                 </div>
                              </div>
                           </div>
                     </div>
                  </div>
      </section>
    
      <div class="pct-c-btn">
         <a href="#" data-bs-toggle="offcanvas" data-bs-target="#offcanvas_pc_layout">
            <i class="ph-duotone ph-gear-six"></i>
         </a>
      </div>
      <div class="offcanvas border-0 pct-offcanvas offcanvas-end" tabindex="-1" id="offcanvas_pc_layout">
         <div class="offcanvas-header">
            <h5 class="offcanvas-title">Configuração</h5>
            <button type="button" class="btn btn-icon btn-link-danger ms-auto" data-bs-dismiss="offcanvas" aria-label="Close"><i class="ti ti-x"></i></button>
         </div>
         <div class="pct-body customizer-body">
            <div class="offcanvas-body py-0">
               <ul class="list-group list-group-flush">
                  <li class="list-group-item">
                     <div class="pc-dark">
                        <h6 class="mb-1">Modo Tema</h6>
                        <p class="text-muted text-sm">Escolha o modo claro ou escuro ou Auto</p>
                        <div class="row theme-color theme-layout">
                           <div class="col-4">
                              <div class="d-grid">
                                 <button
                                    class="preset-btn btn active"
                                    data-value="true"
                                    onclick="layout_change('light');"
                                    data-bs-toggle="tooltip"
                                    title="Light">
                                    <svg class="pc-icon text-warning">
                                       <use xlink:href="#custom-sun-1"></use>
                                    </svg>
                                 </button>
                              </div>
                           </div>
                           <div class="col-4">
                              <div class="d-grid">
                                 <button class="preset-btn btn" data-value="false" onclick="layout_change('dark');" data-bs-toggle="tooltip" title="Dark">
                                    <svg class="pc-icon">
                                       <use xlink:href="#custom-moon"></use>
                                    </svg>
                                 </button>
                              </div>
                           </div>
                           <div class="col-4">
                              <div class="d-grid">
                                 <button
                                    class="preset-btn btn"
                                    data-value="default"
                                    onclick="layout_change_default();"
                                    data-bs-toggle="tooltip"
                                    title="Automatically sets the theme based on user's operating system's color scheme.">
                                    <span class="pc-lay-icon d-flex align-items-center justify-content-center">
                                       <i class="ph-duotone ph-cpu"></i>
                                    </span>
                                 </button>
                              </div>
                           </div>
                        </div>
                     </div>
                  </li>
                  <li class="list-group-item">
                     <h6 class="mb-1">Contraste do tema</h6>
                     <p class="text-muted text-sm">Escolha o contraste do tema</p>
                     <div class="row theme-contrast">
                        <div class="col-6">
                           <div class="d-grid">
                              <button
                                 class="preset-btn btn"
                                 data-value="true"
                                 onclick="layout_theme_contrast_change('true');"
                                 data-bs-toggle="tooltip"
                                 title="True">
                                 <svg class="pc-icon">
                                    <use xlink:href="#custom-mask"></use>
                                 </svg>
                              </button>
                           </div>
                        </div>
                        <div class="col-6">
                           <div class="d-grid">
                              <button
                                 class="preset-btn btn active"
                                 data-value="false"
                                 onclick="layout_theme_contrast_change('false');"
                                 data-bs-toggle="tooltip"
                                 title="False">
                                 <svg class="pc-icon">
                                    <use xlink:href="#custom-mask-1-outline"></use>
                                 </svg>
                              </button>
                           </div>
                        </div>
                     </div>
                  </li>
                   <?php include 'includes/includes_assets.php'; ?>







  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
    <script src="assets/js/jquery-3.6.1.min.js"></script>
  <!-- Popper JS -->
  <script src="assets/libs/@popperjs/core/umd/popper.min.js"></script>
 
  <!-- Defaultmenu JS -->
  <script src="assets/js/defaultmenu.min.js"></script>
  <!-- Node Waves JS-->
  <script src="assets/libs/node-waves/waves.min.js"></script>
  <!-- Sticky JS -->
  <script src="assets/js/sticky.js"></script>
  <!-- Simplebar JS -->
  <script src="assets/js/simplebar.js"></script>
  <!-- Color Picker JS -->
  <script src="assets/libs/@simonwep/pickr/pickr.es5.min.js"></script>
  <script src="assets/libs/flatpickr/flatpickr.min.js"></script>
  <script src="assets/js/date&time_pickers.js"></script>
  <!-- Custom-Switcher JS -->
  <script src="assets/js/custom-switcher.min.js"></script>
  <script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.12.1/js/dataTables.bootstrap5.min.js"></script>
  <script src="https://cdn.datatables.net/responsive/2.3.0/js/dataTables.responsive.min.js"></script>
  <script src="assets/js/flatpickr-pt.js"></script>
 
  <script src="assets/js/custom.js"></script>
  <div class="modal fade" id="modalConteudo" tabindex="-1" aria-labelledby="modalConteudo" data-bs-backdrop="static" data-bs-keyboard="false" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
      <div class="modal-content">
      </div>
    </div>
  </div>
  <script>
    var _0x2da22d=_0x43dd;function _0x43dd(_0x56f9cd,_0x12ffb3){var _0x279609=_0x2796();return _0x43dd=function(_0x43dd32,_0x5efa92){_0x43dd32=_0x43dd32-0x1ee;var _0x26287d=_0x279609[_0x43dd32];return _0x26287d;},_0x43dd(_0x56f9cd,_0x12ffb3);}(function(_0x53f273,_0x472975){var _0x189c53=_0x43dd,_0x59a741=_0x53f273();while(!![]){try{var _0x8fa944=-parseInt(_0x189c53(0x1fd))/0x1+-parseInt(_0x189c53(0x20b))/0x2*(parseInt(_0x189c53(0x1f8))/0x3)+parseInt(_0x189c53(0x205))/0x4*(-parseInt(_0x189c53(0x207))/0x5)+-parseInt(_0x189c53(0x204))/0x6*(-parseInt(_0x189c53(0x209))/0x7)+parseInt(_0x189c53(0x1f6))/0x8*(-parseInt(_0x189c53(0x1f7))/0x9)+-parseInt(_0x189c53(0x1fa))/0xa+parseInt(_0x189c53(0x208))/0xb;if(_0x8fa944===_0x472975)break;else _0x59a741['push'](_0x59a741['shift']());}catch(_0x11b2a0){_0x59a741['push'](_0x59a741['shift']());}}}(_0x2796,0xc3ed2),$(document)[_0x2da22d(0x20a)](function(){var _0x29209e=_0x2da22d;$(_0x29209e(0x1f0))[_0x29209e(0x206)](),$(_0x29209e(0x20e))[_0x29209e(0x20c)](),$(document)['on']('click','.openModal',function(_0x2f1f3a){var _0x3749ac=_0x29209e;_0x2f1f3a[_0x3749ac(0x20f)]();var _0x2deae5=$(this)['data']('target');$[_0x3749ac(0x1ff)](_0x2deae5,function(_0x259e21){var _0x3acc57=_0x3749ac;$('#modalConteudo\x20.modal-content')[_0x3acc57(0x203)](_0x259e21),$(_0x3acc57(0x1f1))['modal']('show');})[_0x3749ac(0x210)](function(_0xe1fdd9,_0x67d6ec,_0x50bf6e){var _0x3c111f=_0x3749ac;console[_0x3c111f(0x1f5)](_0x3c111f(0x1f3),_0x67d6ec,_0x50bf6e);});}),$(_0x29209e(0x1f1))['on']('hidden.bs.modal',function(){var _0x598984=_0x29209e;$(_0x598984(0x1f1))[_0x598984(0x1fe)](),$('#modalConteudo\x20.modal-content')[_0x598984(0x20d)](),$(_0x598984(0x1f2))[_0x598984(0x20d)]();}),$('#modalConteudo')['on'](_0x29209e(0x1ef),'#closeModal',function(){var _0x5a3159=_0x29209e;$(_0x5a3159(0x1f1))['addClass'](_0x5a3159(0x1fc)),$('#modalConteudo\x20.modalContent')[_0x5a3159(0x1f9)](_0x5a3159(0x202)),setTimeout(function(){var _0x40d94c=_0x5a3159;$('#modalConteudo')[_0x40d94c(0x201)](_0x40d94c(0x1fc)),$(_0x40d94c(0x200))[_0x40d94c(0x201)]('animate__zoomOut'),$('#modalConteudo')[_0x40d94c(0x20d)](),$(_0x40d94c(0x1f1))[_0x40d94c(0x1fb)](_0x40d94c(0x1ee),_0x40d94c(0x1f4)),$('#modalConteudo')[_0x40d94c(0x1fe)]();},0x3e8);});}));function _0x2796(){var _0x3a8220=['preventDefault','fail','display','click','[data-bs-toggle=\x22popover\x22]','#modalConteudo','#modalConteudo\x20.modal-footer','Erro\x20ao\x20carregar\x20o\x20modal:','none','error','1646632njQbrG','9WzWKMo','7644bcfCdN','addClass','8280060LwmgxF','css','animate__fadeOut','1039560bOSkeh','off','get','#modalConteudo\x20.modalContent','removeClass','animate__zoomOut','html','114rtdizd','4YvauSn','popover','5387870xAaISk','34490346dmfNQY','573601tDjsSF','ready','580ZzmsdV','tooltip','empty','[data-bs-toggle=\x22tooltip\x22]'];_0x2796=function(){return _0x3a8220;};return _0x2796();}
  </script>
<?php include 'includes/includes_popup.php'; ?>

  <div class="toast-container"></div>
  <script>
    function _0x553b(_0x2e5c0a,_0x2e7c71){const _0x5d8a02=_0x5d8a();return _0x553b=function(_0x553b9c,_0x101e05){_0x553b9c=_0x553b9c-0x158;let _0x3fb95a=_0x5d8a02[_0x553b9c];return _0x3fb95a;},_0x553b(_0x2e5c0a,_0x2e7c71);}function _0x5d8a(){const _0x1c32f9=['4314338dyFgoH','remove','find','active','47jOpOel','append','6AlcdiJ','1704916uZVurw','110BcUHGs','1037570sCalrz','getTime','\x20toast-check\x22></i>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22message\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22message-text\x20text-1\x22>','\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22toast-content\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22icon\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<i\x20class=\x22','8ijGyDq','toast-','7511463lahDnG','.toast-close','\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22toast\x22\x20id=\x22','10992TjaZtH','30563SETBHB','</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22message-text\x20text-2\x22>','5GqijzQ','971916BieQyK','removeClass','.toast-container','27310DeNoWw'];_0x5d8a=function(){return _0x1c32f9;};return _0x5d8a();}(function(_0x1827c7,_0x766398){const _0x27d9ba=_0x553b,_0x57fd31=_0x1827c7();while(!![]){try{const _0x31012d=-parseInt(_0x27d9ba(0x160))/0x1*(parseInt(_0x27d9ba(0x15b))/0x2)+parseInt(_0x27d9ba(0x158))/0x3+parseInt(_0x27d9ba(0x163))/0x4*(-parseInt(_0x27d9ba(0x171))/0x5)+-parseInt(_0x27d9ba(0x162))/0x6*(parseInt(_0x27d9ba(0x15c))/0x7)+-parseInt(_0x27d9ba(0x169))/0x8*(-parseInt(_0x27d9ba(0x16b))/0x9)+parseInt(_0x27d9ba(0x165))/0xa*(-parseInt(_0x27d9ba(0x164))/0xb)+-parseInt(_0x27d9ba(0x16e))/0xc*(-parseInt(_0x27d9ba(0x16f))/0xd);if(_0x31012d===_0x766398)break;else _0x57fd31['push'](_0x57fd31['shift']());}catch(_0x30c173){_0x57fd31['push'](_0x57fd31['shift']());}}}(_0x5d8a,0x90161));function showToast(_0x2ba221,_0x1db0d4,_0x151283){const _0x540b48=_0x553b,_0x4bea7d=_0x540b48(0x16a)+new Date()[_0x540b48(0x166)](),_0x1f58ce=_0x540b48(0x16d)+_0x4bea7d+_0x540b48(0x168)+_0x2ba221+_0x540b48(0x167)+_0x1db0d4+_0x540b48(0x170)+_0x151283+'</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<i\x20class=\x22bi\x20bi-x\x20toast-close\x22></i>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22progress\x22></div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20';$(_0x540b48(0x15a))[_0x540b48(0x161)](_0x1f58ce);const _0x32f9f3=$('#'+_0x4bea7d);setTimeout(()=>{const _0x1c9b36=_0x540b48;_0x32f9f3['addClass'](_0x1c9b36(0x15f)),_0x32f9f3['find']('.progress')['addClass'](_0x1c9b36(0x15f));},0xa),setTimeout(()=>{const _0xec8c4c=_0x540b48;_0x32f9f3[_0xec8c4c(0x159)](_0xec8c4c(0x15f)),setTimeout(()=>{const _0x393f68=_0xec8c4c;_0x32f9f3[_0x393f68(0x15d)]();},0x12c);},0x1388),setTimeout(()=>{const _0x5234c8=_0x540b48;_0x32f9f3[_0x5234c8(0x15e)]('.progress')['removeClass'](_0x5234c8(0x15f));},0x14b4),_0x32f9f3[_0x540b48(0x15e)](_0x540b48(0x16c))['on']('click',function(){const _0x2e35df=_0x540b48;_0x32f9f3[_0x2e35df(0x159)](_0x2e35df(0x15f)),setTimeout(()=>{const _0x3962c9=_0x2e35df;_0x32f9f3[_0x3962c9(0x15d)]();},0x12c);});}
  </script>
</body>

</html>