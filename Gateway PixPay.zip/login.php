<?php
session_start();

if (isset($_SESSION['user_id'])) {
    header("Location: /");
    exit();
}
?>
<html lang="pt-br" dir="ltr" data-nav-layout="horizontal" data-theme-mode="light" data-header-styles="light" data-menu-styles="light" data-toggled="close">

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">


    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title> <?php include 'libs/get_site_name.php'; ?> - Login </title>

    <meta name="Description" content="Dashboard principal do gateway de pagamento <?php include 'libs/get_site_name.php'; ?>">

    <meta name="Author" content="PixPay">

	<meta name="keywords" content="Gateway de pagamento">

    <link rel="icon" href="/imagens/logoo.png" type="image/x-icon">

    <script src="assets/js/authentication-main.js"></script>

    <link id="style" href="assets/libs/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <?php include 'libs/config_css.php'; ?>

    <link href="assets/css/icons.css" rel="stylesheet">

    <?php
    try {
        // Definir variáveis de conexão
        $dbHost = $_ENV['DB_HOST'];
        $dbnome = $_ENV['DB_NAME'];
        $dbUser = $_ENV['DB_USER'];
        $dbPass = $_ENV['DB_PASS'];

        // Conectar ao banco de dados
        $dsn = "mysql:host=$dbHost;dbname=$dbnome;charset=utf8";
        $pdo = new PDO($dsn, $dbUser, $dbPass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        
    } catch (PDOException $e) {
        die("Erro ao conectar ao banco de dados: " . $e->getMessage());
    }
    ?>

    
    
     <style>
    
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    body {
        font-family: Arial, sans-serif;
        background-color: #121212;  /* Cor de fundo escura */
        color: #e0e0e0;  /* Cor do texto clara */
        display: flex;
        align-items: center;
        justify-content: center;
        height: 100vh;
        margin: 0;
    }

    .login-wrapper {
        display: flex;
        flex-direction: column;
        width: 100%;
        max-width: 900px;
        height: 500px;
        background: #1e1e1e;  /* Fundo mais escuro */
        box-shadow: 0 8px 20px rgba(0, 0, 0, 0.4);  /* Sombra mais forte */
        border-radius: 10px;
        overflow: hidden;
    }

    .login-image {
        width: 100%;
        height: 50%;
        background: url('imagens/log.png') no-repeat center center/cover;
    }

    .login-form {
        width: 100%;
        padding: 40px 30px;
        display: flex;
        flex-direction: column;
        justify-content: center;
    }

    .login-form h1 {
        font-size: 28px;
        margin-bottom: 20px;
        color: #ffffff;  /* Cor do título em branco */
    }

    .login-form p {
        font-size: 14px;
        margin-bottom: 30px;
        color: #cccccc;  /* Cor do texto mais suave */
    }

    .login-form input {
        width: 100%;
        padding: 12px 15px;
        margin: 10px 0;
        border: 1px solid #444;  /* Cor mais escura para a borda */
        border-radius: 5px;
        font-size: 16px;
        background-color: #333;  /* Cor de fundo dos campos */
        color: #e0e0e0;  /* Cor do texto nos campos */
    }

    .login-form input[type="submit"] {
        background-color: rgb(var(--primary-rgb));
        color: white;
        border: none;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    .login-form input[type="submit"]:hover {
        background-color: rgb(var(--secondary-rgb));
    }

    .login-form a {
        text-decoration: none;
        color: rgb(var(--primary-rgb));
        font-size: 14px;
        margin-top: 15px;
        text-align: center;
    }

    .login-form a:hover {
        text-decoration: underline;
    }

    @media screen and (max-width: 768px) {
        .login-wrapper {
            flex-direction: column;
            width: 100%;
            height: auto;
        }

        .login-image {
            height: 200px;
        }
    }
</style>

    <script>
        function togglePasswordVisibility(inputId, button) {
            const input = document.getElementById(inputId);
            const isPassword = input.type === 'password';
            input.type = isPassword ? 'text' : 'password';
            button.innerHTML = isPassword ? '<i class="ri-eye-line"></i>' : '<i class="ri-eye-off-line"></i>';
        }
    </script>
    
    
    
     
    
    
    
</head>

<body>
    <div class="login-wrapper">
        <div class="login-image"></div>
        <div class="login-form">
            <h1>Bem-vindo de volta! 🎉</h1>
            <p>Faça login na sua conta para acessar o Painel <?php include 'libs/get_site_name.php'; ?>. 🚀</p>
            <form action="login.php" method="POST">
                <label for="usuario" class="form-label">Usuário</label>
                <input type="text" name="usuario" id="usuario" placeholder="Usuário" required />

                <label for="senha" class="form-label">Senha</label>
                <div style="position: relative;">
                    <input type="password" name="senha" id="senha" placeholder="Senha" required />
                    <button type="button" onclick="togglePasswordVisibility('senha', this)" style="position: absolute; right: 10px; top: 50%; transform: translateY(-50%); border: none; background: transparent; cursor: pointer;">
                        <i class="ri-eye-off-line"></i>
                    </button>
                </div>
<a href="#">Esqueceu sua senha?</a>
                <input type="submit" id="login-button" value="Entrar" />
            </form>
            <a href="register">Regisre-se agora mesmo!</a>
        </div>
    </div>
</body>

</html>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <div class="modal fade" id="modalConteudo" tabindex="-1" aria-labelledby="modalConteudo" data-bs-backdrop="static" data-bs-keyboard="false" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">
        </div>
    </div>
</div>
<script>
    var _0x2da22d=_0x43dd;function _0x43dd(_0x56f9cd,_0x12ffb3){var _0x279609=_0x2796();return _0x43dd=function(_0x43dd32,_0x5efa92){_0x43dd32=_0x43dd32-0x1ee;var _0x26287d=_0x279609[_0x43dd32];return _0x26287d;},_0x43dd(_0x56f9cd,_0x12ffb3);}(function(_0x53f273,_0x472975){var _0x189c53=_0x43dd,_0x59a741=_0x53f273();while(!![]){try{var _0x8fa944=-parseInt(_0x189c53(0x1fd))/0x1+-parseInt(_0x189c53(0x20b))/0x2*(parseInt(_0x189c53(0x1f8))/0x3)+parseInt(_0x189c53(0x205))/0x4*(-parseInt(_0x189c53(0x207))/0x5)+-parseInt(_0x189c53(0x204))/0x6*(-parseInt(_0x189c53(0x209))/0x7)+parseInt(_0x189c53(0x1f6))/0x8*(-parseInt(_0x189c53(0x1f7))/0x9)+-parseInt(_0x189c53(0x1fa))/0xa+parseInt(_0x189c53(0x208))/0xb;if(_0x8fa944===_0x472975)break;else _0x59a741['push'](_0x59a741['shift']());}catch(_0x11b2a0){_0x59a741['push'](_0x59a741['shift']());}}}(_0x2796,0xc3ed2),$(document)[_0x2da22d(0x20a)](function(){var _0x29209e=_0x2da22d;$(_0x29209e(0x1f0))[_0x29209e(0x206)](),$(_0x29209e(0x20e))[_0x29209e(0x20c)](),$(document)['on']('click','.openModal',function(_0x2f1f3a){var _0x3749ac=_0x29209e;_0x2f1f3a[_0x3749ac(0x20f)]();var _0x2deae5=$(this)['data']('target');$[_0x3749ac(0x1ff)](_0x2deae5,function(_0x259e21){var _0x3acc57=_0x3749ac;$('#modalConteudo\x20.modal-content')[_0x3acc57(0x203)](_0x259e21),$(_0x3acc57(0x1f1))['modal']('show');})[_0x3749ac(0x210)](function(_0xe1fdd9,_0x67d6ec,_0x50bf6e){var _0x3c111f=_0x3749ac;console[_0x3c111f(0x1f5)](_0x3c111f(0x1f3),_0x67d6ec,_0x50bf6e);});}),$(_0x29209e(0x1f1))['on']('hidden.bs.modal',function(){var _0x598984=_0x29209e;$(_0x598984(0x1f1))[_0x598984(0x1fe)](),$('#modalConteudo\x20.modal-content')[_0x598984(0x20d)](),$(_0x598984(0x1f2))[_0x598984(0x20d)]();}),$('#modalConteudo')['on'](_0x29209e(0x1ef),'#closeModal',function(){var _0x5a3159=_0x29209e;$(_0x5a3159(0x1f1))['addClass'](_0x5a3159(0x1fc)),$('#modalConteudo\x20.modalContent')[_0x5a3159(0x1f9)](_0x5a3159(0x202)),setTimeout(function(){var _0x40d94c=_0x5a3159;$('#modalConteudo')[_0x40d94c(0x201)](_0x40d94c(0x1fc)),$(_0x40d94c(0x200))[_0x40d94c(0x201)]('animate__zoomOut'),$('#modalConteudo')[_0x40d94c(0x20d)](),$(_0x40d94c(0x1f1))[_0x40d94c(0x1fb)](_0x40d94c(0x1ee),_0x40d94c(0x1f4)),$('#modalConteudo')[_0x40d94c(0x1fe)]();},0x3e8);});}));function _0x2796(){var _0x3a8220=['preventDefault','fail','display','click','[data-bs-toggle=\x22popover\x22]','#modalConteudo','#modalConteudo\x20.modal-footer','Erro\x20ao\x20carregar\x20o\x20modal:','none','error','1646632njQbrG','9WzWKMo','7644bcfCdN','addClass','8280060LwmgxF','css','animate__fadeOut','1039560bOSkeh','off','get','#modalConteudo\x20.modalContent','removeClass','animate__zoomOut','html','114rtdizd','4YvauSn','popover','5387870xAaISk','34490346dmfNQY','573601tDjsSF','ready','580ZzmsdV','tooltip','empty','[data-bs-toggle=\x22tooltip\x22]'];_0x2796=function(){return _0x3a8220;};return _0x2796();}
</script>
    <script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>

    <script src="assets/libs/swiper/swiper-bundle.min.js"></script>

    <script src="assets/js/show-password.js"></script>

<?php include 'includes/includes_popup.php'; ?>

<div class="toast-container">
            
        
            
        
            
        
            
        </div>
<script>
    function _0x553b(_0x2e5c0a,_0x2e7c71){const _0x5d8a02=_0x5d8a();return _0x553b=function(_0x553b9c,_0x101e05){_0x553b9c=_0x553b9c-0x158;let _0x3fb95a=_0x5d8a02[_0x553b9c];return _0x3fb95a;},_0x553b(_0x2e5c0a,_0x2e7c71);}function _0x5d8a(){const _0x1c32f9=['4314338dyFgoH','remove','find','active','47jOpOel','append','6AlcdiJ','1704916uZVurw','110BcUHGs','1037570sCalrz','getTime','\x20toast-check\x22></i>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22message\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22message-text\x20text-1\x22>','\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22toast-content\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22icon\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<i\x20class=\x22','8ijGyDq','toast-','7511463lahDnG','.toast-close','\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22toast\x22\x20id=\x22','10992TjaZtH','30563SETBHB','</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22message-text\x20text-2\x22>','5GqijzQ','971916BieQyK','removeClass','.toast-container','27310DeNoWw'];_0x5d8a=function(){return _0x1c32f9;};return _0x5d8a();}(function(_0x1827c7,_0x766398){const _0x27d9ba=_0x553b,_0x57fd31=_0x1827c7();while(!![]){try{const _0x31012d=-parseInt(_0x27d9ba(0x160))/0x1*(parseInt(_0x27d9ba(0x15b))/0x2)+parseInt(_0x27d9ba(0x158))/0x3+parseInt(_0x27d9ba(0x163))/0x4*(-parseInt(_0x27d9ba(0x171))/0x5)+-parseInt(_0x27d9ba(0x162))/0x6*(parseInt(_0x27d9ba(0x15c))/0x7)+-parseInt(_0x27d9ba(0x169))/0x8*(-parseInt(_0x27d9ba(0x16b))/0x9)+parseInt(_0x27d9ba(0x165))/0xa*(-parseInt(_0x27d9ba(0x164))/0xb)+-parseInt(_0x27d9ba(0x16e))/0xc*(-parseInt(_0x27d9ba(0x16f))/0xd);if(_0x31012d===_0x766398)break;else _0x57fd31['push'](_0x57fd31['shift']());}catch(_0x30c173){_0x57fd31['push'](_0x57fd31['shift']());}}}(_0x5d8a,0x90161));function showToast(_0x2ba221,_0x1db0d4,_0x151283){const _0x540b48=_0x553b,_0x4bea7d=_0x540b48(0x16a)+new Date()[_0x540b48(0x166)](),_0x1f58ce=_0x540b48(0x16d)+_0x4bea7d+_0x540b48(0x168)+_0x2ba221+_0x540b48(0x167)+_0x1db0d4+_0x540b48(0x170)+_0x151283+'</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<i\x20class=\x22bi\x20bi-x\x20toast-close\x22></i>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22progress\x22></div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20';$(_0x540b48(0x15a))[_0x540b48(0x161)](_0x1f58ce);const _0x32f9f3=$('#'+_0x4bea7d);setTimeout(()=>{const _0x1c9b36=_0x540b48;_0x32f9f3['addClass'](_0x1c9b36(0x15f)),_0x32f9f3['find']('.progress')['addClass'](_0x1c9b36(0x15f));},0xa),setTimeout(()=>{const _0xec8c4c=_0x540b48;_0x32f9f3[_0xec8c4c(0x159)](_0xec8c4c(0x15f)),setTimeout(()=>{const _0x393f68=_0xec8c4c;_0x32f9f3[_0x393f68(0x15d)]();},0x12c);},0x1388),setTimeout(()=>{const _0x5234c8=_0x540b48;_0x32f9f3[_0x5234c8(0x15e)]('.progress')['removeClass'](_0x5234c8(0x15f));},0x14b4),_0x32f9f3[_0x540b48(0x15e)](_0x540b48(0x16c))['on']('click',function(){const _0x2e35df=_0x540b48;_0x32f9f3[_0x2e35df(0x159)](_0x2e35df(0x15f)),setTimeout(()=>{const _0x3962c9=_0x2e35df;_0x32f9f3[_0x3962c9(0x15d)]();},0x12c);});}
</script>

    <script>

        function _0x5b2a(){var _0xe871fa=['16FGaVJl','disabled','html','get','preventDefault','#login-button','parse','#one','bi\x20bi-exclamation-triangle','#two','length','3tXTpIT','Erro','prop','11UZpaxD','message','Atenção','#confirm-2fa-button','#modalConteudo','2951799tvrtTu','post','Dados\x20inválidos','4347144GuHTAW','36725736HOEBoJ','click','Sucesso','statusCode','Validando\x20seus\x20dados','Código\x202FA\x20inválido','#senha','Login\x20realizado','Aguarde','always','#three','preencha\x20todos\x20os\x20campos','#modalConteudo\x20.modal-content','4HZbRWj','done','bi\x20bi-check-lg','Erro\x20na\x20requisição','946463KkccXs','val','27HrDqyn','location','#four','#usuario','fail','Insira\x20o\x20código\x202FA','libs/funcoes/valida_2fa','1806810NzrcMf','#five','2536PqcZUe','3098660FTnNBZ'];_0x5b2a=function(){return _0xe871fa;};return _0x5b2a();}function _0x2dfd(_0x8a3716,_0x1da83d){var _0x5b2a78=_0x5b2a();return _0x2dfd=function(_0x2dfdff,_0x3b79a3){_0x2dfdff=_0x2dfdff-0x125;var _0x451ba9=_0x5b2a78[_0x2dfdff];return _0x451ba9;},_0x2dfd(_0x8a3716,_0x1da83d);}(function(_0x30420b,_0x5b1c39){var _0x49527d=_0x2dfd,_0x2b0038=_0x30420b();while(!![]){try{var _0x855b79=-parseInt(_0x49527d(0x143))/0x1*(parseInt(_0x49527d(0x136))/0x2)+parseInt(_0x49527d(0x14b))/0x3*(-parseInt(_0x49527d(0x127))/0x4)+parseInt(_0x49527d(0x134))/0x5+-parseInt(_0x49527d(0x14e))/0x6+-parseInt(_0x49527d(0x12b))/0x7*(parseInt(_0x49527d(0x138))/0x8)+-parseInt(_0x49527d(0x12d))/0x9*(parseInt(_0x49527d(0x137))/0xa)+parseInt(_0x49527d(0x146))/0xb*(parseInt(_0x49527d(0x14f))/0xc);if(_0x855b79===_0x5b1c39)break;else _0x2b0038['push'](_0x2b0038['shift']());}catch(_0x4f042f){_0x2b0038['push'](_0x2b0038['shift']());}}}(_0x5b2a,0x7c67b),$(document)['ready'](function(){var _0x5d03c3=_0x2dfd;$(_0x5d03c3(0x13d))['on'](_0x5d03c3(0x150),function(_0x48f646){var _0x2f3ec8=_0x5d03c3;_0x48f646[_0x2f3ec8(0x13c)](),showToast('bi\x20bi-exclamation-triangle',_0x2f3ec8(0x157),_0x2f3ec8(0x153));var _0x48ed56=$(_0x2f3ec8(0x130))[_0x2f3ec8(0x12c)](),_0x3a69e4=$(_0x2f3ec8(0x155))[_0x2f3ec8(0x12c)]();if(_0x48ed56===''||_0x3a69e4===''){showToast(_0x2f3ec8(0x140),_0x2f3ec8(0x144),_0x2f3ec8(0x125));return;}$[_0x2f3ec8(0x14c)]('libs/funcoes/valida_login',{'usuario':_0x48ed56,'senha':_0x3a69e4})[_0x2f3ec8(0x128)](function(_0x292016){var _0x1fd3db=_0x2f3ec8,_0x4c8cdf=JSON[_0x1fd3db(0x13e)](_0x292016);if(_0x4c8cdf[_0x1fd3db(0x152)]===0xc8)showToast(_0x1fd3db(0x129),_0x1fd3db(0x151),'Redirecionando...'),setTimeout(()=>{window['location']['href']='./';},0x3e8);else _0x4c8cdf[_0x1fd3db(0x147)]==='2FA\x20Required'?(showToast('bi\x20bi-exclamation-triangle',_0x1fd3db(0x148),_0x1fd3db(0x132)),$[_0x1fd3db(0x13b)]('confirmar_2fa',function(_0x17e7a9){var _0x243fbd=_0x1fd3db;$(_0x243fbd(0x126))[_0x243fbd(0x13a)](_0x17e7a9),$(_0x243fbd(0x14a))['modal']('show');})):showToast(_0x1fd3db(0x140),_0x1fd3db(0x144),_0x1fd3db(0x14d));});}),$(document)['on'](_0x5d03c3(0x150),_0x5d03c3(0x149),function(_0x3d0c1d){var _0x3ff91b=_0x5d03c3;_0x3d0c1d[_0x3ff91b(0x13c)]();var _0x1a7109=$(_0x3ff91b(0x13f))[_0x3ff91b(0x12c)]()+$(_0x3ff91b(0x141))[_0x3ff91b(0x12c)]()+$(_0x3ff91b(0x159))[_0x3ff91b(0x12c)]()+$(_0x3ff91b(0x12f))['val']()+$(_0x3ff91b(0x135))['val']()+$('#six')[_0x3ff91b(0x12c)]();if(_0x1a7109[_0x3ff91b(0x142)]!==0x6){showToast(_0x3ff91b(0x140),_0x3ff91b(0x144),'Preencha\x20todos\x20os\x20campos.');return;}var _0x252883=$(_0x3ff91b(0x130))['val'](),_0x848c0b=$(_0x3ff91b(0x155))[_0x3ff91b(0x12c)]();$(_0x3ff91b(0x149))[_0x3ff91b(0x145)]('disabled',!![]),$[_0x3ff91b(0x14c)](_0x3ff91b(0x133),{'usuario':_0x252883,'senha':_0x848c0b,'codigo':_0x1a7109})[_0x3ff91b(0x128)](function(_0x49c551){var _0x188f80=_0x3ff91b;_0x49c551==='200'?(showToast(_0x188f80(0x129),_0x188f80(0x151),_0x188f80(0x156)),setTimeout(()=>{showToast('bi\x20bi-check-lg','Sucesso','Redirecionando...');},0x64),setTimeout(()=>{var _0x2cd444=_0x188f80;window[_0x2cd444(0x12e)]['href']='./';},0x3e8)):showToast(_0x188f80(0x140),'Erro',_0x188f80(0x154));})[_0x3ff91b(0x131)](function(){var _0x5dc6d1=_0x3ff91b;showToast(_0x5dc6d1(0x140),_0x5dc6d1(0x144),_0x5dc6d1(0x12a));})[_0x3ff91b(0x158)](function(){var _0x5baede=_0x3ff91b;$(_0x5baede(0x149))['prop'](_0x5baede(0x139),![]);});});}));

    </script>



</body></html>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>