-- Adminer 4.8.1 MySQL 10.11.10-MariaDB dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `config`;
CREATE TABLE `config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tax_min` decimal(10,6) DEFAULT NULL,
  `tax_cashin` int(11) DEFAULT NULL,
  `tax_cashout` int(11) DEFAULT NULL,
  `tax_internal` int(11) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `favicon` varchar(128) DEFAULT NULL,
  `logo` varchar(128) DEFAULT NULL,
  `togglelogo` varchar(128) DEFAULT NULL,
  `name_pay_logo` int(11) DEFAULT NULL,
  `primary_color` varchar(50) DEFAULT NULL,
  `secondary_color` varchar(50) DEFAULT NULL,
  `anti_fraude_min` decimal(20,6) DEFAULT NULL,
  `alerta` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `config` (`id`, `tax_min`, `tax_cashin`, `tax_cashout`, `tax_internal`, `name`, `favicon`, `logo`, `togglelogo`, `name_pay_logo`, `primary_color`, `secondary_color`, `anti_fraude_min`, `alerta`) VALUES
(0,	0.800000,	4,	3,	1,	'BILLIPAY',	'https://billi-pay.com/assets/images/billi-grande.png',	'https://billi-pay.com/assets/images/billilogo.png',	'https://billi-pay.com/assets/images/billi-grande.png',	0,	'255, 0, 0',	'255, 0, 0',	5000.000000,	'Atenção caro Cliente, Nosso Cashin o limite atual é de R$800, e não há limites para cashout caso o Cashin passe do limite resultara em banimento da conta!');

DROP TABLE IF EXISTS `ip_whitelist`;
CREATE TABLE `ip_whitelist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `ip` varchar(50) DEFAULT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

INSERT INTO `ip_whitelist` (`id`, `user_id`, `ip`) VALUES
(25,	1,	'147.79.84.39');

DROP TABLE IF EXISTS `transactions`;
CREATE TABLE `transactions` (
  `id` varchar(50) NOT NULL,
  `end2end` varchar(50) DEFAULT NULL,
  `external_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` decimal(20,6) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `confirmed_date` varchar(50) DEFAULT '0000-00-00 00:00:00',
  `tax` decimal(20,6) DEFAULT 0.000000,
  `status` enum('PAID','PENDING','CANCELLED','REVERSED') DEFAULT 'PENDING',
  `type` enum('DEPOSIT','WITHDRAW','INTERNAL_TRANSFER') DEFAULT NULL,
  `nome` varchar(50) DEFAULT NULL,
  `descricao` varchar(50) DEFAULT NULL,
  `api` int(11) DEFAULT NULL,
  `document` varchar(50) DEFAULT NULL,
  `internal` int(11) DEFAULT NULL,
  `postback_url` varchar(255) DEFAULT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

INSERT INTO `transactions` (`id`, `end2end`, `external_id`, `user_id`, `amount`, `created_at`, `confirmed_date`, `tax`, `status`, `type`, `nome`, `descricao`, `api`, `document`, `internal`, `postback_url`) VALUES
('e1065854d36b0f1b958d6a2f695vlh1zd',	'E20241230035245iTIsSdMv',	'6772190d4baac',	'19871396',	100.000000,	'2024-12-30 03:52:45',	'0000-00-00 00:00:00',	4.000000,	'PENDING',	'DEPOSIT',	'teste',	'Descrição do pagamento',	NULL,	'46941208830',	NULL,	'https://seuservidor.com/callback'),
('e4538781da6122cba43992b000b7szh05',	'E20241230031825xJOR7BKa',	'677211009c873',	'19871396',	100.220000,	'2024-12-30 03:18:25',	'0000-00-00 00:00:00',	4.008800,	'PAID',	'DEPOSIT',	'metamax',	'222',	NULL,	'098.637.185-80',	NULL,	NULL),
('e4c0bd42a9033ccfd8237f6e0900v1nkm',	'E20250102232543c38UFt2S',	'67772074d70a0',	'19871396',	100.000000,	'2025-01-02 23:25:43',	'0000-00-00 00:00:00',	4.000000,	'PENDING',	'DEPOSIT',	'metamax',	'',	NULL,	'098.637.185-80',	NULL,	NULL),
('e699c38b5a0b41654b3508aa1479rzfb5',	'E20250103000653BYzeKJvD',	'67772a1ac17b1',	'19871396',	1001.110000,	'2025-01-03 00:06:53',	'0000-00-00 00:00:00',	40.044400,	'PENDING',	'DEPOSIT',	'metamax',	'',	NULL,	'098.637.185-80',	NULL,	NULL),
('e7bb4bc3373222e1bdea9843839rgj4z3',	'E20241230035322TjRucmas',	'ecfa9899538bade7a819e93195eo78k6v',	'19871396',	0.200000,	'2024-12-30 03:53:23',	'2024-12-30 03:53:25',	0.800000,	'PAID',	'WITHDRAW',	'cris',	'',	NULL,	'11970142332',	NULL,	'https://seuservidor.com/callback'),
('e8237be5fdead8b6744d8213c5f47hjtx',	'E20250110191905VT4I52Ay',	'678172a63f752',	'19871396',	100.110000,	'2025-01-10 19:19:05',	'0000-00-00 00:00:00',	4.004400,	'PENDING',	'DEPOSIT',	'metamax',	'',	NULL,	'098.637.185-80',	NULL,	NULL),
('ec6df25c1650715f558924edf00e8pa97',	'E20250107015547sLPpMFWl',	'677c89a13e11e',	'19871396',	10.020000,	'2025-01-07 01:55:47',	'0000-00-00 00:00:00',	0.800000,	'PENDING',	'DEPOSIT',	'metamax',	'',	NULL,	'098.637.185-80',	NULL,	NULL),
('ecceebaaf9ebee949dd6c6a457chpko0r',	'E20250103000622AkWznVNo',	'677729fc5beca',	'19871396',	100.110000,	'2025-01-03 00:06:22',	'0000-00-00 00:00:00',	4.004400,	'PENDING',	'DEPOSIT',	'metamax',	'',	NULL,	'098.637.185-80',	NULL,	NULL),
('ef575e5f2339a215f0a168c6d1ecaz27i',	'E20241230194331T71Bmn98',	'6772f7e33d884',	'90304071',	100.000000,	'2024-12-30 19:43:31',	'0000-00-00 00:00:00',	4.000000,	'PENDING',	'DEPOSIT',	'josemir alvaro',	'Descrição do pagamento',	NULL,	'01213606365',	NULL,	'https://seuservidor.com/callback');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `telefone` varchar(50) DEFAULT NULL,
  `cnpj` varchar(50) DEFAULT NULL,
  `faturamento` varchar(50) DEFAULT NULL,
  `documents_checked` int(11) DEFAULT 0,
  `pin` varchar(50) DEFAULT NULL,
  `cash_in_active` int(11) DEFAULT 0,
  `cash_out_active` int(11) DEFAULT 0,
  `balance` decimal(20,6) DEFAULT 0.000000,
  `role` enum('USER','ADMIN') DEFAULT 'USER',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

INSERT INTO `users` (`id`, `username`, `password`, `name`, `email`, `telefone`, `cnpj`, `faturamento`, `documents_checked`, `pin`, `cash_in_active`, `cash_out_active`, `balance`, `role`) VALUES
(16677905,	'venompcx',	'sober1721sg',	'Alisson silva',	'Venixstudios@gmail.com',	'(24) 99311-9793',	'215.217.287-63',	'2',	0,	'121314',	0,	0,	0.000000,	'USER'),
(19871396,	'magnata',	'521723',	'magnata',	'magnata@gmail.com',	'(11) 97365-6223',	'54.914.384/0001-87',	'4',	1,	'521723',	1,	1,	99.000000,	'ADMIN'),
(23480358,	'Joao123',	'123456',	'JOAO CARLOS MENDONCA JUNIOR',	'samucaindio04@gmail.com',	'(31) 97612-2004',	'69.545.243/0001-01',	'3',	1,	'131313',	1,	1,	0.000000,	'USER'),
(24867787,	'testeteste',	'123456',	'Teste teste',	'teste@teste.com',	'(21) 99712-0016',	'210.333.231-87',	'1',	0,	'123456',	0,	0,	0.000000,	'USER'),
(29350112,	'teste22',	'teste22@gmail.com',	'teste22',	'teste22@gmail.com',	'(11) 97365-6447',	'449.968.838-80',	'4',	0,	NULL,	0,	0,	0.000000,	'USER'),
(46565763,	'teste00',	'teste00@gmail.com',	'teste00',	'teste00@gmail.com',	'(11) 97365-6887',	'420.423.828-92',	'4',	0,	NULL,	0,	0,	0.000000,	'USER'),
(54517167,	'Fugihcv',	'240065',	'Vera lucia',	'reserveigge@gmail.com',	'(18) 97897-8777',	'351.377.048-06',	'4',	0,	NULL,	0,	0,	0.000000,	'USER'),
(56924598,	'cb13xxx',	'123456',	'CB13',	'cb13xxx@gmail.com',	'(00) 00000-0000',	'377.466.710-12',	'4',	0,	'000000',	0,	0,	0.000000,	'USER'),
(59727637,	'Rally',	'212710Charlene',	'Fernando Roberto Silva Ferraz ',	'Fernando_ferraz2012@hotmail.com',	'(15) 99684-3422',	'19.316.319/0001-59',	'2',	1,	'212710',	1,	1,	0.000000,	'USER'),
(59731452,	'Hubbg545',	'clarisse-jonsson@tuamaeaquelaursa.com',	'clarisse jonsson',	'clarisse-jonsson@tuamaeaquelaursa.com',	'(66) 67777-7667',	'931.384.390-04',	'4',	0,	'000000',	0,	0,	0.000000,	'USER'),
(66996371,	'teste',	'teste',	'teste',	'teste@gmail.com',	'(11) 97365-6320',	'664.393.459-15',	'1',	1,	'521723',	1,	1,	0.000000,	'USER'),
(74722165,	'Josh12',	'240065',	'Thais martins ',	'boxdd7xx@gmail.com',	'(17) 99979-9788',	'481.062.998-80',	'4',	0,	NULL,	0,	0,	0.000000,	'USER'),
(79891396,	'Gabriel12',	'xyfke7-zahhas-fuztoK',	'Gabriel',	'gn1452617@gmail.com',	'(11) 99407-8761',	'584.446.478-88',	'2',	0,	NULL,	0,	0,	0.000000,	'USER'),
(81065661,	'Bilizin',	'Vera0412@@',	'Renato da Silva moises',	'renatodasilvamoises@gmail.com',	'(14) 99123-7822',	'133.810.858-16',	'2',	0,	NULL,	0,	0,	0.000000,	'USER'),
(83586352,	'Cerberus',	'000000',	'Cerberus',	'cb13xxx+1@gmail.com',	'(00) 00000-0077',	'398.927.700-64',	'4',	0,	NULL,	0,	0,	0.000000,	'USER'),
(88930815,	'Joseph',	'83980109',	'JOSEPH ALEXSANDRO SANTOS PINTO',	'glauberlima0100@gmail.com',	'(31) 98422-6393',	'071.128.753-82',	'1',	1,	'222222',	1,	1,	0.000000,	'USER'),
(89671188,	'matheus777',	'35791200',	'matheus vinicius fonseca campos',	'plataformaprofisional07@gmail.com',	'(37) 99868-4738',	'166.166.356-78',	'4',	0,	NULL,	0,	0,	0.000000,	'USER'),
(90304071,	'REBECAFREZICHIKAWA',	'zacariasA00@',	'REBECA FREZ ICHIKAWA',	'swagswag@gmail.com',	'(83) 92952-6622',	'012.136.063-65',	'4',	1,	'898989',	1,	1,	0.000000,	'USER'),
(92900570,	'teste1',	'teste1',	'teste1',	'teste1@gmail.com',	'(11) 97335-6220',	'700.417.134-51',	'4',	1,	'521723',	1,	1,	0.200000,	'USER'),
(95290919,	'Clezio142',	'252423',	'Clezio Soares',	'Clezioprojetos@hotmail.com',	'(61) 99637-2258',	'709.233.531-00',	'0',	0,	NULL,	0,	0,	0.000000,	'USER'),
(95877035,	'Jkzin',	'83980109',	'ANDRESSA FURTADO PORTELA',	'todospelooleopaidograu@gmail.com',	'(31) 98244-6293',	'342.831.198-14',	'2',	1,	'555555',	1,	1,	0.000000,	'USER');

DROP TABLE IF EXISTS `users_documents`;
CREATE TABLE `users_documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT 0,
  `document_id` int(11) DEFAULT NULL,
  `formFile` binary(50) DEFAULT NULL,
  `file_content` varchar(50) DEFAULT NULL,
  `file_path` varchar(128) DEFAULT NULL,
  `approved` int(11) DEFAULT 0,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

INSERT INTO `users_documents` (`id`, `user_id`, `document_id`, `formFile`, `file_content`, `file_path`, `approved`) VALUES
(18,	19871396,	1,	NULL,	NULL,	'/home/u841498289/domains/ilumycenter.org/public_html/libs/funcoes/documentos/uploads/MINER MONEY_608560.png',	1),
(19,	19871396,	2,	NULL,	NULL,	'/home/u841498289/domains/ilumycenter.org/public_html/libs/funcoes/documentos/uploads/MINER MONEY_663056.png',	1),
(20,	19871396,	3,	NULL,	NULL,	'/home/u841498289/domains/ilumycenter.org/public_html/libs/funcoes/documentos/uploads/MINER MONEY_664447.png',	1),
(21,	19871396,	4,	NULL,	NULL,	'/home/u841498289/domains/ilumycenter.org/public_html/libs/funcoes/documentos/uploads/75229600-hyiprio-advanced-hyip-investment-s',	1),
(22,	95877035,	1,	NULL,	NULL,	'/home/u841498289/domains/billi-pay.com/public_html/libs/funcoes/documentos/uploads/1000110597_410116.jpg',	1),
(23,	95877035,	2,	NULL,	NULL,	'/home/u841498289/domains/billi-pay.com/public_html/libs/funcoes/documentos/uploads/1000110596_828310.jpg',	1),
(24,	95877035,	3,	NULL,	NULL,	'/home/u841498289/domains/billi-pay.com/public_html/libs/funcoes/documentos/uploads/1000110598_343913.jpg',	1),
(25,	88930815,	1,	NULL,	NULL,	'/home/u841498289/domains/billi-pay.com/public_html/libs/funcoes/documentos/uploads/1000110914_400193.jpg',	1),
(26,	88930815,	2,	NULL,	NULL,	'/home/u841498289/domains/billi-pay.com/public_html/libs/funcoes/documentos/uploads/1000110916_567754.jpg',	1),
(27,	88930815,	3,	NULL,	NULL,	'/home/u841498289/domains/billi-pay.com/public_html/libs/funcoes/documentos/uploads/1000110915_275280.jpg',	1),
(33,	23480358,	1,	NULL,	NULL,	'/home/u841498289/domains/billi-pay.com/public_html/libs/funcoes/documentos/uploads/photo_2025-01-10_15-22-42_701390.jpg',	1),
(34,	23480358,	2,	NULL,	NULL,	'/home/u841498289/domains/billi-pay.com/public_html/libs/funcoes/documentos/uploads/photo_2025-01-10_15-23-06_190791.jpg',	1),
(35,	23480358,	3,	NULL,	NULL,	'/home/u841498289/domains/billi-pay.com/public_html/libs/funcoes/documentos/uploads/C273-_748123.jpg',	1),
(36,	24867787,	1,	NULL,	NULL,	'/home/u841498289/domains/billi-pay.com/public_html/libs/funcoes/documentos/uploads/caixatem_124049.png',	0),
(37,	24867787,	2,	NULL,	NULL,	'/home/u841498289/domains/billi-pay.com/public_html/libs/funcoes/documentos/uploads/caixatem_689631.png',	0),
(38,	24867787,	3,	NULL,	NULL,	'/home/u841498289/domains/billi-pay.com/public_html/libs/funcoes/documentos/uploads/caixatem_885289.png',	0),
(39,	24867787,	4,	NULL,	NULL,	'/home/u841498289/domains/billi-pay.com/public_html/libs/funcoes/documentos/uploads/CCMEI-55113870000169_207406.pdf',	0);

DROP TABLE IF EXISTS `users_integration_keys`;
CREATE TABLE `users_integration_keys` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `client_id` varchar(50) DEFAULT NULL,
  `client_secret` varchar(256) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `description` varchar(50) DEFAULT NULL,
  `created_at` varchar(50) DEFAULT NULL,
  `domain` varchar(50) DEFAULT NULL,
  `access_token` varchar(256) DEFAULT NULL,
  `expires_in` varchar(20) DEFAULT NULL,
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `userId` (`user_id`) USING BTREE,
  UNIQUE KEY `client_id` (`client_id`),
  UNIQUE KEY `client_secret` (`client_secret`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

INSERT INTO `users_integration_keys` (`id`, `user_id`, `client_id`, `client_secret`, `name`, `description`, `created_at`, `domain`, `access_token`, `expires_in`) VALUES
(8,	19871396,	'magnata_8072645305',	'0a311350aca9cb7b735025edf62300f209ec224383798a8b0332c783f833eaa1',	'teste',	'sistema\r\nteste\r\nblz',	'2024-12-29 19:32:19',	'https://friday777.com/',	NULL,	NULL),
(9,	66996371,	'teste_2550305271',	'30b9097bd982867c0def8d1a0d3bd47b618535ec6c4c7195e0b64feae1df551b',	'maximobrabo',	'maximobrabomaximobrabo\r\nmaximobrabo\r\nmaximobraboma',	'2024-12-23 18:07:52',	'https://goldinvest-ia.com/',	NULL,	NULL),
(10,	59727637,	'Rally_1122766538',	'ce11b8d71061af926f61a586e2c1e8a85e8163a7955ff50ef53b3b5847b138c7',	'Gold invest IA ',	'Gold invest IA ',	'2024-12-23 22:18:52',	'https://goldinvest-ia.com',	NULL,	NULL),
(11,	92900570,	'teste1_6256297065',	'3918b42c1f31048b8e41dd5ad09af3e91684c61e0c0f7ad213751a5c2f444e70',	'teste t ttt ',	'teste t ttt ',	'2024-12-29 23:09:44',	'https://frida777.com',	NULL,	NULL),
(12,	90304071,	'REBECAFREZICHIKAWA_4853287974',	'deb919e8fff5ff974b3a3c0cdd2cecf67ddbe3ced259532d94497bc8ebde36da',	'teste',	'test\r\ntest\r\ntest\r\ntest\r\ntest',	'2024-12-30 19:42:22',	'https://www.sofascore.com/',	NULL,	NULL);

-- 2025-01-13 18:00:47
