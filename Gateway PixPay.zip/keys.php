<?php
session_start();

// Função para carregar as variáveis do arquivo .env
function loadEnv($file) {
    if (!file_exists($file)) {
        throw new Exception("Arquivo .env não encontrado!");
    }

    $lines = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

    foreach ($lines as $line) {
        if (strpos(trim($line), '#') === 0) {
            continue;
        }

        list($key, $value) = explode('=', $line, 2);
        $key = trim($key);
        $value = trim($value);

        putenv("$key=$value");
        $_ENV[$key] = $value;
    }
}

// Carregar as variáveis do arquivo .env
loadEnv(__DIR__ . '/.env');  // Ajuste o caminho conforme necessário

// Verifique se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    echo "Você precisa estar logado.";
    exit;
}

if (isset($_SESSION['documents_checked'])) {
    if ($_SESSION['documents_checked'] == 0) {
        header("Location: /settings");
        exit();
    }
}

$user_id = $_SESSION['user_id']; // Obtém o user_id da sessão

// Conexão com o banco de dados usando as variáveis do .env
try {
    $dbHost = getenv('DB_HOST');
    $dbName = getenv('DB_NAME');
    $dbUser = getenv('DB_USER');
    $dbPass = getenv('DB_PASS');

    // Conexão PDO com os detalhes do banco de dados
    $pdo = new PDO("mysql:host=$dbHost;dbname=$dbName", $dbUser, $dbPass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Prepare a consulta para buscar os IPs associados ao user_id
    $stmt = $pdo->prepare('SELECT id, ip FROM ip_whitelist WHERE user_id = :user_id');
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->execute();

    // Buscar os resultados
    $ips = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Consulta de credenciais
    $stmt = $pdo->prepare('SELECT * FROM users_integration_keys WHERE user_id = :user_id');
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->execute();

    // Buscar os resultados
    $credenciais = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo 'Erro na conexão com o banco de dados: ' . $e->getMessage();
    exit;
}
?>
<!doctype html>
<html lang="en">

<head>
   <title>Credenciais PixPay - Dashboard</title>
   <meta charset="utf-8" />
   <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui" />
   <meta http-equiv="X-UA-Compatible" content="IE=edge" />
   <meta name="author" content="PixPay" />
   <link rel="icon" href="/imagens/logoo.png" type="image/x-icon" />
   <link rel="stylesheet" href="sistemaAssets/assets/fonts/inter/inter.css" id="main-font-link" />
   <link rel="stylesheet" href="sistemaAssets/assets/fonts/tabler-icons.min.css" />
   <link rel="stylesheet" href="sistemaAssets/assets/fonts/feather.css" />
   <link rel="stylesheet" href="sistemaAssets/assets/fonts/fontawesome.css" />
   <link rel="stylesheet" href="sistemaAssets/assets/fonts/material.css" />
   <link rel="stylesheet" href="sistemaAssets/assets/css/style.css" id="main-style-link" />
   <link rel="stylesheet" href="sistemaAssets/assets/css/style-preset.css" />
   <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script> <?php
    try {
        // Definir variáveis de conexão
        $dbHost = $_ENV['DB_HOST'];
        $dbnome = $_ENV['DB_NAME'];
        $dbUser = $_ENV['DB_USER'];
        $dbPass = $_ENV['DB_PASS'];

        // Conectar ao banco de dados
        $dsn = "mysql:host=$dbHost;dbname=$dbnome;charset=utf8";
        $pdo = new PDO($dsn, $dbUser, $dbPass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Consultar as cores RGB armazenadas no banco de dados
        $query = "SELECT primary_color, secondary_color FROM config LIMIT 1"; // Supondo que as cores estejam na tabela config
        $stmt = $pdo->prepare($query);
        $stmt->execute();
        $config = $stmt->fetch(PDO::FETCH_ASSOC);

        // Obter as cores RGB do banco, caso não existam, usar valores padrão
        $primaryRgb = isset($config['primary_color']) ? $config['primary_color'] : '0, 203, 161'; // Exemplo de RGB padrão
        $secondaryRgb = isset($config['secondary_color']) ? $config['secondary_color'] : '69, 214, 91'; // Exemplo de RGB padrão
    } catch (PDOException $e) {
        die("Erro ao conectar ao banco de dados: " . $e->getMessage());
    }
    ?>

    <style>
        :root {
            --primary-rgb: <?php echo $primaryRgb; ?>;
            --secondary-rgb: <?php echo $secondaryRgb; ?>;
            --success-rgb: <?php echo $primaryRgb; ?>;
        }

        .box_code {
            padding-inline: 0;
            border: 1px solid rgb(<?php echo $primaryRgb; ?>);
            width: 39px;
            height: 39px;
            margin: 0px 4px;
            border-radius: 10px;
        }
    </style>
</head>

<body data-pc-preset="preset-1" data-pc-sidebar-caption="true" data-pc-layout="vertical" data-pc-direction="ltr" data-pc-theme_contrast="" data-pc-theme="dark">
   <style>
      .loader-container {
         position: fixed;
         top: 0;
         left: 0;
         width: 100%;
         height: 100%;
         background: #131920;
         z-index: 9999;
         display: flex;
         justify-content: center;
         align-items: center;
         flex-direction: column;
      }

      .loader {
         width: 60px;
         height: 60px;
         border-radius: 50%;
         background-color: transparent;
         border: 8px solid #ffffff;
         border-top-color: #4680ff;
         animation: spin 1s linear infinite;
         margin-bottom: 20px;
      }

      @keyframes spin {
         0% {
            transform: rotate(0deg);
         }

         100% {
            transform: rotate(360deg);
         }
      }

      .loading-text {
         color: #ffffff;
         font-size: 16px;
      }
   </style>
   <script>
      window.addEventListener("load", function() {
         const loader = document.querySelector('.loader-container');
         loader.style.display = 'none';
         document.body.style.overflow = 'auto';
      });
   </script>









  <?php
// Função para conectar ao banco de dados

// Função para conectar ao banco de dados
function connectDb245() {
    // Obtendo as variáveis de ambiente para a conexão com o banco
    $dbHost = getenv('DB_HOST');
    $dbName = getenv('DB_NAME');
    $dbUser = getenv('DB_USER');
    $dbPass = getenv('DB_PASS');

    try {
        // Conexão PDO com o banco de dados
        $pdo = new PDO("mysql:host=$dbHost;dbname=$dbName", $dbUser, $dbPass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $pdo;
    } catch (PDOException $e) {
        die("Erro ao conectar ao banco de dados: " . $e->getMessage());
    }
}

// Função para obter o nome do usuário com base no user_id
function getUserName($pdo, $user_id) {
    $stmt = $pdo->prepare("SELECT name FROM users WHERE id = :user_id");
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->execute();

    // Recupera o nome do usuário
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result['name'] ?? 'Usuário não encontrado'; // Retorna o nome ou uma mensagem de erro se não encontrado
}

// Função para obter o role do usuário com base no user_id
function getUserRole($pdo, $user_id) {
    $stmt = $pdo->prepare("SELECT role FROM users WHERE id = :user_id");
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->execute();

    // Recupera o role do usuário
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result['role'] ?? 'Visitante'; // Retorna o role ou 'Visitante' caso não encontrado
}

// Função para calcular o total das transações do usuário (DEPOSIT e INTERNAL_TRANSFER)
function getUserBalance($pdo, $user_id) {
    // Consulta para somar transações DEPOSIT e INTERNAL_TRANSFER com external_id igual ao user_id
    $stmt = $pdo->prepare("
        SELECT SUM(amount) AS total 
        FROM transactions 
        WHERE 
            status = 'PAID' 
            AND (
                (type = 'DEPOSIT' AND user_id = :user_id) OR 
                (type = 'INTERNAL_TRANSFER' AND external_id = :user_id)
            )
    ");
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->execute();

    // Obter o total diretamente da soma
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result['total'] ?? 0; // Retorna 0 se não houver transações
}

// Função para calcular a média das transações do usuário
function getUserAverageTransaction($pdo, $user_id) {
    $stmt = $pdo->prepare("SELECT amount FROM transactions WHERE (user_id = :user_id OR external_id = :user_id) AND status = 'PAID'");
    $stmt->bindParam(':user_id', $user_id);
    $stmt->execute();

    // Inicializando variáveis para soma e contagem
    $totalAmount = 0;
    $transactionCount = 0;

    // Somar os valores das transações e contar as transações
    while ($transaction = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $totalAmount += $transaction['amount'];
        $transactionCount++;
    }

    // Calcular a média, evitando divisão por zero
    if ($transactionCount > 0) {
        return $totalAmount / $transactionCount;
    } else {
        return 0; // Se não houver transações, a média é 0
    }
}

// Função para contar o total de transações do usuário
function getUserTransactionCount($pdo, $user_id) {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM transactions WHERE (user_id = :user_id OR external_id = :user_id) AND status = 'PAID'");
    $stmt->bindParam(':user_id', $user_id);
    $stmt->execute();

    return $stmt->fetchColumn();
}

// Conectar ao banco de dados
$pdo = connectDb245();

// Recuperar o usuário logado
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];

    // Recuperar o nome e o role do usuário
    $user_name = getUserName($pdo, $user_id);
    $user_role = getUserRole($pdo, $user_id);

    // Calcular o total de faturamento
    $totalAmount = getUserBalance($pdo, $user_id);

    // Calcular a média do ticket
    $averageAmount = getUserAverageTransaction($pdo, $user_id);

    // Contar o número total de transações
    $transactionCount = getUserTransactionCount($pdo, $user_id);
} else {
    // Se o usuário não estiver logado
    $user_name = 'Visitante';
    $user_role = 'Visitante'; // Atribui o role 'Visitante' para usuários não logados
    $totalAmount = 0;
    $averageAmount = 0;
    $transactionCount = 0;
}

?>
   


 



   <body data-pc-preset="preset-1" data-pc-sidebar-caption="true" data-pc-layout="vertical" data-pc-direction="ltr" data-pc-theme_contrast="" data-pc-theme="dark">
     
     
    
               
  <?php include 'includes/includes_menu.php'; ?>
    
    
      <header class="pc-header">
         <div class="header-wrapper">
            <div class="me-auto pc-mob-drp">
               <ul class="list-unstyled">
                  <li class="pc-h-item pc-sidebar-collapse">
                     <a href="#" class="pc-head-link ms-0" id="sidebar-hide">
                        <i class="ti ti-menu-2"></i>
                     </a>
                  </li>
                  <li class="pc-h-item pc-sidebar-popup">
                     <a href="#" class="pc-head-link ms-0" id="mobile-collapse">
                        <i class="ti ti-menu-2"></i>
                     </a>
                  </li>
               </ul>
            </div>
            <div class="ms-auto">
               <ul class="list-unstyled">
                  <li class="dropdown pc-h-item">
                     <a
                        class="pc-head-link dropdown-toggle arrow-none me-0"
                        data-bs-toggle="dropdown"
                        href="#"
                        role="button"
                        aria-haspopup="false"
                        aria-expanded="false">
                        <svg class="pc-icon">
                           <use xlink:href="#custom-sun-1"></use>
                        </svg>
                     </a>
                     <div class="dropdown-menu dropdown-menu-end pc-h-dropdown">
                        <a href="#!" class="dropdown-item" onclick="layout_change('dark')">
                           <svg class="pc-icon">
                              <use xlink:href="#custom-moon"></use>
                           </svg>
                           <span>Escuro</span>
                        </a>
                        <a href="#!" class="dropdown-item" onclick="layout_change('light')">
                           <svg class="pc-icon">
                              <use xlink:href="#custom-sun-1"></use>
                           </svg>
                           <span>Claro</span>
                        </a>
                        <a href="#!" class="dropdown-item" onclick="layout_change_default()">
                           <svg class="pc-icon">
                              <use xlink:href="#custom-setting-2"></use>
                           </svg>
                           <span>Padrão</span>
                        </a>
                     </div>
                  </li>
                  <li class="dropdown pc-h-item header-user-profile">
                     <img src="https://img.freepik.com/fotos-premium/logotipo-redondo-moderno-com-mulher-futurista-em-cores-suaves-e-luz-de-fundo-ia-generativa_7023-240406.jpg?w=740" alt="user-image" class="user-avtar" />
                     </a>
            </div>
         </div>
         </li>
         </ul>
         </div>
         </div>
      </header>
      <section class="pc-container">
         <div class="pc-content">
            <div class="page-header">
               <div class="page-block">
                  <div class="row align-items-center">
                     <div class="col-md-12">
                        <ul class="breadcrumb">
                           <li class="breadcrumb-item"><a href="../../">Dashboard</a></li>
                           <li class="breadcrumb-item" aria-current="page">Credenciais</li>
                        </ul>
                     </div>
                     <div class="col-md-12">
                        <div class="page-header-title">
                           <h2 class="mb-0">Credenciais</h2>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
                           <center> <img src="https://pixpay.fun/imagens/log.png" alt="Logo" class="img-fluid mb-4" style="max-width: 200px;"> </center>

            <div class="row">
                
               <div class="col-md-12">
                  <div class="card">
                     <div class="card-header">
                     </div>
                     <div class="card-body" id="afiliados">
                        <form method="POST" action="">
                           <div class="row">
                              <div class="col-md-12">
                                 <div class="card">
                                    <div class="card-header">
                                       
                                       
                                       
                                       
                                     
                                     
                                     
                                      <div class="row">
      <div class="col-xl-12">
        <div class="card custom-card shadow-sm border-light">
          <div class="card-body">
            <div class="table-responsive">
              <table class="table text-nowrap table-striped table-hover table-bordered">
                <thead class="table-light">
                  <tr>
                    <th scope="col">Client ID</th>
                    <th scope="col">Nome</th>
                    <th scope="col">Descrição</th>
                    <th scope="col">Data de Criação</th>
                    <th scope="col">Status</th>
                  </tr>
                </thead>
                <tbody>
                  <?php if (count($credenciais) > 0): ?>
                    <?php foreach ($credenciais as $credencial): ?>
                      <tr>
                        <td><?= $credencial['client_id'] ?></td>
                        <td><?= $credencial['name'] ?></td>
                        <td><?= $credencial['description'] ?></td>
                        <td><?= date('d/m/Y H:i:s', strtotime($credencial['created_at'])) ?></td>
                        <td><button class="btn btn-sm btn-success">ATIVO</button></td>
                      </tr>
                    <?php endforeach; ?>
                  <?php else: ?>
                    <tr>
                      <td colspan="5" class="text-center text-muted">Você deve gerar uma credencial de integração.</td>
                    </tr>
                  <?php endif; ?>
                </tbody>
              </table>

                                     
                                     
                                     
                                     
                                     
                                     
                                     
                                     
                                     
                                     
                                     
                                     
                                     Agora de forma Facil voce consegue gerenciar as suas CHAVES para integração, Criando, Apagando, e tambem adicionando novos IP's para saques.
                                     
            
            
            
           <div class="main-content app-content">
  <div class="container-fluid">
    <div class="page-header-breadcrumb d-flex align-items-center justify-content-between flex-wrap gap-2">
      <div>
        <p class="fw-medium fs-20 text-dark">Gerenciar Chaves de Integração</p>
      </div>
    </div>
    <button type="button" data-target="libs/includes/criar_integracao" id="alert-confirm" class="btn btn-success mb-4 btn-wave waves-effect waves openModal">
      Credenciais de Integração
    </button>
   
              <div class="accordion accordion-solid-primary mt-4" id="accordionPrimarySolidExample">
                <div class="accordion-item">
                  <h2 class="accordion-header" id="headingPrimarySolidOne">
                    <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapsePrimarySolidOne" aria-expanded="true" aria-controls="collapsePrimarySolidOne">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-tabler icons-tabler-outline icon-tabler-network">
                        <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                        <path d="M6 9a6 6 0 1 0 12 0a6 6 0 0 0 -12 0" />
                        <path d="M12 3c1.333 .333 2 2.333 2 6s-.667 5.667 -2 6" />
                        <path d="M12 3c-1.333 .333 -2 2.333 -2 6s.667 5.667 2 6" />
                        <path d="M6 9h12" />
                        <path d="M3 20h7" />
                        <path d="M14 20h7" />
                        <path d="M10 20a2 2 0 1 0 4 0a2 2 0 0 0 -4 0" />
                        <path d="M12 15v3" />
                      </svg> IPs Permitidos
                    </button>
                  </h2>
                  <div id="collapsePrimarySolidOne" class="accordion-collapse collapse show" aria-labelledby="headingPrimarySolidOne" data-bs-parent="#accordionPrimarySolidExample">
                    <div class="accordion-body">
                      <div class="table-responsive">
                        <table class="table text-nowrap table-bordered">
                          <thead class="table-light">
                            <tr>
                              <th scope="col">IP</th>
                              <th scope="col">Ação</th>
                            </tr>
                          </thead>
                          <tbody class="table-group-divider">
                            <?php if (count($ips) > 0): ?>
                              <?php foreach ($ips as $ip): ?>
                                <tr data-index="<?= $ip['id'] ?>">
                                  <th scope="row"><?= htmlspecialchars($ip['ip']) ?></th>
                                  <td>
                                    <svg class="excluir text-danger" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                      <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                      <path d="M4 7l16 0"></path>
                                      <path d="M10 11l0 6"></path>
                                      <path d="M14 11l0 6"></path>
                                      <path d="M5 7l1 12a2 2 0 0 0 2 2h8a2 2 0 0 0 2 -2l1 -12"></path>
                                      <path d="M9 7v-3a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v3"></path>
                                    </svg>
                                  </td>
                                </tr>
                              <?php endforeach; ?>
                            <?php else: ?>
                              <tr>
                                <td colspan="2" class="text-center text-muted">Nenhum IP encontrado para este usuário.</td>
                              </tr>
                            <?php endif; ?>
                          </tbody>
                        </table>
                        <button class="btn btn-sm btn-primary mt-4 openModal" data-target="libs/includes/adicionar_ip">Adicionar IP</button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

         <?php
// Iniciar a sessão
session_start();

// Função para conectar ao banco de dados
function connectDb() {
    $dbHost = getenv('DB_HOST');
    $dbName = getenv('DB_NAME');
    $dbUser = getenv('DB_USER');
    $dbPass = getenv('DB_PASS');

    try {
        // Conexão PDO com o banco de dados
        $pdo = new PDO("mysql:host=$dbHost;dbname=$dbName", $dbUser, $dbPass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $pdo;
    } catch (PDOException $e) {
        throw new Exception("Erro ao conectar ao banco de dados: " . $e->getMessage());
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Defina o PIN correto (isso pode vir de um banco de dados ou de uma variável de ambiente)
    $user_pin = $_POST['pin'];

    // Conectar ao banco de dados
    $pdo = connectDb();

    // Buscar o PIN do usuário no banco de dados
    $stmt = $pdo->prepare("SELECT pin FROM users WHERE id = :user_id");
    $stmt->bindParam(':user_id', $_SESSION['user_id']);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // Verificar se o PIN está correto
    if ($user_pin == $user['pin']) {
        // Se o PIN for correto, mostrar as credenciais
        echo "<div class='alert alert-success'>PIN correto. Aqui estão suas credenciais de integração:</div>";

        // Buscar as credenciais de integração do usuário
        $stmt = $pdo->prepare("SELECT * FROM users_integration_keys WHERE user_id = :user_id");
        $stmt->bindParam(':user_id', $_SESSION['user_id']);
        $stmt->execute();
        $credenciais = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Mostrar as credenciais
        echo "<table class='table'>";
        echo "<tr><th>Client ID</th><th>Nome</th><th>Descrição</th><th>Data de Criação</th><th>Client Secret</th><th>Status</th></tr>";
        foreach ($credenciais as $credencial) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($credencial['client_id']) . "</td>";
            echo "<td>" . htmlspecialchars($credencial['name']) . "</td>";
            echo "<td>" . htmlspecialchars($credencial['description']) . "</td>";
            echo "<td>" . date('d/m/Y H:i:s', strtotime($credencial['created_at'])) . "</td>";
            echo "<td>" . htmlspecialchars($credencial['client_secret']) . "</td>";
            echo "<td><button class='btn btn-sm btn-success'>ATIVO</button></td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        // Se o PIN estiver errado, mostrar um erro
        echo "<div class='alert alert-danger'>PIN incorreto. Tente novamente.</div>";
    }
} else {
    // Mostrar o formulário de PIN
    ?>
   <br>
<br>
<form method="POST">
    <div class="form-group">
        <label for="pin">Digite o PIN para ver suas Credenciais para Integração PRIVADA</label>
        <input type="password" class="form-control" id="pin" name="pin" required>
    </div>
    <br>
    <button type="submit" class="btn btn-primary">Verificar PIN</button>
</form>

    <?php
}
?>



            
            
            
            
            
            
            
                                       
                                       
                                    </div>
                                 </div>
                              </div>
                           </div>
                     </div>
                  </div>
      </section>
      <footer class="pc-footer">
         <div class="footer-wrapper container-fluid">
            <div class="row">
               <div class="col my-1">
                  <p class="m-0">Feito com muito &#9829; por <a href="PixPay" target="_blank">PixPay</a></p>
               </div>
               <div class="col-auto my-1">
                  <ul class="list-inline footer-link mb-0">
                     <li class="list-inline-item"><a href="../../inicio">Inicio</a></li>
                     <li class="list-inline-item"><a href="PixPay" target="_blank">PixPay</a></li>
                  </ul>
               </div>
            </div>
         </div>
      </footer>
      <div class="pct-c-btn">
         <a href="#" data-bs-toggle="offcanvas" data-bs-target="#offcanvas_pc_layout">
            <i class="ph-duotone ph-gear-six"></i>
         </a>
      </div>
      <div class="offcanvas border-0 pct-offcanvas offcanvas-end" tabindex="-1" id="offcanvas_pc_layout">
         <div class="offcanvas-header">
            <h5 class="offcanvas-title">Configuração</h5>
            <button type="button" class="btn btn-icon btn-link-danger ms-auto" data-bs-dismiss="offcanvas" aria-label="Close"><i class="ti ti-x"></i></button>
         </div>
         <div class="pct-body customizer-body">
            <div class="offcanvas-body py-0">
               <ul class="list-group list-group-flush">
                  <li class="list-group-item">
                     <div class="pc-dark">
                        <h6 class="mb-1">Modo Tema</h6>
                        <p class="text-muted text-sm">Escolha o modo claro ou escuro ou Auto</p>
                        <div class="row theme-color theme-layout">
                           <div class="col-4">
                              <div class="d-grid">
                                 <button
                                    class="preset-btn btn active"
                                    data-value="true"
                                    onclick="layout_change('light');"
                                    data-bs-toggle="tooltip"
                                    title="Light">
                                    <svg class="pc-icon text-warning">
                                       <use xlink:href="#custom-sun-1"></use>
                                    </svg>
                                 </button>
                              </div>
                           </div>
                           <div class="col-4">
                              <div class="d-grid">
                                 <button class="preset-btn btn" data-value="false" onclick="layout_change('dark');" data-bs-toggle="tooltip" title="Dark">
                                    <svg class="pc-icon">
                                       <use xlink:href="#custom-moon"></use>
                                    </svg>
                                 </button>
                              </div>
                           </div>
                           <div class="col-4">
                              <div class="d-grid">
                                 <button
                                    class="preset-btn btn"
                                    data-value="default"
                                    onclick="layout_change_default();"
                                    data-bs-toggle="tooltip"
                                    title="Automatically sets the theme based on user's operating system's color scheme.">
                                    <span class="pc-lay-icon d-flex align-items-center justify-content-center">
                                       <i class="ph-duotone ph-cpu"></i>
                                    </span>
                                 </button>
                              </div>
                           </div>
                        </div>
                     </div>
                  </li>
                  <li class="list-group-item">
                     <h6 class="mb-1">Contraste do tema</h6>
                     <p class="text-muted text-sm">Escolha o contraste do tema</p>
                     <div class="row theme-contrast">
                        <div class="col-6">
                           <div class="d-grid">
                              <button
                                 class="preset-btn btn"
                                 data-value="true"
                                 onclick="layout_theme_contrast_change('true');"
                                 data-bs-toggle="tooltip"
                                 title="True">
                                 <svg class="pc-icon">
                                    <use xlink:href="#custom-mask"></use>
                                 </svg>
                              </button>
                           </div>
                        </div>
                        <div class="col-6">
                           <div class="d-grid">
                              <button
                                 class="preset-btn btn active"
                                 data-value="false"
                                 onclick="layout_theme_contrast_change('false');"
                                 data-bs-toggle="tooltip"
                                 title="False">
                                 <svg class="pc-icon">
                                    <use xlink:href="#custom-mask-1-outline"></use>
                                 </svg>
                              </button>
                           </div>
                        </div>
                     </div>
                  </li>
                   <?php include 'includes/includes_assets.php'; ?>







  <script src="assets/js/jquery-3.6.1.min.js"></script>
  <!-- Popper JS -->
  <script src="assets/libs/@popperjs/core/umd/popper.min.js"></script>
  
  <!-- Defaultmenu JS -->
  <script src="assets/js/defaultmenu.min.js"></script>
  <!-- Node Waves JS-->
  <script src="assets/libs/node-waves/waves.min.js"></script>
  <!-- Sticky JS -->
  <script src="assets/js/sticky.js"></script>
  <!-- Simplebar JS -->
  <script src="assets/libs/simplebar/simplebar.min.js"></script>
  <script src="assets/js/simplebar.js"></script>
  <!-- Color Picker JS -->
  <script src="assets/libs/@simonwep/pickr/pickr.es5.min.js"></script>
  <script src="assets/libs/flatpickr/flatpickr.min.js"></script>
  <script src="assets/js/date&time_pickers.js"></script>
  <!-- Apex Charts JS -->
  <script src="assets/libs/apexcharts/apexcharts.min.js"></script>
  <!-- Ecommerce-Dashboard JS -->
  <script src="assets/js/ecommerce-dashboard.js"></script>
  <!-- Custom-Switcher JS -->
  <script src="assets/js/custom-switcher.min.js"></script>
  <script src="assets/libs/sweetalert2/sweetalert2.min.js"></script>
  <!-- Custom JS -->
  <script src="assets/js/custom.js"></script>
<?php include 'includes/includes_popup.php'; ?>

  <div class="toast-container"></div>
  <script>
    function _0x553b(_0x2e5c0a,_0x2e7c71){const _0x5d8a02=_0x5d8a();return _0x553b=function(_0x553b9c,_0x101e05){_0x553b9c=_0x553b9c-0x158;let _0x3fb95a=_0x5d8a02[_0x553b9c];return _0x3fb95a;},_0x553b(_0x2e5c0a,_0x2e7c71);}function _0x5d8a(){const _0x1c32f9=['4314338dyFgoH','remove','find','active','47jOpOel','append','6AlcdiJ','1704916uZVurw','110BcUHGs','1037570sCalrz','getTime','\x20toast-check\x22></i>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22message\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22message-text\x20text-1\x22>','\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22toast-content\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22icon\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<i\x20class=\x22','8ijGyDq','toast-','7511463lahDnG','.toast-close','\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22toast\x22\x20id=\x22','10992TjaZtH','30563SETBHB','</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22message-text\x20text-2\x22>','5GqijzQ','971916BieQyK','removeClass','.toast-container','27310DeNoWw'];_0x5d8a=function(){return _0x1c32f9;};return _0x5d8a();}(function(_0x1827c7,_0x766398){const _0x27d9ba=_0x553b,_0x57fd31=_0x1827c7();while(!![]){try{const _0x31012d=-parseInt(_0x27d9ba(0x160))/0x1*(parseInt(_0x27d9ba(0x15b))/0x2)+parseInt(_0x27d9ba(0x158))/0x3+parseInt(_0x27d9ba(0x163))/0x4*(-parseInt(_0x27d9ba(0x171))/0x5)+-parseInt(_0x27d9ba(0x162))/0x6*(parseInt(_0x27d9ba(0x15c))/0x7)+-parseInt(_0x27d9ba(0x169))/0x8*(-parseInt(_0x27d9ba(0x16b))/0x9)+parseInt(_0x27d9ba(0x165))/0xa*(-parseInt(_0x27d9ba(0x164))/0xb)+-parseInt(_0x27d9ba(0x16e))/0xc*(-parseInt(_0x27d9ba(0x16f))/0xd);if(_0x31012d===_0x766398)break;else _0x57fd31['push'](_0x57fd31['shift']());}catch(_0x30c173){_0x57fd31['push'](_0x57fd31['shift']());}}}(_0x5d8a,0x90161));function showToast(_0x2ba221,_0x1db0d4,_0x151283){const _0x540b48=_0x553b,_0x4bea7d=_0x540b48(0x16a)+new Date()[_0x540b48(0x166)](),_0x1f58ce=_0x540b48(0x16d)+_0x4bea7d+_0x540b48(0x168)+_0x2ba221+_0x540b48(0x167)+_0x1db0d4+_0x540b48(0x170)+_0x151283+'</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<i\x20class=\x22bi\x20bi-x\x20toast-close\x22></i>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22progress\x22></div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20';$(_0x540b48(0x15a))[_0x540b48(0x161)](_0x1f58ce);const _0x32f9f3=$('#'+_0x4bea7d);setTimeout(()=>{const _0x1c9b36=_0x540b48;_0x32f9f3['addClass'](_0x1c9b36(0x15f)),_0x32f9f3['find']('.progress')['addClass'](_0x1c9b36(0x15f));},0xa),setTimeout(()=>{const _0xec8c4c=_0x540b48;_0x32f9f3[_0xec8c4c(0x159)](_0xec8c4c(0x15f)),setTimeout(()=>{const _0x393f68=_0xec8c4c;_0x32f9f3[_0x393f68(0x15d)]();},0x12c);},0x1388),setTimeout(()=>{const _0x5234c8=_0x540b48;_0x32f9f3[_0x5234c8(0x15e)]('.progress')['removeClass'](_0x5234c8(0x15f));},0x14b4),_0x32f9f3[_0x540b48(0x15e)](_0x540b48(0x16c))['on']('click',function(){const _0x2e35df=_0x540b48;_0x32f9f3[_0x2e35df(0x159)](_0x2e35df(0x15f)),setTimeout(()=>{const _0x3962c9=_0x2e35df;_0x32f9f3[_0x3962c9(0x15d)]();},0x12c);});}
  </script>
  <div class="modal fade" id="modalConteudo" tabindex="-1" aria-labelledby="modalConteudo" data-bs-backdrop="static" data-bs-keyboard="false" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
      <div class="modal-content">
      </div>
    </div>
  </div>
  <script>
    var _0x2da22d=_0x43dd;function _0x43dd(_0x56f9cd,_0x12ffb3){var _0x279609=_0x2796();return _0x43dd=function(_0x43dd32,_0x5efa92){_0x43dd32=_0x43dd32-0x1ee;var _0x26287d=_0x279609[_0x43dd32];return _0x26287d;},_0x43dd(_0x56f9cd,_0x12ffb3);}(function(_0x53f273,_0x472975){var _0x189c53=_0x43dd,_0x59a741=_0x53f273();while(!![]){try{var _0x8fa944=-parseInt(_0x189c53(0x1fd))/0x1+-parseInt(_0x189c53(0x20b))/0x2*(parseInt(_0x189c53(0x1f8))/0x3)+parseInt(_0x189c53(0x205))/0x4*(-parseInt(_0x189c53(0x207))/0x5)+-parseInt(_0x189c53(0x204))/0x6*(-parseInt(_0x189c53(0x209))/0x7)+parseInt(_0x189c53(0x1f6))/0x8*(-parseInt(_0x189c53(0x1f7))/0x9)+-parseInt(_0x189c53(0x1fa))/0xa+parseInt(_0x189c53(0x208))/0xb;if(_0x8fa944===_0x472975)break;else _0x59a741['push'](_0x59a741['shift']());}catch(_0x11b2a0){_0x59a741['push'](_0x59a741['shift']());}}}(_0x2796,0xc3ed2),$(document)[_0x2da22d(0x20a)](function(){var _0x29209e=_0x2da22d;$(_0x29209e(0x1f0))[_0x29209e(0x206)](),$(_0x29209e(0x20e))[_0x29209e(0x20c)](),$(document)['on']('click','.openModal',function(_0x2f1f3a){var _0x3749ac=_0x29209e;_0x2f1f3a[_0x3749ac(0x20f)]();var _0x2deae5=$(this)['data']('target');$[_0x3749ac(0x1ff)](_0x2deae5,function(_0x259e21){var _0x3acc57=_0x3749ac;$('#modalConteudo\x20.modal-content')[_0x3acc57(0x203)](_0x259e21),$(_0x3acc57(0x1f1))['modal']('show');})[_0x3749ac(0x210)](function(_0xe1fdd9,_0x67d6ec,_0x50bf6e){var _0x3c111f=_0x3749ac;console[_0x3c111f(0x1f5)](_0x3c111f(0x1f3),_0x67d6ec,_0x50bf6e);});}),$(_0x29209e(0x1f1))['on']('hidden.bs.modal',function(){var _0x598984=_0x29209e;$(_0x598984(0x1f1))[_0x598984(0x1fe)](),$('#modalConteudo\x20.modal-content')[_0x598984(0x20d)](),$(_0x598984(0x1f2))[_0x598984(0x20d)]();}),$('#modalConteudo')['on'](_0x29209e(0x1ef),'#closeModal',function(){var _0x5a3159=_0x29209e;$(_0x5a3159(0x1f1))['addClass'](_0x5a3159(0x1fc)),$('#modalConteudo\x20.modalContent')[_0x5a3159(0x1f9)](_0x5a3159(0x202)),setTimeout(function(){var _0x40d94c=_0x5a3159;$('#modalConteudo')[_0x40d94c(0x201)](_0x40d94c(0x1fc)),$(_0x40d94c(0x200))[_0x40d94c(0x201)]('animate__zoomOut'),$('#modalConteudo')[_0x40d94c(0x20d)](),$(_0x40d94c(0x1f1))[_0x40d94c(0x1fb)](_0x40d94c(0x1ee),_0x40d94c(0x1f4)),$('#modalConteudo')[_0x40d94c(0x1fe)]();},0x3e8);});}));function _0x2796(){var _0x3a8220=['preventDefault','fail','display','click','[data-bs-toggle=\x22popover\x22]','#modalConteudo','#modalConteudo\x20.modal-footer','Erro\x20ao\x20carregar\x20o\x20modal:','none','error','1646632njQbrG','9WzWKMo','7644bcfCdN','addClass','8280060LwmgxF','css','animate__fadeOut','1039560bOSkeh','off','get','#modalConteudo\x20.modalContent','removeClass','animate__zoomOut','html','114rtdizd','4YvauSn','popover','5387870xAaISk','34490346dmfNQY','573601tDjsSF','ready','580ZzmsdV','tooltip','empty','[data-bs-toggle=\x22tooltip\x22]'];_0x2796=function(){return _0x3a8220;};return _0x2796();}
  </script>
  <script>
    function _0x40da(){const _0x536da5=['warning','407AabLtB','9749993GSxGbD','509796GAJYHH','error','374152qZZLWt','POST','success','Erro\x20ao\x20remover\x20','7wqGsTk','libs/funcoes/excluir_permissao','querySelectorAll','remove','#3085d6','Webhook','json','1262sWIUCm','click','id=','closest','ipIndex=','\x20removido\x20com\x20sucesso!','30BStVNh','4455xLTnxW','1808mIvwka','1636686xOPINj','3701340qTkNAx','Sim,\x20exclua!','fire','.excluir','bi\x20bi-check-lg','includes','then','application/x-www-form-urlencoded','dataset','querySelector','bi\x20bi-exclamation-lg'];_0x40da=function(){return _0x536da5;};return _0x40da();}const _0x5b9784=_0x38f0;(function(_0x3564a4,_0x164e66){const _0x382fdc=_0x38f0,_0x56afd5=_0x3564a4();while(!![]){try{const _0x5d9085=-parseInt(_0x382fdc(0x14e))/0x1*(parseInt(_0x382fdc(0x15d))/0x2)+parseInt(_0x382fdc(0x150))/0x3+parseInt(_0x382fdc(0x152))/0x4*(parseInt(_0x382fdc(0x13e))/0x5)+-parseInt(_0x382fdc(0x141))/0x6*(-parseInt(_0x382fdc(0x156))/0x7)+-parseInt(_0x382fdc(0x140))/0x8*(-parseInt(_0x382fdc(0x13f))/0x9)+parseInt(_0x382fdc(0x142))/0xa+-parseInt(_0x382fdc(0x14f))/0xb;if(_0x5d9085===_0x164e66)break;else _0x56afd5['push'](_0x56afd5['shift']());}catch(_0x426514){_0x56afd5['push'](_0x56afd5['shift']());}}}(_0x40da,0x53aed));function _0x38f0(_0x58a713,_0x326a95){const _0x40da77=_0x40da();return _0x38f0=function(_0x38f035,_0x15509f){_0x38f035=_0x38f035-0x13c;let _0xa16369=_0x40da77[_0x38f035];return _0xa16369;},_0x38f0(_0x58a713,_0x326a95);}const excluirIcons=document[_0x5b9784(0x158)](_0x5b9784(0x145));excluirIcons['forEach'](_0x432c97=>{const _0x4ac6e9=_0x5b9784;_0x432c97['addEventListener'](_0x4ac6e9(0x15e),()=>{const _0x5d3f10=_0x4ac6e9,_0xb0c87=_0x432c97[_0x5d3f10(0x160)]('tr'),_0x15bf69=_0xb0c87[_0x5d3f10(0x160)]('table')[_0x5d3f10(0x14b)]('th')['textContent'][_0x5d3f10(0x147)]('IP'),_0x53e957=_0xb0c87[_0x5d3f10(0x14a)]['id'],_0x425d9a=_0xb0c87[_0x5d3f10(0x14a)]['index'];Swal[_0x5d3f10(0x144)]({'title':'Tem\x20certeza?','text':'Você\x20não\x20poderá\x20reverter\x20isso!','icon':_0x5d3f10(0x14d),'showCancelButton':!![],'confirmButtonColor':_0x5d3f10(0x15a),'cancelButtonColor':'#d33','confirmButtonText':_0x5d3f10(0x143)})[_0x5d3f10(0x148)](_0x24a8cf=>{const _0x439ffb=_0x5d3f10;_0x24a8cf['isConfirmed']&&fetch(_0x439ffb(0x157),{'method':_0x439ffb(0x153),'headers':{'Content-Type':_0x439ffb(0x149)},'body':'action=delete&'+(_0x15bf69?_0x439ffb(0x13c)+encodeURIComponent(_0x425d9a):_0x439ffb(0x15f)+encodeURIComponent(_0x53e957))})['then'](_0x5d8121=>_0x5d8121[_0x439ffb(0x15c)]())['then'](_0x430f90=>{const _0x198483=_0x439ffb;_0x430f90[_0x198483(0x154)]?(showToast(_0x198483(0x146),'Sucesso',(_0x15bf69?'IP':'Webhook')+_0x198483(0x13d)),_0x432c97[_0x198483(0x160)]('tr')[_0x198483(0x159)]()):showToast(_0x198483(0x14c),'Erro',_0x198483(0x155)+(_0x15bf69?'IP':_0x198483(0x15b))+':\x20'+_0x430f90[_0x198483(0x151)]);});});});});
    
  </script>
</body>

</html>