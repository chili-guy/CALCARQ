<?php
session_start();

if (isset($_SESSION['user_id'])) {
    header("Location: /");
    exit();
}
?>
<html lang="pt-br" dir="ltr" data-nav-layout="horizontal" data-theme-mode="light" data-header-styles="light" data-menu-styles="light" data-toggled="close">

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">


    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title> <?php include 'libs/get_site_name.php'; ?> - Registre-se </title>

    <meta name="Description" content="Dashboard principal do gateway de pagamento <?php include 'libs/get_site_name.php'; ?>">

    <meta name="Author" content="PixPay">

	<meta name="keywords" content="Gateway de pagamento">

    <link rel="icon" href="/imagens/logoo.png" type="image/x-icon">

    <script src="assets/js/authentication-main.js"></script>

    <link id="style" href="assets/libs/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <?php include 'libs/config_css.php'; ?>

    <link href="assets/css/icons.css" rel="stylesheet">

    <?php
    try {
        // Definir variáveis de conexão
        $dbHost = $_ENV['DB_HOST'];
        $dbnome = $_ENV['DB_NAME'];
        $dbUser = $_ENV['DB_USER'];
        $dbPass = $_ENV['DB_PASS'];

        // Conectar ao banco de dados
        $dsn = "mysql:host=$dbHost;dbname=$dbnome;charset=utf8";
        $pdo = new PDO($dsn, $dbUser, $dbPass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        
    } catch (PDOException $e) {
        die("Erro ao conectar ao banco de dados: " . $e->getMessage());
    }
    ?>

    
    
 <style>
    body {
        font-family: Arial, sans-serif;
        background-color: #121212; /* Fundo escuro */
        color: #ffffff; /* Texto branco */
        margin: 0;
        padding: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
    }

    .login-wrapper {
        display: flex;
        flex-direction: row; /* Alinha a imagem e o formulário lado a lado */
        width: 90%;
        max-width: 900px;
        background-color: #1e1e1e; /* Fundo mais claro */
        border-radius: 8px;
        padding: 20px;
        box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.7);
    }

   

    .login-form {
        flex: 1;
        display: flex;
        flex-direction: column;
        justify-content: center;
        padding: 20px;
    }

    .login-form h1 {
        font-size: 24px;
        margin-bottom: 15px;
        text-align: center;
    }

    .login-form p {
        font-size: 14px;
        margin-bottom: 20px;
        text-align: center;
    }

    .login-form label {
        font-size: 14px;
        margin-bottom: 5px;
        display: block;
        color: #ffffff; /* Texto branco */
    }

    .login-form input,
    .login-form select {
        width: 100%;
        padding: 12px;
        margin-bottom: 15px;
        border: 1px solid #333;
        border-radius: 5px;
        background-color: #2a2a2a; /* Fundo dos campos */
        color: #ffffff; /* Texto branco */
        font-size: 16px;
    }

    .login-form input::placeholder,
    .login-form select::placeholder {
        color: #ffffff; /* Placeholder branco */
    }

    .login-form input[type="submit"] {
        width: 100%;
        padding: 12px;
        background-color: #007bff; /* Azul */
        border: none;
        border-radius: 5px;
        color: #ffffff; /* Texto branco */
        font-size: 16px;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }

    .login-form input[type="submit"]:hover {
        background-color: #0056b3; /* Azul mais escuro */
    }

    .login-form a {
        display: block;
        text-align: center;
        color: #007bff; /* Azul */
        text-decoration: none;
        margin-top: 10px;
        font-size: 14px;
    }

    .login-form a:hover {
        text-decoration: underline;
    }

    .form-check-label {
        color: #b3b3b3; /* Texto mais claro */
        font-size: 14px;
    }

    /* Tornar o layout mais responsivo */
    @media (max-width: 768px) {
        .login-wrapper {
            flex-direction: column; /* Empilha a imagem e o formulário em telas pequenas */
            width: 100%;
        }

        .login-image {
            height: 200px; /* Reduz a altura da imagem */
            margin-right: 0;
            margin-bottom: 20px; /* Espaço abaixo da imagem */
        }

        .login-form h1 {
            font-size: 20px;
        }

        .login-form input,
        .login-form select {
            font-size: 14px;
            padding: 10px;
        }

        .login-form input[type="submit"] {
            font-size: 14px;
        }

        .login-form a {
            font-size: 12px;
        }
    }

    @media (max-width: 480px) {
        .login-image {
            height: 150px; /* Reduz ainda mais a imagem */
        }

        .login-form h1 {
            font-size: 18px;
        }

        .login-form p {
            font-size: 12px;
        }

        .login-form input,
        .login-form select {
            font-size: 12px;
            padding: 8px;
        }

        .login-form input[type="submit"] {
            font-size: 12px;
            padding: 10px;
        }

        .login-form a {
            font-size: 10px;
        }
    }
</style>

    <script>
        function togglePasswordVisibility(inputId, button) {
            const input = document.getElementById(inputId);
            const isPassword = input.type === 'password';
            input.type = isPassword ? 'text' : 'password';
            button.innerHTML = isPassword ? '<i class="ri-eye-line"></i>' : '<i class="ri-eye-off-line"></i>';
        }
    </script>
    
    
  

   
    
    
</head>

<body>
    <div class="login-wrapper">
        <div class="login-image"></div>
        <div class="login-form">
            <h1>Olha que Legal! 🎉</h1>
            <p>Falta só mais um passo para o seu Futuro! <?php include 'libs/get_site_name.php'; ?>. 🚀</p>
            <form action="register.php" method="POST">
                
                <!-- Nome Completo -->
                <label for="nome_completo" class="form-label text-default" >Nome completo<sup>*</sup></label>
                <input type="text" class="form-control form-control-lg" name="nome" id="nome_completo" placeholder="Henrique Lima" required style="color: #ffffff; background-color: #2a2a2a; border: 1px solid #333;">

                
                <!-- Nome de Usuário -->
                <label for="usuario" class="form-label text-default">Nome de usuário<sup>*</sup></label>
                <input type="text" class="form-control form-control-lg" name="usuario" id="usuario" placeholder="@henriquelima2024" required>
                
                <!-- E-mail -->
                <label for="email" class="form-label">Email<sup>*</sup></label>
                <input type="email" class="form-control form-control-lg" name="email" id="email" placeholder="joaodasilva@gmail.com" required>

                <!-- Telefone -->
                <label for="telefone" class="form-label">Telefone<sup>*</sup></label>
                <input type="text" class="form-control form-control-lg" name="telefone" id="telefone" placeholder="(31) 91122-3445" inputmode="text" required>
                
                <!-- CNPJ ou CPF -->
                <label for="cnpj" class="form-label">CNPJ ou CPF<sup>*</sup></label>
                <input type="text" class="form-control form-control-lg" name="cnpj" id="cnpj" placeholder="12.345.678/0001-00" required>
                
                <!-- Faturamento Mensal -->
                <label for="faturamento" class="form-label text-default">Quanto você fatura por mês?<sup>*</sup></label>
                <select class="form-select" name="faturamento" id="faturamento" required>
                    <option value="0">Sem faturamento</option>
                    <option value="1">Abaixo de 100 mil</option>
                    <option value="2">Entre 100 e 500 mil</option>
                    <option value="3">Entre 500 e 1 milhão</option>
                    <option selected value="4">Entre 1 e 5 milhões</option>
                    <option value="5">Mais de 5 milhões</option>
                </select>
                
                <!-- Senha -->
                <label for="senha" class="form-label">Senha<sup>*</sup></label>
                <div style="position: relative;">
                    <input type="password" class="form-control form-control-lg" name="senha" id="senha" placeholder="Senha" required>
                    <button type="button" onclick="togglePasswordVisibility('senha', this)" style="position: absolute; right: 10px; top: 50%; transform: translateY(-50%); border: none; background: transparent; cursor: pointer;">
                        <i class="ri-eye-off-line"></i>
                    </button>
                </div>
                
                <!-- Confirmar Senha -->
                <label for="confirmar_senha" class="form-label text-default">Confirme a senha<sup>*</sup></label>
                <div style="position: relative;">
                    <input type="password" class="form-control form-control-lg" name="confirmar_senha" id="confirmar_senha" placeholder="Confirme a senha" required>
                    <button type="button" onclick="togglePasswordVisibility('confirmar_senha', this)" style="position: absolute; right: 10px; top: 50%; transform: translateY(-50%); border: none; background: transparent; cursor: pointer;">
                        <i class="ri-eye-off-line"></i>
                    </button>
                </div>
              <!-- Concordo com os Termos -->
<div class="col-xl-12 d-flex align-items-center mt-3">
    <div class="form-check">
        <input class="form-check-input" type="checkbox" name="termos" value="1" id="concordo_termos" required style="width: 16px; height: 16px; margin-right: 8px;">
        <label class="form-check-label text-muted fw-normal" for="concordo_termos">
            Eu li e concordo com os <a href="#" class="text-success" data-bs-toggle="modal" data-bs-target="#termosModal"><u>Termos e Condições</u></a></a>
        </label>
    </div>
</div>

<!-- Modal dos Termos de Uso -->
<div class="modal fade" id="termosModal" tabindex="-1" aria-labelledby="termosModalLabel" data-bs-backdrop="static" data-bs-keyboard="false" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="termosModalLabel">Termos e Condições</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>Termos de Uso do PixPay</p>
                
                
                <p>1. Aceitação dos Termos

Ao acessar e utilizar os serviços oferecidos pela PixPay, você concorda em cumprir estes Termos de Uso, juntamente com nossa Política de Privacidade. Caso não concorde com estes termos, você não poderá usar nossos serviços.</p>


 <p>2. Serviços Oferecidos </p>
 
<p>A PixPay é um gateway de pagamento que facilita transações financeiras entre consumidores e empresas. Nosso serviço permite que você realize pagamentos de maneira rápida, segura e confiável através de diversas formas de pagamento, como cartões de crédito, transferências bancárias e outras opções.</p>
 
 </p>



                <img src="imagens/log.png" alt="Imagem dos Termos e Condições" style="width: 100%; height: auto; max-height: 250px; object-fit: contain;">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
            </div>
        </div>
    </div>
</div>

                    <input type="submit" id="cadastro-button" value="Cadastrar" class="btn btn-primary ms-3" />
                    
                     <!-- Link para Login -->
            <a href="login">Já tenho uma Conta</a>
        </div>
                </div>
            </form>

           
    </div>

    <script>
        // Função para alternar a visibilidade da senha
        function togglePasswordVisibility(id, button) {
            var input = document.getElementById(id);
            var icon = button.querySelector('i');

            if (input.type === "password") {
                input.type = "text";
                icon.className = "ri-eye-line";  // Ícone para "mostrar"
            } else {
                input.type = "password";
                icon.className = "ri-eye-off-line";  // Ícone para "esconder"
            }
        }
    </script>
</body>
</html>


<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>

    <script src="assets/js/show-password.js"></script>

    <script src="assets/js/inputmask.js"></script>

    <div class="modal fade" id="modalConteudo" tabindex="-1" aria-labelledby="modalConteudo" data-bs-backdrop="static" data-bs-keyboard="false" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">
        </div>
    </div>
</div>
<script>
    var _0x2da22d=_0x43dd;function _0x43dd(_0x56f9cd,_0x12ffb3){var _0x279609=_0x2796();return _0x43dd=function(_0x43dd32,_0x5efa92){_0x43dd32=_0x43dd32-0x1ee;var _0x26287d=_0x279609[_0x43dd32];return _0x26287d;},_0x43dd(_0x56f9cd,_0x12ffb3);}(function(_0x53f273,_0x472975){var _0x189c53=_0x43dd,_0x59a741=_0x53f273();while(!![]){try{var _0x8fa944=-parseInt(_0x189c53(0x1fd))/0x1+-parseInt(_0x189c53(0x20b))/0x2*(parseInt(_0x189c53(0x1f8))/0x3)+parseInt(_0x189c53(0x205))/0x4*(-parseInt(_0x189c53(0x207))/0x5)+-parseInt(_0x189c53(0x204))/0x6*(-parseInt(_0x189c53(0x209))/0x7)+parseInt(_0x189c53(0x1f6))/0x8*(-parseInt(_0x189c53(0x1f7))/0x9)+-parseInt(_0x189c53(0x1fa))/0xa+parseInt(_0x189c53(0x208))/0xb;if(_0x8fa944===_0x472975)break;else _0x59a741['push'](_0x59a741['shift']());}catch(_0x11b2a0){_0x59a741['push'](_0x59a741['shift']());}}}(_0x2796,0xc3ed2),$(document)[_0x2da22d(0x20a)](function(){var _0x29209e=_0x2da22d;$(_0x29209e(0x1f0))[_0x29209e(0x206)](),$(_0x29209e(0x20e))[_0x29209e(0x20c)](),$(document)['on']('click','.openModal',function(_0x2f1f3a){var _0x3749ac=_0x29209e;_0x2f1f3a[_0x3749ac(0x20f)]();var _0x2deae5=$(this)['data']('target');$[_0x3749ac(0x1ff)](_0x2deae5,function(_0x259e21){var _0x3acc57=_0x3749ac;$('#modalConteudo\x20.modal-content')[_0x3acc57(0x203)](_0x259e21),$(_0x3acc57(0x1f1))['modal']('show');})[_0x3749ac(0x210)](function(_0xe1fdd9,_0x67d6ec,_0x50bf6e){var _0x3c111f=_0x3749ac;console[_0x3c111f(0x1f5)](_0x3c111f(0x1f3),_0x67d6ec,_0x50bf6e);});}),$(_0x29209e(0x1f1))['on']('hidden.bs.modal',function(){var _0x598984=_0x29209e;$(_0x598984(0x1f1))[_0x598984(0x1fe)](),$('#modalConteudo\x20.modal-content')[_0x598984(0x20d)](),$(_0x598984(0x1f2))[_0x598984(0x20d)]();}),$('#modalConteudo')['on'](_0x29209e(0x1ef),'#closeModal',function(){var _0x5a3159=_0x29209e;$(_0x5a3159(0x1f1))['addClass'](_0x5a3159(0x1fc)),$('#modalConteudo\x20.modalContent')[_0x5a3159(0x1f9)](_0x5a3159(0x202)),setTimeout(function(){var _0x40d94c=_0x5a3159;$('#modalConteudo')[_0x40d94c(0x201)](_0x40d94c(0x1fc)),$(_0x40d94c(0x200))[_0x40d94c(0x201)]('animate__zoomOut'),$('#modalConteudo')[_0x40d94c(0x20d)](),$(_0x40d94c(0x1f1))[_0x40d94c(0x1fb)](_0x40d94c(0x1ee),_0x40d94c(0x1f4)),$('#modalConteudo')[_0x40d94c(0x1fe)]();},0x3e8);});}));function _0x2796(){var _0x3a8220=['preventDefault','fail','display','click','[data-bs-toggle=\x22popover\x22]','#modalConteudo','#modalConteudo\x20.modal-footer','Erro\x20ao\x20carregar\x20o\x20modal:','none','error','1646632njQbrG','9WzWKMo','7644bcfCdN','addClass','8280060LwmgxF','css','animate__fadeOut','1039560bOSkeh','off','get','#modalConteudo\x20.modalContent','removeClass','animate__zoomOut','html','114rtdizd','4YvauSn','popover','5387870xAaISk','34490346dmfNQY','573601tDjsSF','ready','580ZzmsdV','tooltip','empty','[data-bs-toggle=\x22tooltip\x22]'];_0x2796=function(){return _0x3a8220;};return _0x2796();}
</script>
<?php include 'includes/includes_popup.php'; ?>

<div class="toast-container"></div>
<script>
    function _0x553b(_0x2e5c0a,_0x2e7c71){const _0x5d8a02=_0x5d8a();return _0x553b=function(_0x553b9c,_0x101e05){_0x553b9c=_0x553b9c-0x158;let _0x3fb95a=_0x5d8a02[_0x553b9c];return _0x3fb95a;},_0x553b(_0x2e5c0a,_0x2e7c71);}function _0x5d8a(){const _0x1c32f9=['4314338dyFgoH','remove','find','active','47jOpOel','append','6AlcdiJ','1704916uZVurw','110BcUHGs','1037570sCalrz','getTime','\x20toast-check\x22></i>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22message\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22message-text\x20text-1\x22>','\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22toast-content\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22icon\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<i\x20class=\x22','8ijGyDq','toast-','7511463lahDnG','.toast-close','\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22toast\x22\x20id=\x22','10992TjaZtH','30563SETBHB','</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<span\x20class=\x22message-text\x20text-2\x22>','5GqijzQ','971916BieQyK','removeClass','.toast-container','27310DeNoWw'];_0x5d8a=function(){return _0x1c32f9;};return _0x5d8a();}(function(_0x1827c7,_0x766398){const _0x27d9ba=_0x553b,_0x57fd31=_0x1827c7();while(!![]){try{const _0x31012d=-parseInt(_0x27d9ba(0x160))/0x1*(parseInt(_0x27d9ba(0x15b))/0x2)+parseInt(_0x27d9ba(0x158))/0x3+parseInt(_0x27d9ba(0x163))/0x4*(-parseInt(_0x27d9ba(0x171))/0x5)+-parseInt(_0x27d9ba(0x162))/0x6*(parseInt(_0x27d9ba(0x15c))/0x7)+-parseInt(_0x27d9ba(0x169))/0x8*(-parseInt(_0x27d9ba(0x16b))/0x9)+parseInt(_0x27d9ba(0x165))/0xa*(-parseInt(_0x27d9ba(0x164))/0xb)+-parseInt(_0x27d9ba(0x16e))/0xc*(-parseInt(_0x27d9ba(0x16f))/0xd);if(_0x31012d===_0x766398)break;else _0x57fd31['push'](_0x57fd31['shift']());}catch(_0x30c173){_0x57fd31['push'](_0x57fd31['shift']());}}}(_0x5d8a,0x90161));function showToast(_0x2ba221,_0x1db0d4,_0x151283){const _0x540b48=_0x553b,_0x4bea7d=_0x540b48(0x16a)+new Date()[_0x540b48(0x166)](),_0x1f58ce=_0x540b48(0x16d)+_0x4bea7d+_0x540b48(0x168)+_0x2ba221+_0x540b48(0x167)+_0x1db0d4+_0x540b48(0x170)+_0x151283+'</span>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<i\x20class=\x22bi\x20bi-x\x20toast-close\x22></i>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22progress\x22></div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20';$(_0x540b48(0x15a))[_0x540b48(0x161)](_0x1f58ce);const _0x32f9f3=$('#'+_0x4bea7d);setTimeout(()=>{const _0x1c9b36=_0x540b48;_0x32f9f3['addClass'](_0x1c9b36(0x15f)),_0x32f9f3['find']('.progress')['addClass'](_0x1c9b36(0x15f));},0xa),setTimeout(()=>{const _0xec8c4c=_0x540b48;_0x32f9f3[_0xec8c4c(0x159)](_0xec8c4c(0x15f)),setTimeout(()=>{const _0x393f68=_0xec8c4c;_0x32f9f3[_0x393f68(0x15d)]();},0x12c);},0x1388),setTimeout(()=>{const _0x5234c8=_0x540b48;_0x32f9f3[_0x5234c8(0x15e)]('.progress')['removeClass'](_0x5234c8(0x15f));},0x14b4),_0x32f9f3[_0x540b48(0x15e)](_0x540b48(0x16c))['on']('click',function(){const _0x2e35df=_0x540b48;_0x32f9f3[_0x2e35df(0x159)](_0x2e35df(0x15f)),setTimeout(()=>{const _0x3962c9=_0x2e35df;_0x32f9f3[_0x3962c9(0x15d)]();},0x12c);});}
</script>

    <script>

        const _0x3df67c=_0x3767;function _0x3767(_0x11eafb,_0x1e57da){const _0xc7e8e7=_0xc7e8();return _0x3767=function(_0x37672b,_0x41fee7){_0x37672b=_0x37672b-0x1e3;let _0x31ff30=_0xc7e8e7[_0x37672b];return _0x31ff30;},_0x3767(_0x11eafb,_0x1e57da);}function _0xc7e8(){const _0x4cd66b=['#nome_completo','ready','termos','cnpj','$1.$2.$3','Sucesso','As\x20senhas\x20não\x20coincidem','bi\x20bi-exclamation-triangle','#usuario','status','2879866LEgTav','telefone','substring','109821pMwUvs','905292KCwrxg','CPF\x20inválido','434TrFVBP','location','error','950732CmbXJE','90096wJDOzy','4639936QKqesv','confirmar_senha','Preencha\x20todos\x20os\x20dados\x20corretamente','length','1411450qWwWbz','#email','href','val','charAt','15vgMlRr','stringify','email','Cadastro\x20realizado','nome','#concordo_termos','POST','input','Redirecionando...','10PfxLlI','#telefone','#senha','inputmask',':checked','$1.$2','20sBTKAq','preventDefault','#confirmar_senha','responseText','success','usuario','bi\x20bi-check-lg','Erro','#cadastro-button','senha','test','#faturamento','replace','application/json','$1-$2'];_0xc7e8=function(){return _0x4cd66b;};return _0xc7e8();}(function(_0x5b4e1c,_0x434564){const _0x2cccc0=_0x3767,_0xb3ba9f=_0x5b4e1c();while(!![]){try{const _0x1b37ca=parseInt(_0x2cccc0(0x20e))/0x1*(parseInt(_0x2cccc0(0x1f2))/0x2)+parseInt(_0x2cccc0(0x1e3))/0x3*(parseInt(_0x2cccc0(0x214))/0x4)+-parseInt(_0x2cccc0(0x21a))/0x5+parseInt(_0x2cccc0(0x215))/0x6*(-parseInt(_0x2cccc0(0x211))/0x7)+-parseInt(_0x2cccc0(0x216))/0x8+parseInt(_0x2cccc0(0x20f))/0x9*(-parseInt(_0x2cccc0(0x1ec))/0xa)+parseInt(_0x2cccc0(0x20b))/0xb;if(_0x1b37ca===_0x434564)break;else _0xb3ba9f['push'](_0xb3ba9f['shift']());}catch(_0x44060d){_0xb3ba9f['push'](_0xb3ba9f['shift']());}}}(_0xc7e8,0x9fce9),$(document)[_0x3df67c(0x202)](function(){const _0x1faa1f=_0x3df67c;$(_0x1faa1f(0x209))['on'](_0x1faa1f(0x1ea),function(){const _0xada970=_0x1faa1f;var _0x9b71b6=$(this)[_0xada970(0x21d)](),_0x47114e=_0x9b71b6['replace'](/[^a-zA-Z0-9]/g,'');$(this)[_0xada970(0x21d)](_0x47114e);}),$(_0x1faa1f(0x1ed))[_0x1faa1f(0x1ef)]('(99)\x2099999-9999');function _0x98aea7(_0x478018){const _0x527687=_0x1faa1f;return _0x478018=_0x478018[_0x527687(0x1fe)](/\D/g,''),_0x478018['length']<=0xb?(_0x478018=_0x478018[_0x527687(0x1fe)](/(\d{3})(\d)/,_0x527687(0x1f1)),_0x478018=_0x478018[_0x527687(0x1fe)](/(\d{3})(\d)/,'$1.$2'),_0x478018=_0x478018['replace'](/(\d{3})(\d{1,2})$/,_0x527687(0x200))):(_0x478018=_0x478018['replace'](/^(\d{2})(\d)/,_0x527687(0x1f1)),_0x478018=_0x478018[_0x527687(0x1fe)](/^(\d{2})\.(\d{3})(\d)/,_0x527687(0x205)),_0x478018=_0x478018[_0x527687(0x1fe)](/\.(\d{3})(\d)/,'.$1/$2'),_0x478018=_0x478018[_0x527687(0x1fe)](/(\d{4})(\d)/,_0x527687(0x200))),_0x478018;}function _0x219843(_0x2d913e){const _0x2cad39=_0x1faa1f;_0x2d913e=_0x2d913e['replace'](/[^\d]+/g,'');if(_0x2d913e[_0x2cad39(0x219)]!==0xb||/^(\d)\1+$/[_0x2cad39(0x1fc)](_0x2d913e))return![];let _0x190d17=0x0,_0x40d4b7;for(let _0x135807=0x1;_0x135807<=0x9;_0x135807++)_0x190d17+=parseInt(_0x2d913e[_0x2cad39(0x20d)](_0x135807-0x1,_0x135807))*(0xb-_0x135807);_0x40d4b7=_0x190d17*0xa%0xb;if(_0x40d4b7===0xa||_0x40d4b7===0xb)_0x40d4b7=0x0;if(_0x40d4b7!==parseInt(_0x2d913e[_0x2cad39(0x20d)](0x9,0xa)))return![];_0x190d17=0x0;for(let _0x5ba497=0x1;_0x5ba497<=0xa;_0x5ba497++)_0x190d17+=parseInt(_0x2d913e['substring'](_0x5ba497-0x1,_0x5ba497))*(0xc-_0x5ba497);_0x40d4b7=_0x190d17*0xa%0xb;if(_0x40d4b7===0xa||_0x40d4b7===0xb)_0x40d4b7=0x0;if(_0x40d4b7!==parseInt(_0x2d913e['substring'](0xa,0xb)))return![];return!![];}function _0x4c7a76(_0x451c2f){const _0x2b37d2=_0x1faa1f;_0x451c2f=_0x451c2f['replace'](/[^\d]+/g,'');if(_0x451c2f['length']!==0xe)return![];let _0x3465ac=_0x451c2f['length']-0x2,_0x266a11=_0x451c2f[_0x2b37d2(0x20d)](0x0,_0x3465ac),_0x1b3e6e=_0x451c2f[_0x2b37d2(0x20d)](_0x3465ac),_0x4c343c=0x0,_0x4e1f5c=_0x3465ac-0x7;for(let _0x15236c=_0x3465ac;_0x15236c>=0x1;_0x15236c--){_0x4c343c+=_0x266a11[_0x2b37d2(0x21e)](_0x3465ac-_0x15236c)*_0x4e1f5c--;if(_0x4e1f5c<0x2)_0x4e1f5c=0x9;}let _0x1d0462=_0x4c343c%0xb<0x2?0x0:0xb-_0x4c343c%0xb;if(_0x1d0462!==parseInt(_0x1b3e6e[_0x2b37d2(0x21e)](0x0)))return![];_0x3465ac=_0x3465ac+0x1,_0x266a11=_0x451c2f[_0x2b37d2(0x20d)](0x0,_0x3465ac),_0x4c343c=0x0,_0x4e1f5c=_0x3465ac-0x7;for(let _0x287daa=_0x3465ac;_0x287daa>=0x1;_0x287daa--){_0x4c343c+=_0x266a11[_0x2b37d2(0x21e)](_0x3465ac-_0x287daa)*_0x4e1f5c--;if(_0x4e1f5c<0x2)_0x4e1f5c=0x9;}_0x1d0462=_0x4c343c%0xb<0x2?0x0:0xb-_0x4c343c%0xb;if(_0x1d0462!==parseInt(_0x1b3e6e[_0x2b37d2(0x21e)](0x1)))return![];return!![];}$('#cnpj')['on'](_0x1faa1f(0x1ea),function(){const _0x4758aa=_0x1faa1f;var _0x5d661e=$(this)[_0x4758aa(0x21d)](),_0x3661fa=_0x5d661e[_0x4758aa(0x1fe)](/\D/g,'');_0x3661fa[_0x4758aa(0x219)]>0xe&&(_0x3661fa=_0x3661fa[_0x4758aa(0x20d)](0x0,0xe));var _0x4a90e6=_0x98aea7(_0x3661fa);$(this)['val'](_0x4a90e6);}),$(_0x1faa1f(0x1fa))['on']('click',function(_0x5341cb){const _0x3aaa75=_0x1faa1f;_0x5341cb[_0x3aaa75(0x1f3)]();var _0x1f90d7={'nome':$(_0x3aaa75(0x201))['val'](),'email':$(_0x3aaa75(0x21b))[_0x3aaa75(0x21d)](),'telefone':$('#telefone')['val'](),'usuario':$(_0x3aaa75(0x209))[_0x3aaa75(0x21d)](),'cnpj':$('#cnpj')[_0x3aaa75(0x21d)](),'faturamento':$(_0x3aaa75(0x1fd))[_0x3aaa75(0x21d)](),'senha':$(_0x3aaa75(0x1ee))['val'](),'confirmar_senha':$(_0x3aaa75(0x1f4))[_0x3aaa75(0x21d)](),'termos':$(_0x3aaa75(0x1e8))['is'](_0x3aaa75(0x1f0))};if(!_0x1f90d7[_0x3aaa75(0x1e7)]||!_0x1f90d7[_0x3aaa75(0x1e5)]||!_0x1f90d7[_0x3aaa75(0x20c)]||!_0x1f90d7[_0x3aaa75(0x1f7)]||!_0x1f90d7[_0x3aaa75(0x204)]||!_0x1f90d7[_0x3aaa75(0x1fb)]||!_0x1f90d7['confirmar_senha']||!_0x1f90d7[_0x3aaa75(0x203)]){showToast(_0x3aaa75(0x208),_0x3aaa75(0x1f9),_0x3aaa75(0x218));return;}if(_0x1f90d7[_0x3aaa75(0x1fb)]!==_0x1f90d7[_0x3aaa75(0x217)]){showToast(_0x3aaa75(0x208),_0x3aaa75(0x1f9),_0x3aaa75(0x207));return;}var _0x1d6329=_0x1f90d7[_0x3aaa75(0x204)][_0x3aaa75(0x219)]<=0xe?_0x219843(_0x1f90d7[_0x3aaa75(0x204)]):_0x4c7a76(_0x1f90d7[_0x3aaa75(0x204)]);if(!_0x1d6329){showToast(_0x3aaa75(0x208),'Erro',_0x1f90d7[_0x3aaa75(0x204)][_0x3aaa75(0x219)]<=0xe?_0x3aaa75(0x210):'CNPJ\x20inválido');return;}$['ajax']({'url':'libs/funcoes/valida_cadastro','type':_0x3aaa75(0x1e9),'contentType':_0x3aaa75(0x1ff),'data':JSON[_0x3aaa75(0x1e4)](_0x1f90d7),'success':function(_0x5af8fe){const _0x12c0d1=_0x3aaa75;var _0x896e52=JSON['parse'](_0x5af8fe);_0x896e52[_0x12c0d1(0x20a)]===_0x12c0d1(0x1f6)?(showToast(_0x12c0d1(0x1f8),_0x12c0d1(0x206),_0x12c0d1(0x1e6)),setTimeout(()=>{const _0x1d3e7f=_0x12c0d1;showToast(_0x1d3e7f(0x1f8),_0x1d3e7f(0x206),_0x1d3e7f(0x1eb));},0x3e8),setTimeout(()=>{const _0x350719=_0x12c0d1;window[_0x350719(0x212)][_0x350719(0x21c)]='./';},0x5dc)):showToast('bi\x20bi-exclamation-triangle',_0x12c0d1(0x1f9),_0x896e52['message']);},'error':function(_0x3098f0,_0x3c7b6b,_0x46cc78){const _0x535159=_0x3aaa75;console[_0x535159(0x213)](_0x3098f0[_0x535159(0x1f5)]),showToast('bi\x20bi-exclamation-triangle','Erro',_0x3098f0[_0x535159(0x1f5)]);}});});}));

    </script>



</body></html>