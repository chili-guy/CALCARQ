// Exports the "media" plugin for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/plugins/media')
//   ES2015:
//     import 'tinymce/plugins/media'
require('./plugin.js');