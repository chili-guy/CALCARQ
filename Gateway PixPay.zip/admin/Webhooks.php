<?php
session_start();

// Verificar se o usuário está autenticado
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login');
    exit;
}


use Dotenv\Dotenv;

require __DIR__ . '/../vendor/autoload.php';

$dotenv = Dotenv::createImmutable(__DIR__ . '/../');
$dotenv->load();

try {
    $dbHost = $_ENV['DB_HOST'];
    $dbnome = $_ENV['DB_NAME'];
    $dbUser = $_ENV['DB_USER'];
    $dbPass = $_ENV['DB_PASS'];

    $dsn = "mysql:host=$dbHost;dbname=$dbnome;charset=utf8";
    $pdo = new PDO($dsn, $dbUser, $dbPass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erro ao conectar ao banco de dados: " . $e->getMessage());
}

// Configuração inicial de variáveis
$search = ""; // Definir $search como vazio por padrão
$keys = []; // Array para armazenar os dados de `users_integration_keys`
$ipWhitelist = []; // Array para armazenar os dados de `ip_whitelist`

// Verificar se há busca
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $search = trim($_GET['search']);
}

// Consultar os dados da tabela `users_integration_keys` com ou sem filtro de busca
$query = "
    SELECT * FROM users_integration_keys
";
if (!empty($search)) {
    $query .= " WHERE client_id LIKE :search OR name LIKE :search";
}

$stmt = $pdo->prepare($query);

if (!empty($search)) {
    $stmt->bindValue(':search', "%$search%", PDO::PARAM_STR);
}
$stmt->execute();

// Armazenar os resultados de `users_integration_keys` na variável `$keys`
$keys = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Consultar os dados da tabela `ip_whitelist`
$queryIpWhitelist = "
    SELECT * FROM ip_whitelist
";
if (!empty($search)) {
    $queryIpWhitelist .= " WHERE user_id LIKE :search";
}

$stmtIpWhitelist = $pdo->prepare($queryIpWhitelist);

if (!empty($search)) {
    $stmtIpWhitelist->bindValue(':search', "%$search%", PDO::PARAM_STR);
}
$stmtIpWhitelist->execute();

// Armazenar os resultados de `ip_whitelist` na variável `$ipWhitelist`
$ipWhitelist = $stmtIpWhitelist->fetchAll(PDO::FETCH_ASSOC);



// Consultar o role do usuário com base no user_id da sessão
$user_id = $_SESSION['user_id'];
$query = "SELECT id, username, email, role FROM users WHERE id = :user_id";
$stmt = $pdo->prepare($query);
$stmt->execute([':user_id' => $user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Verificar se o usuário existe no banco
if (!$user) {
    header('Location: ../login'); // Redireciona para o login se o usuário não for encontrado
    exit;
}

// Verificar se o usuário tem a role 'admin'
if ($user['role'] !== 'ADMIN') {
    header('Location: ../login'); // Redireciona para o login se não for admin
    exit;
}




?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Lista de Webhooks</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #121212;
            color: #ffffff;
            margin: 0;
            padding: 0;
            overflow-x: hidden;
        }

        /* Sidebar */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            width: 240px;
            background: #1e1e1e;
            padding: 20px;
            transition: all 0.3s;
        }

        .sidebar a {
            color: #ffffff;
            display: block;
            padding: 12px;
            margin-bottom: 8px;
            text-decoration: none;
            border-radius: 5px;
            transition: all 0.3s;
        }

        .sidebar a:hover,
        .sidebar a.active {
            background: #00ff88;
            color: #121212;
        }

        /* Content */
        .content {
            margin-left: 240px;
            padding: 20px;
            background: #181818;
            min-height: 100vh;
        }

        /* Tabela */
        .table th,
        .table td {
            border-top: none;
        }

        /* Botões */
        .btn-warning {
            background: #ffcc00;
            color: #121212;
        }

        .btn-danger {
            background: #ff4d4d;
            color: #ffffff;
        }

        .btn-sm {
            font-size: 14px;
        }

        /* Paginação */
        .pagination .page-item.active .page-link {
            background-color: #00ff88;
            border-color: #00ff88;
        }

        .pagination .page-link {
            color: #ffffff;
        }

        .search-bar .input-group {
            max-width: 500px;
            width: 100%;
        }

        .search-bar input {
            border: 2px solid #00ff88;
            border-radius: 5px 0 0 5px;
            color: #121212;
            font-size: 16px;
            padding: 10px;
        }

        .search-bar input:focus {
            border-color: #00cc6a;
            outline: none;
        }

        .search-bar .btn-success {
            background-color: #00ff88;
            border-color: #00ff88;
            border-radius: 0 5px 5px 0;
            color: #121212;
        }

        .search-bar .btn-success:hover {
            background-color: #00cc6a;
            border-color: #00cc6a;
        }
    </style>
</head>

<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <h4 class="text-center text-light mb-4">Admin Panel</h4>
        <a href="user_list.php"><i class="fas fa-users"></i> Usuários</a>
        <a href="transaction_list.php"><i class="fas fa-exchange-alt"></i> Transações</a>
        <a href="documents_list.php"><i class="fas fa-file-alt"></i> Documentos</a>
        <a href="config_edit.php"><i class="fas fa-cogs"></i> Configurações</a>
        <a href="Webhooks.php" class="active"><i class="fas fa-cogs"></i> Webhooks</a>
        <a href="../" class="text-danger"><i class="fas fa-sign-out-alt"></i> Voltar</a>
    </div>

    <!-- Content -->
    <div class="content">
        <h1 class="text-center mb-4">Lista de Webhooks</h1>

        <!-- Formulário de busca -->
        <div class="search-bar mb-4">
            <form method="GET" action="">
                <div class="input-group">
                    <input type="text" name="search" class="form-control" placeholder="Buscar por client_id, nome ou user_id" value="<?php echo htmlspecialchars($search); ?>">
                    <div class="input-group-append">
                        <button class="btn btn-success" type="submit"><i class="fas fa-search"></i> Buscar</button>
                    </div>
                </div>
            </form>
        </div>

        <!-- Tabela de Webhooks -->
        <table class="table table-dark table-hover">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>User ID</th>
                    <th>Client ID</th>
                    <th>Client Secret</th>
                    <th>Nome</th>
                    <th>Descrição</th>
                    <th>Criado em</th>
                    <th>Domínio</th>
                   <!-- <th>Access Token</th>
                    <th>Expires In</th> -->
                    <th>IP</th> <!-- Coluna para o IP -->
                </tr>
            </thead>
            <tbody>
                <?php foreach ($keys as $key): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($key['id']); ?></td>
                        <td><?php echo htmlspecialchars($key['user_id']); ?></td>
                        <td><?php echo htmlspecialchars($key['client_id']); ?></td>
                        <td><?php echo htmlspecialchars($key['client_secret']); ?></td>
                        <td><?php echo htmlspecialchars($key['name']); ?></td>
                        <td><?php echo htmlspecialchars($key['description']); ?></td>
                        <td><?php echo htmlspecialchars($key['created_at']); ?></td>
                        <td><?php echo htmlspecialchars($key['domain']); ?></td>
                       <!-- <td><?php echo htmlspecialchars($key['access_token']); ?></td>
                        <td><?php echo htmlspecialchars($key['expires_in']); ?></td>-->
                        <td>
                            <?php 
                            // Exibir o IP do user_id correspondente
                            $ip = 'IP não encontrado';
                            foreach ($ipWhitelist as $ipData) {
                                if ($ipData['user_id'] == $key['user_id']) {
                                    $ip = htmlspecialchars($ipData['ip']);
                                    break;
                                }
                            }
                            echo $ip;
                            ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <!-- Paginação -->
        <nav>
            <ul class="pagination">
                <!-- Adicione sua lógica de paginação aqui -->
            </ul>
        </nav>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>
