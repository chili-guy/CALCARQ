<?php
session_start();

// Verificar se o usuário está autenticado
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login');
    exit;
}

use Dotenv\Dotenv;

require __DIR__ . '/../vendor/autoload.php';

$dotenv = Dotenv::createImmutable(__DIR__ . '/../');
$dotenv->load();

try {
    $dbHost = $_ENV['DB_HOST'];
    $dbnome = $_ENV['DB_NAME'];
    $dbUser = $_ENV['DB_USER'];
    $dbPass = $_ENV['DB_PASS'];

    $dsn = "mysql:host=$dbHost;dbname=$dbnome;charset=utf8";
    $pdo = new PDO($dsn, $dbUser, $dbPass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erro ao conectar ao banco de dados: " . $e->getMessage());
}

// Verificar se o usuário tem a role 'admin'
$user_id = $_SESSION['user_id'];
$query = "SELECT role FROM users WHERE id = :user_id";
$stmt = $pdo->prepare($query);
$stmt->execute([':user_id' => $user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user || $user['role'] !== 'ADMIN') {
    header('Location: ../login');
    exit;
}

// Consultar as configurações do site
$query = "SELECT * FROM config LIMIT 1"; // Apenas uma linha de configuração
$stmt = $pdo->prepare($query);
$stmt->execute();
$config = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$config) {
    die("Configurações não encontradas.");
}

// Atualizar as configurações se o formulário for enviado
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update'])) {
        // Captura os novos valores do formulário
        $name = $_POST['name'];
        $favicon = $_POST['favicon']; // Favicon como texto
        $logo = $_POST['logo']; // Logo como texto
        $toggleLogo = $_POST['togglelogo']; // 'sim' ou 'não'
        $namePayLogo = isset($_POST['name_pay_logo']) ? 1 : 0;
        $primaryColor = $_POST['primary_color']; // Cor primária em RGB
        $secondaryColor = $_POST['secondary_color']; // Cor secundária em RGB
        $antiFraudeMin = $_POST['anti_fraude_min']; // Valor do anti fraude mínimo

        // Captura e valida as taxas
        $taxMin = (float)$_POST['tax_min']; // Taxa mínima como decimal
        $taxCashIn = (int)$_POST['tax_cashin']; // Taxa de Cash-In como inteiro (porcentagem)
        $taxCashOut = (int)$_POST['tax_cashout']; // Taxa de Cash-Out como inteiro (porcentagem)
        $taxInternal = (int)$_POST['tax_internal']; // Taxa Interna como inteiro (porcentagem)

        // Definir os valores mínimos
        $minTaxMin = 0.80; // Mínimo para tax_min
        $minTaxCashIn = 3; // Mínimo para tax_cashin
        $minTaxCashOut = 1; // Mínimo para tax_cashout
        $minTaxInternal = 0; // Mínimo para tax_internal

        // Validar os valores
        if ($taxMin < $minTaxMin || $taxCashIn < $minTaxCashIn || $taxCashOut < $minTaxCashOut || $taxInternal < $minTaxInternal) {
            $message = "Os valores das taxas não podem ser menores que os valores mínimos.";
        } else {
            // Modificar a consulta para incluir a atualização de todos os campos, incluindo as taxas
            $query = "UPDATE config 
                      SET name = :name, favicon = :favicon, logo = :logo, togglelogo = :togglelogo, name_pay_logo = :name_pay_logo, 
                          primary_color = :primary_color, secondary_color = :secondary_color, anti_fraude_min = :anti_fraude_min,
                          tax_min = :tax_min, tax_cashin = :tax_cashin, tax_cashout = :tax_cashout, tax_internal = :tax_internal
                      WHERE id = 0"; // Supondo que há apenas uma linha de configuração
            $stmt = $pdo->prepare($query);
            $stmt->execute([
                ':name' => $name,
                ':favicon' => $favicon,
                ':logo' => $logo,
                ':togglelogo' => $toggleLogo,
                ':name_pay_logo' => $namePayLogo,
                ':primary_color' => $primaryColor,
                ':secondary_color' => $secondaryColor,
                ':anti_fraude_min' => $antiFraudeMin,
                ':tax_min' => $taxMin,
                ':tax_cashin' => $taxCashIn,
                ':tax_cashout' => $taxCashOut,
                ':tax_internal' => $taxInternal
            ]);

            // Atualizar a variável para refletir as alterações
            $config['name'] = $name;
            $config['favicon'] = $favicon;
            $config['logo'] = $logo;
            $config['togglelogo'] = $toggleLogo;
            $config['name_pay_logo'] = $namePayLogo;
            $config['primary_color'] = $primaryColor;
            $config['secondary_color'] = $secondaryColor;
            $config['anti_fraude_min'] = $antiFraudeMin;
            $config['tax_min'] = $taxMin;
            $config['tax_cashin'] = $taxCashIn;
            $config['tax_cashout'] = $taxCashOut;
            $config['tax_internal'] = $taxInternal;

            // Opcionalmente, adicionar uma mensagem de sucesso
            $message = "Configurações atualizadas com sucesso!";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Configurações</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #121212;
            color: #ffffff;
            margin: 0;
            padding: 0;
            overflow-x: hidden;
        }

        /* Sidebar */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            width: 240px;
            background: #1e1e1e;
            padding: 20px;
            transition: all 0.3s;
        }

        .sidebar a {
            color: #ffffff;
            display: block;
            padding: 12px;
            margin-bottom: 8px;
            text-decoration: none;
            border-radius: 5px;
            transition: all 0.3s;
        }

        .sidebar a:hover,
        .sidebar a.active {
            background: #00ff88;
            color: #121212;
        }

        /* Content */
        .content {
            margin-left: 240px;
            padding: 20px;
            background: #181818;
            min-height: 100vh;
        }

        /* Formulário */
        .form-group label {
            color: #ffffff;
        }

        .form-group input {
            border-radius: 5px;
        }

        .btn-success {
            background-color: #00ff88;
            border-color: #00ff88;
            color: #121212;
        }

        .btn-success:hover {
            background-color: #00cc6a;
            border-color: #00cc6a;
        }

        .btn-secondary {
            background-color: #555555;
            border-color: #555555;
        }

        .btn-secondary:hover {
            background-color: #444444;
            border-color: #444444;
        }
    </style>
</head>

<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <h4 class="text-center text-light mb-4">Admin Panel</h4>
        <a href="user_list.php"><i class="fas fa-users"></i> Usuários</a>
        <a href="transaction_list.php"><i class="fas fa-exchange-alt"></i> Transações</a>
        <a href="documents_list.php"><i class="fas fa-file-alt"></i> Documentos</a>
        <a href="config_edit.php" class="active"><i class="fas fa-cogs"></i> Configurações</a>
         <a href="Webhooks.php" class="active"><i class="fas fa-cogs"></i> Webhooks</a>
        <a href="../" class="text-danger"><i class="fas fa-sign-out-alt"></i> Voltar</a>
    </div>

    <!-- Content -->
    <div class="content">
        <h2 class="text-center mb-4">Editar Configurações</h2>
        <!-- Mensagem de sucesso ou erro -->
        <?php if (isset($message)): ?>
            <div class="alert alert-info"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>

        <!-- Formulário de Edição -->
        <form method="POST">
            <div class="form-group">
                <label for="name">Nome do Site</label>
                <input type="text" name="name" id="name" class="form-control" value="<?php echo htmlspecialchars($config['name']); ?>" required>
            </div>
            <div class="form-group">
                <label for="favicon">Favicon</label>
                <input type="text" name="favicon" id="favicon" class="form-control" value="<?php echo htmlspecialchars($config['favicon']); ?>" required>
            </div>
            <div class="form-group">
                <label for="logo">Logo</label>
                <input type="text" name="logo" id="logo" class="form-control" value="<?php echo htmlspecialchars($config['logo']); ?>" required>
            </div>
            <div class="form-group">
                <label for="togglelogo">Mini-Logo</label>
                <input type="text" name="togglelogo" id="togglelogo" class="form-control" value="<?php echo htmlspecialchars($config['togglelogo']); ?>" required>
            </div>
            <div class="form-group">
                <label for="name_pay_logo">Exibir Nome PAY depois da Logo</label>
                <input type="checkbox" name="name_pay_logo" id="name_pay_logo" <?php echo $config['name_pay_logo'] ? 'checked' : ''; ?>>
            </div>
            <div class="form-group">
                <label for="primary_color">Cor Primária (RGB)</label>
                <input type="text" name="primary_color" id="primary_color" class="form-control" value="<?php echo htmlspecialchars($config['primary_color']); ?>" placeholder="Ex: 0, 203, 161" required>
            </div>
            <div class="form-group">
                <label for="secondary_color">Cor Secundária (RGB)</label>
                <input type="text" name="secondary_color" id="secondary_color" class="form-control" value="<?php echo htmlspecialchars($config['secondary_color']); ?>" placeholder="Ex: 255, 87, 34" required>
            </div>
            <div class="form-group">
                <label for="anti_fraude_min">Valor Mínimo Anti-Fraude (float)</label>
                <input type="text" name="anti_fraude_min" id="anti_fraude_min" class="form-control" value="<?php echo htmlspecialchars($config['anti_fraude_min']); ?>" placeholder="Ex: 100.00" required>
                <small class="form-text text-muted">
                    Quando o depósito atingir ou exceder este valor, o cash-out será desativado.
                </small>
            </div>
            <div class="form-group">
                <label for="tax_min">Taxa Mínima (Decimal)</label>
                <input type="number" step="0.01" name="tax_min" id="tax_min" class="form-control" value="<?php echo htmlspecialchars($config['tax_min']); ?>" required>
                <small class="form-text text-muted">Valor mínimo: 0.80</small>
            </div>
            <div class="form-group">
                <label for="tax_cashin">Taxa de Cash-In (%)</label>
                <input type="number" name="tax_cashin" id="tax_cashin" class="form-control" value="<?php echo htmlspecialchars($config['tax_cashin']); ?>" required>
                <small class="form-text text-muted">Valor mínimo: 3%</small>
            </div>
            <div class="form-group">
                <label for="tax_cashout">Taxa de Cash-Out (%)</label>
                <input type="number" name="tax_cashout" id="tax_cashout" class="form-control" value="<?php echo htmlspecialchars($config['tax_cashout']); ?>" required>
                <small class="form-text text-muted">Valor mínimo: 1%</small>
            </div>
            <div class="form-group">
                <label for="tax_internal">Taxa Interna (%)</label>
                <input type="number" name="tax_internal" id="tax_internal" class="form-control" value="<?php echo htmlspecialchars($config['tax_internal']); ?>" required>
                <small class="form-text text-muted">Valor mínimo: 0%</small>
            </div>
            <button type="submit" name="update" class="btn btn-success">Salvar</button>
        </form>
    </div>

    <!-- Scripts JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>

</html>