<?php
session_start();

// Verificar se o usuário está autenticado
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login'); // Redireciona para a página de login se não estiver autenticado
    exit;
}

use Dotenv\Dotenv;

require __DIR__ . '/../vendor/autoload.php';

$dotenv = Dotenv::createImmutable(__DIR__ . '/../');
$dotenv->load();

try {
    $dbHost = $_ENV['DB_HOST'];
    $dbName = $_ENV['DB_NAME'];
    $dbUser = $_ENV['DB_USER'];
    $dbPass = $_ENV['DB_PASS'];

    $dsn = "mysql:host=$dbHost;dbname=$dbName;charset=utf8";
    $pdo = new PDO($dsn, $dbUser, $dbPass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erro ao conectar ao banco de dados: " . $e->getMessage());
}

// Verificar se o usuário tem a role 'admin'
$user_id = $_SESSION['user_id'];
$query = "SELECT role FROM users WHERE id = :user_id";
$stmt = $pdo->prepare($query);
$stmt->execute([':user_id' => $user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user || $user['role'] !== 'ADMIN') {
    header('Location: ../login'); // Redireciona se não for admin
    exit;
}

// Obter o ID da transação
if (!isset($_GET['id'])) {
    die("ID da transação não fornecido.");
}

$transaction_id = $_GET['id'];

// Excluir a transação
$query = "DELETE FROM transactions WHERE id = :id";
$stmt = $pdo->prepare($query);
$stmt->execute([':id' => $transaction_id]);

header('Location: transaction_list'); // Redireciona para a lista de transações
exit;
