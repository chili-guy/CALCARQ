<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: ../login');
    exit;
}

use Dotenv\Dotenv;

require __DIR__ . '/../vendor/autoload.php';

$dotenv = Dotenv::createImmutable(__DIR__ . '/../');
$dotenv->load();

try {
    $dbHost = $_ENV['DB_HOST'];
    $dbName = $_ENV['DB_NAME'];
    $dbUser = $_ENV['DB_USER'];
    $dbPass = $_ENV['DB_PASS'];

    $dsn = "mysql:host=$dbHost;dbname=$dbName;charset=utf8";
    $pdo = new PDO($dsn, $dbUser, $dbPass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erro ao conectar ao banco de dados: " . $e->getMessage());
}

$user_id = $_SESSION['user_id'];
$query = "SELECT id, username, email, role, pin, cash_in_active, cash_out_active, documents_checked FROM users WHERE id = :user_id";
$stmt = $pdo->prepare($query);
$stmt->execute([':user_id' => $user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    header('Location: ../login');
    exit;
}

if ($user['role'] !== 'ADMIN') {
    header('Location: ../login');
    exit;
}

$limit = 20;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

$search = isset($_GET['search']) ? trim($_GET['search']) : '';

$query = "SELECT id, username, email, role, balance, pin, cash_in_active, cash_out_active, documents_checked 
          FROM users 
          WHERE username LIKE :search 
          LIMIT :limit OFFSET :offset";

$stmt = $pdo->prepare($query);
$stmt->bindValue(':search', '%' . $search . '%', PDO::PARAM_STR);
$stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

$totalQuery = "SELECT COUNT(*) FROM users WHERE username LIKE :search";
$totalStmt = $pdo->prepare($totalQuery);
$totalStmt->bindValue(':search', '%' . $search . '%', PDO::PARAM_STR);
$totalStmt->execute();
$totalUsers = $totalStmt->fetchColumn();
$totalPages = ceil($totalUsers / $limit);

$queryTotalUsers = "SELECT COUNT(*) FROM users";
$stmtTotalUsers = $pdo->prepare($queryTotalUsers);
$stmtTotalUsers->execute();
$totalUsers = $stmtTotalUsers->fetchColumn();

$queryTotalCashIn = "SELECT COUNT(*) FROM users WHERE cash_in_active = 1";
$stmtTotalCashIn = $pdo->prepare($queryTotalCashIn);
$stmtTotalCashIn->execute();
$totalCashIn = $stmtTotalCashIn->fetchColumn();

$queryTotalCashOut = "SELECT COUNT(*) FROM users WHERE cash_out_active = 1";
$stmtTotalCashOut = $pdo->prepare($queryTotalCashOut);
$stmtTotalCashOut->execute();
$totalCashOut = $stmtTotalCashOut->fetchColumn();

$queryTotalDocuments = "SELECT COUNT(*) FROM users_documents WHERE approved = 0";
$stmtTotalDocuments = $pdo->prepare($queryTotalDocuments);
$stmtTotalDocuments->execute();
$totalDocuments = $stmtTotalDocuments->fetchColumn();

$queryTotalBalance = "SELECT SUM(balance) FROM users";
$stmtTotalBalance = $pdo->prepare($queryTotalBalance);
$stmtTotalBalance->execute();
$totalBalance = $stmtTotalBalance->fetchColumn();

$queryTotalTransactions = "SELECT COUNT(*) FROM transactions";
$stmtTotalTransactions = $pdo->prepare($queryTotalTransactions);
$stmtTotalTransactions->execute();
$totalTransactions = $stmtTotalTransactions->fetchColumn();

$queryTotalMovimentado = "SELECT SUM(amount) FROM transactions WHERE status = 'PAID'";
$stmtTotalMovimentado = $pdo->prepare($queryTotalMovimentado);
$stmtTotalMovimentado->execute();
$totalMovimentado = $stmtTotalMovimentado->fetchColumn();

?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard Administrativo</title>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
        font-family: 'Arial', sans-serif;
        background-color: #121212;
        color: #ffffff;
        margin: 0;
        padding: 0;
        overflow-x: hidden;
    }
    
    .sidebar {
        position: fixed;
        top: 0;
        left: 0;
        height: 100%;
        width: 240px;
        background: #1e1e1e;
        padding: 20px;
        transition: all 0.3s;
    }
    
    .sidebar a {
        color: #ffffff;
        display: block;
        padding: 12px;
        margin-bottom: 8px;
        text-decoration: none;
        border-radius: 5px;
        transition: all 0.3s;
    }
    
    .sidebar a:hover, .sidebar a.active {
        background: #00ff88;
        color: #121212;
    }
    
    .content {
        margin-left: 240px;
        padding: 20px;
        background: #181818;
        min-height: 100vh;
    }
    
    .dashboard-header {
        text-align: center;
        margin-bottom: 30px;
        color: #00ff88;
    }
    
    .card {
        background: url('/new/fundo1.png') no-repeat center center;
        background-size: cover;
        color: #ffffff;
        border: none;
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.5);
        transition: all 0.3s;
        position: relative;
        z-index: 1;
    }
    
    .card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0, 0, 0, 0.5);
        border-radius: 10px;
        z-index: 0;
    }
    
    .card h5, .card p {
        position: relative;
        z-index: 2;
    }
    
    .btn {
        border: none;
        border-radius: 5px;
        font-weight: bold;
        padding: 10px 15px;
        transition: all 0.3s ease;
    }
    
    .btn-warning {
        background: #ffcc00;
        color: #121212;
    }
    
    .btn-warning:hover {
        background: #ffd633;
        color: #000;
        box-shadow: 0 4px 8px rgba(255, 204, 0, 0.5);
    }
    
    .btn-danger {
        background: #ff4d4d;
        color: #ffffff;
    }
    
    .btn-danger:hover {
        background: #ff6666;
        box-shadow: 0 4px 8px rgba(255, 77, 77, 0.5);
    }
    
    .btn-sm {
        font-size: 14px;
        padding: 8px 12px;
    }
    
    .table th, .table td {
        border-top: none;
    }
    
    ::-webkit-scrollbar {
        width: 8px;
    }
    
    ::-webkit-scrollbar-thumb {
        background-color: #00ff88;
        border-radius: 10px;
    }
    
    .slide-bar {
        background: #333333;
        padding: 10px;
        border-radius: 10px;
        color: #ffffff;
        text-align: center;
        margin-bottom: 20px;
    }
    
    .slide-bar h5 {
        margin: 0 0 10px;
        color: #00ff88;
    }
    
    .slide-bar input[type="range"] {
        width: 100%;
    }
    .search-bar {
        display: flex;
        justify-content: center;
        margin-bottom: 20px;
    }
    
    .search-bar .input-group {
        max-width: 500px;
        width: 100%;
    }
    
    .search-bar input {
        border: 2px solid #00ff88;
        border-radius: 5px 0 0 5px;
        color: #121212;
        font-size: 16px;
        padding: 10px;
        transition: border-color 0.3s ease;
    }
    
    .search-bar input:focus {
        border-color: #00cc6a;
        outline: none;
    }
    
    .search-bar .btn-success {
        background-color: #00ff88;
        border-color: #00ff88;
        border-radius: 0 5px 5px 0;
        color: #121212;
        font-weight: bold;
        transition: all 0.3s ease;
    }
    
    .search-bar .btn-success:hover {
        background-color: #00cc6a;
        border-color: #00cc6a;
        box-shadow: 0 4px 8px rgba(0, 255, 136, 0.5);
    }
    
  </style>
</head>

<body>
  <!-- Sidebar -->
  <div class="sidebar">
    <h4 class="text-center text-light mb-4">Admin Panel</h4>
    <a href="user_list.php" class="active"><i class="fas fa-users"></i> Usuários</a>
    <a href="transaction_list.php"><i class="fas fa-exchange-alt"></i> Transações</a>
    <a href="documents_list"><i class="fas fa-file-alt"></i> Documentos <?php if ($pending_documents > 0): ?> <span class="badge badge-danger ml-2"><?php echo $pending_documents; ?></span> <?php endif; ?> </a>
    <a href="config_edit.php"><i class="fas fa-cogs"></i> Configurações</a>
    <a href="Webhooks.php"><i class="fas fa-cogs"></i> Webhooks</a>
    <a href="../" class="text-danger"><i class="fas fa-sign-out-alt"></i> Voltar</a>
  </div>
  <!-- Content -->
  <div class="content">
    <div class="row text-center">
      <div class="col-md-4 mb-3">
        <div class="card p-3">
          <h5>Total de Contas</h5>
          <p><?php echo $totalUsers; ?></p>
        </div>
      </div>
      <div class="col-md-4 mb-3">
        <div class="card p-3">
          <h5>Total de Saldo</h5>
          <p>R$ <?php echo number_format($totalBalance, 2, ',', '.'); ?></p>
        </div>
      </div>
      <div class="col-md-4 mb-3">
        <div class="card p-3">
          <h5>Total Movimentado</h5>
          <p>R$ <?php echo number_format($totalMovimentado, 2, ',', '.'); ?></p>
        </div>
      </div>
    </div>
    <!-- Formulário de busca -->
    <div class="search-bar mb-4">
        <form method="get" action="">
            <div class="input-group">
                <input type="text" name="search" class="form-control" placeholder="Buscar por usuário" value="<?php echo htmlspecialchars($search); ?>">
                <div class="input-group-append">
                    <button class="btn btn-success" type="submit"><i class="fas fa-search"></i> Buscar</button>
                </div>
            </div>
        </form>
    </div>

    <!-- Tabela -->
    <table class="table table-dark table-hover">
      <thead>
        <tr>
          <th>Usuário</th>
          <th>Email</th>
          <th>Role</th>
          <th>Saldo</th>
          <th>PIN</th>
          <th>CASH IN</th>
          <th>CASH OUT</th>
           <th>DOCUMENTOS</th>
          <th>Ações</th>
        </tr>
      </thead>
      
      <tbody> <?php if (empty($users)): ?> <tr>
          <td colspan="6" class="text-center">Nenhum usuário encontrado.</td>
        </tr> <?php else: ?> <?php foreach ($users as $user): ?> <tr>
          <td><?php echo htmlspecialchars($user['username']); ?></td>
          <td><?php echo htmlspecialchars($user['email']); ?></td>
     
          
          
         <td>
    <?php 
        echo $user['role'] === 'ADMIN' ? 'Administrador' : 'NÃO ADMIN'; 
    ?>
</td>
 
          
          <td>R$ <?php echo number_format($user['balance'], 2, ',', '.'); ?></td>
           <td><?php echo htmlspecialchars($user['pin']); ?></td>
           
            <td>
    <?php 
        echo $user['cash_in_active'] == 1 ? 'ATIVADO✅' : 'NÃO ATIVO❌'; 
    ?>
</td>
           
           
           <td>
    <?php 
        echo $user['cash_out_active'] == 1 ? 'ATIVADO✅' : 'NÃO ATIVO❌'; 
    ?>
</td>

           
           
          <td>
    <?php 
        echo $user['documents_checked'] == 1 ? 'ATIVADO✅' : 'NÃO ATIVO❌'; 
    ?>
</td>

          <td>
            <a href="edit_user.php?id=<?php echo $user['id']; ?>" class="btn btn-warning btn-sm">Editar</a>
            <a href="delete_user.php?id=<?php echo $user['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Tem certeza que deseja excluir este usuário?');">Excluir</a>
          </td>
        </tr> <?php endforeach; ?> <?php endif; ?> </tbody>
    </table>
  </div>
</body>

</html>