<?php
// Carregar as dependências antes de iniciar a sessão
use Dotenv\Dotenv;
require __DIR__ . '/../vendor/autoload.php';

// Iniciar a sessão
session_start();

// Verificar se o usuário está autenticado
if (isset($_SESSION['user_id'])) {
    // Verificar se o usuário tem a role 'admin'
    $user_id = $_SESSION['user_id'];
    
    // Carregar as variáveis de ambiente
    $dotenv = Dotenv::createImmutable(__DIR__ . '/../');
    $dotenv->load();

    try {
        $dbHost = $_ENV['DB_HOST'];
        $dbName = $_ENV['DB_NAME'];
        $dbUser = $_ENV['DB_USER'];
        $dbPass = $_ENV['DB_PASS'];

        $dsn = "mysql:host=$dbHost;dbname=$dbName;charset=utf8";
        $pdo = new PDO($dsn, $dbUser, $dbPass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (PDOException $e) {
        die("Erro ao conectar ao banco de dados: " . $e->getMessage());
    }

    // Consultar o role do usuário
    $query = "SELECT role FROM users WHERE id = :user_id";
    $stmt = $pdo->prepare($query);
    $stmt->execute([':user_id' => $user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // Se o usuário for admin, redireciona para o painel de usuários
    if ($user && $user['role'] === 'ADMIN') {
        header('Location: user_list'); // Redireciona para a lista de usuários
        exit;
    } else {
        // Se o usuário não for admin, redireciona para a página de login
        header('Location: ../login');
        exit;
    }
} else {
    // Se não estiver autenticado, redireciona para a página de login
    header('Location: ../login');
    exit;
}
