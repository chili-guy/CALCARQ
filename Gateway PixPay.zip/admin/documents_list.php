<?php
session_start();

// Verificar se o usuário está autenticado
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login');
    exit;
}

use Dotenv\Dotenv;

require __DIR__ . '/../vendor/autoload.php';

$dotenv = Dotenv::createImmutable(__DIR__ . '/../');
$dotenv->load();

try {
    $dbHost = $_ENV['DB_HOST'];
    $dbnome = $_ENV['DB_NAME'];
    $dbUser = $_ENV['DB_USER'];
    $dbPass = $_ENV['DB_PASS'];

    $dsn = "mysql:host=$dbHost;dbname=$dbnome;charset=utf8";
    $pdo = new PDO($dsn, $dbUser, $dbPass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erro ao conectar ao banco de dados: " . $e->getMessage());
}

// Processar as requisições POST (aprovar ou recusar documentos)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');

    $document_id = isset($_POST['document_id']) ? (int)$_POST['document_id'] : 0;
    $action = isset($_POST['action']) ? trim($_POST['action']) : '';

    if ($document_id > 0 && in_array($action, ['approve', 'reject'])) {
        try {
            if ($action === 'approve') {
                // Aprovar o documento
                $status = 1; // 1 = aprovado
                $stmt = $pdo->prepare("UPDATE users_documents SET approved = :status WHERE id = :document_id");
                $stmt->bindValue(':status', $status, PDO::PARAM_INT);
                $stmt->bindValue(':document_id', $document_id, PDO::PARAM_INT);
                $stmt->execute();
            
                // Buscar o user_id para realizar a verificação
                $stmt_document = $pdo->prepare("SELECT user_id FROM users_documents WHERE id = :document_id");
                $stmt_document->bindValue(':document_id', $document_id, PDO::PARAM_INT);
                $stmt_document->execute();
                $document = $stmt_document->fetch(PDO::FETCH_ASSOC);
            
                if ($document) {
                    // Verificar se todos os documentos 1-4 do usuário estão aprovados
                    $stmt_check = $pdo->prepare("
                        SELECT COUNT(*) 
                        FROM users_documents 
                        WHERE user_id = :user_id AND document_id IN (1, 2, 3, 4) AND approved = 1
                    ");
                    $stmt_check->bindValue(':user_id', $document['user_id'], PDO::PARAM_INT);
                    $stmt_check->execute();
                    $approved_documents = $stmt_check->fetchColumn();

                    // Se todos os documentos 1-4 estiverem aprovados
                    if ($approved_documents == 4) {
                        // Atualizar a coluna documents_checked para 1
                        $stmt_user = $pdo->prepare("UPDATE users SET documents_checked = 1 WHERE id = :user_id");
                        $stmt_user->bindValue(':user_id', $document['user_id'], PDO::PARAM_INT);
                        $stmt_user->execute();

                        echo '<script>alert("Documento aprovado e todos os documentos verificados para o usuário!"); window.location.reload();</script>';
                    } else {
                        echo '<script>alert("Documento aprovado, mas o usuário ainda tem documentos pendentes."); window.location.reload();</script>';
                    }
                }
            
            } elseif ($action === 'reject') {
                // Recusar o documento (deletar)
                $stmt = $pdo->prepare("DELETE FROM users_documents WHERE id = :document_id");
                $stmt->bindValue(':document_id', $document_id, PDO::PARAM_INT);
                $stmt->execute();

                echo '<script>alert("Documento recusado e deletado com sucesso!"); window.location.reload();</script>';
            }
        } catch (PDOException $e) {
            echo '<script>alert("Erro ao processar a ação: ' . $e->getMessage() . '"); window.location.reload();</script>';
        }
    } else {
        echo '<script>alert("Dados inválidos fornecidos."); window.location.reload();</script>';
    }

    exit;
}

// Configuração inicial de variáveis
$search = ""; // Definir $search como vazio por padrão
$documents = []; // Definir $documents como array vazio por padrão

// Verificar se há busca
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $search = trim($_GET['search']);
}

// Consultar documentos com ou sem filtro por usuário
$query = "
    SELECT DISTINCT d.id AS document_unique_id, u.id AS user_id, u.name, u.username, d.document_id, d.file_path, d.approved 
    FROM users_documents d
    JOIN users u ON u.id = d.user_id
    WHERE d.approved = 0
";
if (!empty($search)) {
    $query .= " AND u.username LIKE :search";
}

$stmt = $pdo->prepare($query);

if (!empty($search)) {
    $stmt->bindValue(':search', "%$search%", PDO::PARAM_STR);
}
$stmt->execute();

$documents = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Função para determinar o tipo de documento com base no document_id
function getDocumentType($document_id) {
    switch ($document_id) {
        case 1: return "Frente";
        case 2: return "Verso";
        case 3: return "Segurando Documento";
        case 4: return "Contrato Social";
        default: return "Tipo Desconhecido";
    }
}

// Função para ajustar o caminho do arquivo (cortar tudo antes de /libs ou \libs)
function adjustFilePath($filePath) {
    // Substitui tudo antes da pasta 'libs' e mantém o caminho relativo a partir de 'libs'
    $adjustedPath = preg_replace('/^.*?[\\\\\/]libs/', '', $filePath);
    return '/libs' . $adjustedPath;
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Lista de Documentos</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #121212;
            color: #ffffff;
            margin: 0;
            padding: 0;
            overflow-x: hidden;
        }

        /* Sidebar */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            width: 240px;
            background: #1e1e1e;
            padding: 20px;
            transition: all 0.3s;
        }

        .sidebar a {
            color: #ffffff;
            display: block;
            padding: 12px;
            margin-bottom: 8px;
            text-decoration: none;
            border-radius: 5px;
            transition: all 0.3s;
        }

        .sidebar a:hover,
        .sidebar a.active {
            background: #00ff88;
            color: #121212;
        }

        /* Content */
        .content {
            margin-left: 240px;
            padding: 20px;
            background: #181818;
            min-height: 100vh;
        }

        /* Tabela */
        .table th,
        .table td {
            border-top: none;
        }

        /* Botões */
        .btn-warning {
            background: #ffcc00;
            color: #121212;
        }

        .btn-danger {
            background: #ff4d4d;
            color: #ffffff;
        }

        .btn-sm {
            font-size: 14px;
        }

        /* Paginação */
        .pagination .page-item.active .page-link {
            background-color: #00ff88;
            border-color: #00ff88;
        }

        .pagination .page-link {
            color: #ffffff;
        }

        .search-bar .input-group {
            max-width: 500px;
            width: 100%;
        }

        .search-bar input {
            border: 2px solid #00ff88;
            border-radius: 5px 0 0 5px;
            color: #121212;
            font-size: 16px;
            padding: 10px;
        }

        .search-bar input:focus {
            border-color: #00cc6a;
            outline: none;
        }

        .search-bar .btn-success {
            background-color: #00ff88;
            border-color: #00ff88;
            border-radius: 0 5px 5px 0;
            color: #121212;
        }

        .search-bar .btn-success:hover {
            background-color: #00cc6a;
            border-color: #00cc6a;
        }
    </style>
</head>

<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <h4 class="text-center text-light mb-4">Admin Panel</h4>
        <a href="user_list.php"><i class="fas fa-users"></i> Usuários</a>
        <a href="transaction_list.php"><i class="fas fa-exchange-alt"></i> Transações</a>
        <a href="documents_list.php" class="active"><i class="fas fa-file-alt"></i> Documentos</a>
        <a href="config_edit.php"><i class="fas fa-cogs"></i> Configurações</a>
         <a href="Webhooks.php" class="active"><i class="fas fa-cogs"></i> Webhooks</a>
        <a href="../" class="text-danger"><i class="fas fa-sign-out-alt"></i> Voltar</a>
    </div>

    <!-- Content -->
    <div class="content">
        <h1 class="text-center mb-4">Lista de Documentos</h1>

        <!-- Formulário de busca -->
        <div class="search-bar mb-4">
            <form method="GET" action="">
                <div class="input-group">
                    <input type="text" name="search" class="form-control" placeholder="Buscar por username" value="<?php echo htmlspecialchars($search); ?>">
                    <div class="input-group-append">
                        <button class="btn btn-success" type="submit"><i class="fas fa-search"></i> Buscar</button>
                    </div>
                </div>
            </form>
        </div>

        <!-- Tabela de documentos -->
        <table class="table table-dark table-hover">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome Completo</th>
                    <th>Username</th>
                    <th>Tipo de Documento</th>
                    <th>Documento</th>
                    <th>Status</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($documents as $document): ?>
                    <tr id="doc-<?php echo htmlspecialchars($document['document_unique_id']); ?>">
                        <td><?php echo htmlspecialchars($document['document_unique_id']); ?></td>
                        <td><?php echo htmlspecialchars($document['name']); ?></td>
                        <td><?php echo htmlspecialchars($document['username']); ?></td>
                        <td><?php echo getDocumentType($document['document_id']); ?></td>
                        <td><a href="<?php echo adjustFilePath($document['file_path']); ?>" target="_blank">Visualizar</a></td>
                        <td><?php echo $document['approved'] ? 'Aprovado' : 'Pendente'; ?></td>
                        <td>
                            <?php if ($document['approved'] == 0): ?>
                                <form method="POST" action="">
                                    <input type="hidden" name="document_id" value="<?php echo $document['document_unique_id']; ?>">
                                    <input type="hidden" name="action" value="approve">
                                    <button type="submit" class="btn btn-warning btn-sm">Aprovar</button>
                                </form>
                                <form method="POST" action="">
                                    <input type="hidden" name="document_id" value="<?php echo $document['document_unique_id']; ?>">
                                    <input type="hidden" name="action" value="reject">
                                    <button type="submit" class="btn btn-danger btn-sm">Recusar</button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <!-- Paginação -->
        <nav>
            <ul class="pagination">
                <!-- Adicione sua lógica de paginação aqui -->
            </ul>
        </nav>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>
