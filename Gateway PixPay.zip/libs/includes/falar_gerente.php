<html><head></head><body><div class="modal-header">
    <h6 class="modal-title" id="staticBackdropLabel4">Gerente de Relacionamento - <?php include '../get_site_name.php'; ?></h6>
    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
 <center><img class="whatsapp" src="https://st2.depositphotos.com/37227484/42763/i/450/depositphotos_427634378-stock-photo-blonde-business-woman-sitting-and.jpg" alt="WhatsApp" style="width: 100px; margin-right: 10px;"> </center>
<div class="modal-body">
    <div class="row perfil_suporte">
        <img style="display: none;" class="perfil" src="https://st2.depositphotos.com/37227484/42763/i/450/depositphotos_427634378-stock-photo-blonde-business-woman-sitting-and.jpg" alt="">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
        <h4 class="text-center">Felipe C.</h4>
            <h6 class="text-center">felipe@billi.pay</h6>
            <a href="https://wa.me/5514936183607" target="_blank" class="form-control btn btn-success enviar_mensagem">
                <img class="whatsapp" src="https://static.vecteezy.com/system/resources/previews/018/930/564/non_2x/whatsapp-logo-whatsapp-icon-whatsapp-transparent-free-png.png" alt="">   
                +55 (14) 93618-3607            </a>
        </div>
    </div>
</div></body></html>