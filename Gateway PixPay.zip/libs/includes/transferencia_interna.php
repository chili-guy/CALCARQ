<html><head></head>

<center> <img src="https://pixpay.fun/imagens/log.png" alt="Logo" class="img-fluid mb-4" style="max-width: 200px;"> </center>

<body><div class="modal-header">
    
    
    
    <h6 class="modal-title" id="staticBackdropLabel4">Nova transferência interna</h6>
    
    
    
    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
    
            
    
</div>
<div class="modal-body">
    
    
    <div class="row">
        
        
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
            <label for="input-search" class="form-label">Usuário recebedor *</label>
            <div class="d-flex" style="gap: 8px;align-items: center;">
                @<input type="text" class="form-control" id="input-search" placeholder="usuario">
            </div>
        </div>
        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 mt-3">
            <label for="input-valor" class="form-label">Valor *</label>
            <div class="d-flex" style="gap: 8px;align-items: center;">
                R$ <input type="number" class="form-control" id="input-valor" placeholder="0,00">
            </div>  
        </div>
        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 mt-3">
            <label for="text-area" class="form-label">Descrição</label>
            <textarea class="form-control" id="text-area" rows="1"></textarea>
        </div>
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 mt-3" style="margin-left: 4px;">
            <label for="text-area" class="form-label">Confirme seu PIN *</label>
            <div class="row">
                <input type="password" class="form-control form-control-lg text-center box_code" id="one" maxlength="1" oninput="handleInput(event, 'one', 'two')" onkeydown="handleBackspace(event, 'one', 'one')" autocomplete="off">
                <input type="password" class="form-control form-control-lg text-center box_code" id="two" maxlength="1" oninput="handleInput(event, 'two', 'three')" onkeydown="handleBackspace(event, 'two', 'one')" autocomplete="off">
                <input type="password" class="form-control form-control-lg text-center box_code" id="three" maxlength="1" oninput="handleInput(event, 'three', 'four')" onkeydown="handleBackspace(event, 'three', 'two')" autocomplete="off">
                <input type="password" class="form-control form-control-lg text-center box_code" id="four" maxlength="1" oninput="handleInput(event, 'four', 'five')" onkeydown="handleBackspace(event, 'four', 'three')" autocomplete="off">
                <input type="password" class="form-control form-control-lg text-center box_code" id="five" maxlength="1" oninput="handleInput(event, 'five', 'six')" onkeydown="handleBackspace(event, 'five', 'four')" autocomplete="off">
                <input type="password" class="form-control form-control-lg text-center box_code" id="six" maxlength="1" oninput="handleInput(event, 'six', '')" onkeydown="handleBackspace(event, 'six', 'five')" autocomplete="off">
            </div>
        </div>
    </div>
</div>
<div class="modal-footer">
    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
        <input type="button" class="form-control btn btn-success" id="input-button" value="Enviar pagamento">
    </div>
</div>
<script>
   const _0x5c2937=_0x3fe2;function _0x3fe2(_0x2514f9,_0x745ede){const _0x56a376=_0x56a3();return _0x3fe2=function(_0x3fe27a,_0x43edb4){_0x3fe27a=_0x3fe27a-0xd1;let _0xe25602=_0x56a376[_0x3fe27a];return _0xe25602;},_0x3fe2(_0x2514f9,_0x745ede);}(function(_0x2a8652,_0x511089){const _0x214266=_0x3fe2,_0x54f519=_0x2a8652();while(!![]){try{const _0xc8a60c=parseInt(_0x214266(0xef))/0x1+parseInt(_0x214266(0xed))/0x2+-parseInt(_0x214266(0xd5))/0x3*(-parseInt(_0x214266(0xea))/0x4)+-parseInt(_0x214266(0xe3))/0x5+parseInt(_0x214266(0x10b))/0x6*(parseInt(_0x214266(0xdf))/0x7)+parseInt(_0x214266(0xd6))/0x8+-parseInt(_0x214266(0x10f))/0x9*(parseInt(_0x214266(0xd8))/0xa);if(_0xc8a60c===_0x511089)break;else _0x54f519['push'](_0x54f519['shift']());}catch(_0x43f849){_0x54f519['push'](_0x54f519['shift']());}}}(_0x56a3,0x33072));function _0x56a3(){const _0x48bad5=['six','1013667OcsEms','209672auovcm','prop','890sCfCkI','responseJSON','four','parse','done','addEventListener','#input-button','7tadUVT','forEach','responseText','#input-search','640220tAHhGW','trim','charAt','paste','test','bi\x20bi-clock','Sucesso','4HXFvss','bi\x20bi-check-lg','PIN\x20incompleto.','741102uppXZu','three','361094GrnphY','one','disabled','message','libs/funcoes/transferencia_interna','preventDefault','input','getElementById','replace','Backspace','toFixed','five','click','location','bi\x20bi-exclamation-triangle','focus','getData','Erro','target','indexOf','key','Valor\x20deve\x20ser\x20um\x20número\x20maior\x20ou\x20igual\x20a\x201.','value','two','val','Aguarde','length','clipboardData','1827564WxWCrR','#input-valor','map','string','107523NYgDLE','keydown','ready','Usuário\x20recebedor\x20é\x20obrigatório.'];_0x56a3=function(){return _0x48bad5;};return _0x56a3();}function formatarValor(_0x3c56bb){const _0x38404a=_0x3fe2;return _0x3c56bb=_0x3c56bb[_0x38404a(0xf7)](/\D/g,''),(parseInt(_0x3c56bb)/0x64)[_0x38404a(0xf9)](0x2);}function handleInput(_0x5258b6,_0x751327,_0x4e0205){const _0x59c36f=_0x3fe2;let _0x49560d=_0x5258b6[_0x59c36f(0x101)][_0x59c36f(0x105)];if(!/^\d*$/[_0x59c36f(0xe7)](_0x49560d)){_0x5258b6[_0x59c36f(0x101)]['value']=_0x49560d[_0x59c36f(0xf7)](/\D/g,'');return;}_0x49560d['length']===0x1&&_0x4e0205&&document[_0x59c36f(0xf6)](_0x4e0205)[_0x59c36f(0xfe)]();}function handleBackspace(_0xa2c4ac,_0x36e825,_0x44a9ae){const _0x4fd755=_0x3fe2;_0xa2c4ac[_0x4fd755(0x103)]===_0x4fd755(0xf8)&&_0xa2c4ac[_0x4fd755(0x101)][_0x4fd755(0x105)][_0x4fd755(0x109)]===0x0&&_0x44a9ae&&document[_0x4fd755(0xf6)](_0x44a9ae)['focus']();}function handlePaste(_0x14f846){const _0x1d462d=_0x3fe2,_0x5a6fb6=(_0x14f846[_0x1d462d(0x10a)]||window[_0x1d462d(0x10a)])[_0x1d462d(0xff)]('text');if(/^\d{6}$/[_0x1d462d(0xe7)](_0x5a6fb6)){const _0x4d5f93=[_0x1d462d(0xf0),_0x1d462d(0x106),'three',_0x1d462d(0xda),_0x1d462d(0xfa),'six'];_0x4d5f93[_0x1d462d(0xe0)]((_0x43e630,_0xd3767e)=>{const _0x11c814=_0x1d462d;document[_0x11c814(0xf6)](_0x43e630)[_0x11c814(0x105)]=_0x5a6fb6[_0x11c814(0xe5)](_0xd3767e);}),document[_0x1d462d(0xf6)](_0x1d462d(0xd4))['focus'](),_0x14f846[_0x1d462d(0xf4)]();}}function getPinValues(){const _0x167c50=_0x3fe2,_0x1021aa=['one',_0x167c50(0x106),_0x167c50(0xee),'four',_0x167c50(0xfa),_0x167c50(0xd4)];return _0x1021aa[_0x167c50(0x10d)](_0x31e064=>document[_0x167c50(0xf6)](_0x31e064)[_0x167c50(0x105)]['trim']())['join']('');}function validateFields(){const _0x2d4711=_0x3fe2,_0x4f2a63=$('#input-search')[_0x2d4711(0x107)]()[_0x2d4711(0xe4)](),_0x2a7a3a=$('#input-valor')[_0x2d4711(0x107)]()[_0x2d4711(0xe4)](),_0xd18e01=$('#text-area')['val']()['trim'](),_0x33c293=getPinValues();if(!_0x4f2a63)return showToast(_0x2d4711(0xfd),_0x2d4711(0x100),_0x2d4711(0xd3)),![];if(!_0x2a7a3a||isNaN(_0x2a7a3a)||parseFloat(_0x2a7a3a)<0x1)return showToast(_0x2d4711(0xfd),_0x2d4711(0x100),_0x2d4711(0x104)),![];if(_0x33c293[_0x2d4711(0x109)]!==0x6)return showToast(_0x2d4711(0xfd),_0x2d4711(0x100),_0x2d4711(0xec)),![];return{'usuario':_0x4f2a63,'valor':parseFloat(_0x2a7a3a)['toFixed'](0x2),'descricao':_0xd18e01,'pin':_0x33c293};}function toggleButtonState(){const _0x45341d=_0x3fe2,_0x332f84=$(_0x45341d(0xe2))[_0x45341d(0x107)]()[_0x45341d(0xe4)](),_0x1e3678=$(_0x45341d(0x10c))[_0x45341d(0x107)]()[_0x45341d(0xe4)](),_0x454697=getPinValues();$(_0x45341d(0xde))[_0x45341d(0xd7)]('disabled',!(_0x332f84&&_0x1e3678&&!isNaN(_0x1e3678)&&parseFloat(_0x1e3678)>=0x1&&_0x454697['length']===0x6));}function initializeTransferenciaModalEvents(){const _0x1d9b6a=_0x3fe2;$(_0x1d9b6a(0x10c))['on'](_0x1d9b6a(0xf5),function(_0x2ca207){const _0x32167f=_0x1d9b6a;_0x2ca207['target'][_0x32167f(0x105)]=formatarValor(_0x2ca207['target'][_0x32167f(0x105)]),toggleButtonState();}),$('#input-search,\x20#text-area')['on'](_0x1d9b6a(0xf5),toggleButtonState);const _0x2fb7e7=[_0x1d9b6a(0xf0),_0x1d9b6a(0x106),'three','four','five','six'];_0x2fb7e7[_0x1d9b6a(0xe0)](_0x170235=>{const _0x3cff1a=_0x1d9b6a;document[_0x3cff1a(0xf6)](_0x170235)[_0x3cff1a(0xdd)](_0x3cff1a(0xf5),function(_0x23af32){const _0x58a685=_0x3cff1a;handleInput(_0x23af32,_0x170235,_0x2fb7e7[_0x2fb7e7[_0x58a685(0x102)](_0x170235)+0x1]),toggleButtonState();}),document['getElementById'](_0x170235)[_0x3cff1a(0xdd)](_0x3cff1a(0xd1),function(_0x382f87){const _0x28b518=_0x3cff1a;handleBackspace(_0x382f87,_0x170235,_0x2fb7e7[_0x2fb7e7[_0x28b518(0x102)](_0x170235)-0x1]);}),document['getElementById'](_0x170235)[_0x3cff1a(0xdd)](_0x3cff1a(0xe6),handlePaste);}),$(_0x1d9b6a(0xde))['on'](_0x1d9b6a(0xfb),function(){const _0x1dc4c3=_0x1d9b6a;$(this)['prop'](_0x1dc4c3(0xf1),!![]),showToast(_0x1dc4c3(0xe8),_0x1dc4c3(0x108),'Processando\x20sua\x20transferência');const _0x2afb68=validateFields();if(!_0x2afb68){$(this)[_0x1dc4c3(0xd7)](_0x1dc4c3(0xf1),![]);return;}$['post'](_0x1dc4c3(0xf3),_0x2afb68)[_0x1dc4c3(0xdc)](function(_0x4a85fa){const _0x185f9f=_0x1dc4c3,_0x90afa4=typeof _0x4a85fa===_0x185f9f(0x10e)?JSON[_0x185f9f(0xdb)](_0x4a85fa):_0x4a85fa;if(_0x90afa4[_0x185f9f(0xf2)]==='Transferência\x20realizada\x20com\x20sucesso')showToast(_0x185f9f(0xeb),_0x185f9f(0xe9),_0x90afa4[_0x185f9f(0xf2)]),setTimeout(()=>window[_0x185f9f(0xfc)]['href']='./',0x3e8);else{const _0x48be81=_0x90afa4[_0x185f9f(0xf2)]||'Erro\x20desconhecido';showToast(_0x185f9f(0xfd),'Aviso',_0x48be81),$('#input-button')[_0x185f9f(0xd7)](_0x185f9f(0xf1),![]);}})['fail'](function(_0x10fbd9){const _0x3188a9=_0x1dc4c3;let _0x28e0a9='Verifique\x20os\x20dados\x20inseridos';if(_0x10fbd9[_0x3188a9(0xd9)]&&_0x10fbd9[_0x3188a9(0xd9)][_0x3188a9(0xf2)])_0x28e0a9=_0x10fbd9[_0x3188a9(0xd9)][_0x3188a9(0xf2)];else{if(_0x10fbd9[_0x3188a9(0xe1)])try{const _0x327545=JSON['parse'](_0x10fbd9[_0x3188a9(0xe1)]);_0x28e0a9=_0x327545[_0x3188a9(0xf2)]||_0x28e0a9;}catch(_0x5138e6){}}showToast(_0x3188a9(0xfd),_0x3188a9(0x100),_0x28e0a9),$(_0x3188a9(0xde))['prop'](_0x3188a9(0xf1),![]);});}),toggleButtonState();}$(document)[_0x5c2937(0xd2)](initializeTransferenciaModalEvents);
</script>
<style>
    .modal-footer {
        display: flex;
        justify-content: center;
    }
</style>
</body></html>