<html><head></head><body><div class="modal-header">
    <h6 class="modal-title" id="staticBackdropLabel4">Redes Social - <?php include '../get_site_name.php'; ?></h6>
    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>

   





<div class="modal-body">
    <div class="row perfil_suporte">
        <img style="display: none;" class="perfil" src="https://st2.depositphotos.com/37227484/42763/i/450/depositphotos_427634378-stock-photo-blonde-business-woman-sitting-and.jpg" alt="">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
      
      
     
            <h6 class="text-center">Siga a rede Social da Billi-Pay e acompanha todos as novidades</h6> <br>



      
      
      
            <a href="https://www.instagram.com/#/" target="_blank" class="form-control btn btn-success enviar_mensagem">
                <img class="whatsapp" src="https://upload.wikimedia.org/wikipedia/commons/a/a5/Instagram_icon.png" alt="">   
                Instagram            </a>
        </div>
        
        
        
        
      <!--  
        <a href="https://wa.me/5514936183607" target="_blank" class="form-control btn btn-success enviar_mensagem">
                <img class="whatsapp" src="assets/images/media/svg/whatsapp.svg" alt="">   
                Telegram            </a>
        </div>
        
        -->
        
        
        
        
        
        
        
    </div>
</div></body></html>