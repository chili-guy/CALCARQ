<html><head></head><body><div class="modal-header">
    <h6 class="modal-title" id="staticBackdropLabel4">Adicionar IP</h6>
    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>

<div class="modal-body">
    <div class="row gerar_qrcode">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
            <label for="input-ip" class="form-label">IP do servidor</label>
            <input type="text" class="form-control" id="input-ip" placeholder="10.1.1.1">
        </div>
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 mt-3">
            <label for="input-valor" class="form-label">Para continuar, informe seu PIN de 6 dígitos</label>
            <div class="row" style="margin-left:0px;">
                <input type="password" class="form-control form-control-lg text-center box_code" id="one" maxlength="1" oninput="handleInput(event, 'one', 'two')" onkeydown="handleBackspace(event, 'one', 'one')">
                <input type="password" class="form-control form-control-lg text-center box_code" id="two" maxlength="1" oninput="handleInput(event, 'two', 'three')" onkeydown="handleBackspace(event, 'two', 'one')">
                <input type="password" class="form-control form-control-lg text-center box_code" id="three" maxlength="1" oninput="handleInput(event, 'three', 'four')" onkeydown="handleBackspace(event, 'three', 'two')">
                <input type="password" class="form-control form-control-lg text-center box_code" id="four" maxlength="1" oninput="handleInput(event, 'four', 'five')" onkeydown="handleBackspace(event, 'four', 'three')">
                <input type="password" class="form-control form-control-lg text-center box_code" id="five" maxlength="1" oninput="handleInput(event, 'five', 'six')" onkeydown="handleBackspace(event, 'five', 'four')">
                <input type="password" class="form-control form-control-lg text-center box_code" id="six" maxlength="1" oninput="handleInput(event, 'six', '')" onkeydown="handleBackspace(event, 'six', 'five')">
            </div>
        </div>
    </div>
</div>
<div class="modal-footer">
    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
        <input type="button" class="form-control btn btn-success" id="input-button" value="Adicionar">
    </div>
</div>
<script>
   var _0x5b65df=_0x3ed1;function _0x3f34(){var _0x21741f=['catch','five','&pin=','533898XcnWLC','bi\x20bi-exclamation-circle','5552945PRvDgj','getElementById','9320178WFSrWR','ip=','reload','2551706yLVxeU','addEventListener','replace','four','forEach','trim','libs/funcoes/adicionar_ip','PIN\x20inválido','POST','.box_code','focus','74853GxZDCZ','querySelectorAll','Sucesso','Falha\x20de\x20comunicação','one','IP\x20adicionado.','nextElementSibling','IP\x20inválido','94088ifRoSP','then','399LMFXjI','six','input-ip','length','144ZXQJPx','json','target','value','Erro','16848945hVnSAQ'];_0x3f34=function(){return _0x21741f;};return _0x3f34();}function _0x3ed1(_0x2457a9,_0x568da9){var _0x3f3425=_0x3f34();return _0x3ed1=function(_0x3ed16e,_0x339a6d){_0x3ed16e=_0x3ed16e-0xf7;var _0x1b1321=_0x3f3425[_0x3ed16e];return _0x1b1321;},_0x3ed1(_0x2457a9,_0x568da9);}(function(_0x29a2f5,_0x14f124){var _0x4ac817=_0x3ed1,_0x487561=_0x29a2f5();while(!![]){try{var _0x710a55=-parseInt(_0x4ac817(0x115))/0x1+parseInt(_0x4ac817(0x11c))/0x2+-parseInt(_0x4ac817(0xfe))/0x3*(-parseInt(_0x4ac817(0x10c))/0x4)+-parseInt(_0x4ac817(0x117))/0x5+parseInt(_0x4ac817(0x119))/0x6+parseInt(_0x4ac817(0x108))/0x7*(parseInt(_0x4ac817(0x106))/0x8)+-parseInt(_0x4ac817(0x111))/0x9;if(_0x710a55===_0x14f124)break;else _0x487561['push'](_0x487561['shift']());}catch(_0x11095d){_0x487561['push'](_0x487561['shift']());}}}(_0x3f34,0xd7255));function handleInput(_0x841e2a,_0x27315b,_0x4d7ba4){var _0x3f94cf=_0x3ed1;_0x841e2a[_0x3f94cf(0x10e)][_0x3f94cf(0x10f)][_0x3f94cf(0x10b)]===0x1&&_0x4d7ba4&&document['getElementById'](_0x4d7ba4)[_0x3f94cf(0xfd)]();}function handleBackspace(_0x5dc0a0,_0x321a7c,_0x2440bc){var _0x4eee7d=_0x3ed1;_0x5dc0a0['key']==='Backspace'&&_0x5dc0a0[_0x4eee7d(0x10e)][_0x4eee7d(0x10f)][_0x4eee7d(0x10b)]===0x0&&_0x2440bc&&document[_0x4eee7d(0x118)](_0x2440bc)['focus']();}document[_0x5b65df(0xff)](_0x5b65df(0xfc))[_0x5b65df(0xf7)](_0x35879c=>{var _0x19bd75=_0x5b65df;_0x35879c[_0x19bd75(0x11d)]('input',function(){var _0x457dc3=_0x19bd75;this[_0x457dc3(0x10f)]=this[_0x457dc3(0x10f)][_0x457dc3(0x11e)](/[^0-9]/g,''),handleInput(event,this['id'],this[_0x457dc3(0x104)]?this[_0x457dc3(0x104)]['id']:'');});}),document['getElementById']('input-button')[_0x5b65df(0x11d)]('click',function(){var _0x521c19=_0x5b65df,_0x396278=document[_0x521c19(0x118)](_0x521c19(0x10a))[_0x521c19(0x10f)][_0x521c19(0xf8)](),_0x5c796a='';[_0x521c19(0x102),'two','three',_0x521c19(0x11f),_0x521c19(0x113),_0x521c19(0x109)]['forEach'](function(_0x907a07){_0x5c796a+=document['getElementById'](_0x907a07)['value'];});if(!_0x396278['match'](/^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/)){showToast(_0x521c19(0x116),_0x521c19(0x110),_0x521c19(0x105));return;}if(_0x5c796a[_0x521c19(0x10b)]!==0x6){showToast(_0x521c19(0x116),_0x521c19(0x110),_0x521c19(0xfa));return;}fetch(_0x521c19(0xf9),{'method':_0x521c19(0xfb),'headers':{'Content-Type':'application/x-www-form-urlencoded'},'body':_0x521c19(0x11a)+encodeURIComponent(_0x396278)+_0x521c19(0x114)+encodeURIComponent(_0x5c796a)})[_0x521c19(0x107)](_0x4a0397=>_0x4a0397[_0x521c19(0x10d)]())['then'](_0x2b995f=>{var _0x3dd6ab=_0x521c19;_0x2b995f['success']?(showToast('bi\x20bi-check-circle',_0x3dd6ab(0x100),_0x3dd6ab(0x103)),setTimeout(()=>window['location'][_0x3dd6ab(0x11b)](),0x3e8)):showToast(_0x3dd6ab(0x116),_0x3dd6ab(0x110),_0x2b995f['error']);})[_0x521c19(0x112)](_0x274697=>{var _0x113a70=_0x521c19;showToast(_0x113a70(0x116),_0x113a70(0x110),_0x113a70(0x101));});});
</script></body></html>